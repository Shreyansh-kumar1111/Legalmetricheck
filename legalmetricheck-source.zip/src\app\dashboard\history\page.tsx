'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import {
  Search,
  Filter,
  Eye,
  History as HistoryIcon,
  Loader2,
  ArrowUpDown,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  PlusCircle,
  X,
  ArrowRight,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { InspectionData } from '@/types';
import { formatDate, getStatusLabel } from '@/lib/utils';
import { getRuntimeInspections } from '@/lib/demoData';

function HistoryContent() {
  const searchParams = useSearchParams();
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [statusFilter, setStatusFilter] = useState(searchParams.get('status') || 'ALL');
  
  const [inspections, setInspections] = useState<InspectionData[]>(
    getRuntimeInspections(statusFilter, searchQuery)
  );
  const [loading, setLoading] = useState(false);
  const [sortField, setSortField] = useState<'createdAt' | 'complianceScore'>('createdAt');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    const params = new URLSearchParams();
    if (statusFilter !== 'ALL') params.set('status', statusFilter);
    if (searchQuery.trim()) params.set('search', searchQuery.trim());

    fetch(`/api/inspections?${params.toString()}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          try {
            const stored = localStorage.getItem('demoInspections');
            if (stored) {
              const localInspections = JSON.parse(stored);
              const filteredLocals = localInspections.filter((i: any) => {
                if (statusFilter !== 'ALL' && i.status !== statusFilter) return false;
                if (searchQuery) {
                  const q = searchQuery.toLowerCase();
                  return i.productName?.toLowerCase().includes(q) || 
                         i.inspectionId?.toLowerCase().includes(q) || 
                         i.officerName?.toLowerCase().includes(q);
                }
                return true;
              });
              
              const existingIds = new Set(data.data.map((i: any) => i.inspectionId));
              const newLocals = filteredLocals.filter((i: any) => !existingIds.has(i.inspectionId));
              
              if (newLocals.length > 0) {
                setInspections([...newLocals, ...data.data]);
                return;
              }
            }
          } catch (e) {
            console.error('Failed to merge local inspections', e);
          }
          setInspections(data.data);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [statusFilter, searchQuery]);

  const sorted = [...inspections].sort((a, b) => {
    if (sortField === 'createdAt') {
      return sortDir === 'desc'
        ? new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        : new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
    return sortDir === 'desc'
      ? b.complianceScore - a.complianceScore
      : a.complianceScore - b.complianceScore;
  });

  const toggleSort = (field: 'createdAt' | 'complianceScore') => {
    if (sortField === field) {
      setSortDir((prev) => (prev === 'desc' ? 'asc' : 'desc'));
    } else {
      setSortField(field);
      setSortDir('desc');
    }
  };

  const statusPills = [
    { id: 'ALL', label: 'All Audits' },
    { id: 'COMPLIANT', label: 'Compliant' },
    { id: 'NON_COMPLIANT', label: 'Violations' },
    { id: 'NEEDS_REVIEW', label: 'Needs Review' },
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-950/80 text-indigo-300 border border-indigo-700/60 mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            <span>Audit History</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[var(--text-color)] tracking-tight">
            Inspection Records
          </h1>
          <p className="text-sm text-[var(--text-muted)] mt-1">
            Searchable history of verified packaged commodities and statutory findings.
          </p>
        </div>

        <Link
          href="/dashboard/inspect"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-[var(--text-color)] bg-indigo-600 hover:opacity-95 shadow-lg shadow-indigo-500/25 transition-all hover:scale-[1.02] min-h-[44px]"
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Inspection</span>
        </Link>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 sm:p-5 bg-[var(--card-bg)] backdrop-blur-md rounded-2xl border border-[var(--border-color)] shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="flex-1 w-full flex items-center gap-3 px-4 py-2.5 rounded-xl bg-[var(--card-bg)] border border-[var(--border-color)] focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20 transition-all shadow-inner group">
            <Search className="w-4 h-4 text-[var(--text-muted)] group-focus-within:text-indigo-400 shrink-0 pointer-events-none transition-colors" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by product name, batch ID, or manufacturer..."
              className="w-full bg-transparent text-sm font-normal text-[var(--text-color)] placeholder:text-[var(--text-muted)] focus:outline-none leading-normal tracking-wide"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="text-[var(--text-muted)] hover:text-[var(--text-color)] p-1 transition"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Sort Buttons */}
          <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
            <button
              onClick={() => toggleSort('createdAt')}
              className={`flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-3.5 py-2.5 sm:py-2 rounded-xl text-xs sm:text-sm font-semibold border transition cursor-pointer min-h-[42px] ${
                sortField === 'createdAt'
                  ? 'bg-indigo-950/80 text-indigo-300 border-indigo-700/60'
                  : 'bg-[var(--card-bg)] text-[var(--text-color)] border-[var(--border-color)] hover:bg-[var(--card-bg)]'
              }`}
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span>Date {sortField === 'createdAt' && (sortDir === 'desc' ? '↓' : '↑')}</span>
            </button>

            <button
              onClick={() => toggleSort('complianceScore')}
              className={`flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-3.5 py-2.5 sm:py-2 rounded-xl text-xs sm:text-sm font-semibold border transition cursor-pointer min-h-[42px] ${
                sortField === 'complianceScore'
                  ? 'bg-indigo-950/80 text-indigo-300 border-indigo-700/60'
                  : 'bg-[var(--card-bg)] text-[var(--text-color)] border-[var(--border-color)] hover:bg-[var(--card-bg)]'
              }`}
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span>Score {sortField === 'complianceScore' && (sortDir === 'desc' ? '↓' : '↑')}</span>
            </button>
          </div>
        </div>

        {/* Status Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {statusPills.map((pill) => (
            <button
              key={pill.id}
              onClick={() => setStatusFilter(pill.id)}
              className={`px-3.5 py-2 sm:py-1.5 rounded-xl text-xs sm:text-sm font-semibold border transition cursor-pointer shrink-0 min-h-[38px] ${
                statusFilter === pill.id
                  ? 'bg-indigo-600 text-[var(--text-color)] border-transparent shadow-md shadow-indigo-500/25'
                  : 'bg-[var(--card-bg)] text-[var(--text-muted)] border-[var(--border-color)] hover:bg-[var(--card-bg)] hover:text-[var(--text-color)]'
              }`}
            >
              {pill.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-[var(--card-bg)] rounded-2xl border border-[var(--border-color)] shadow-sm backdrop-blur-sm overflow-hidden">
        {loading ? (
          <div className="p-16 flex flex-col items-center justify-center text-center space-y-3">
            <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
            <p className="text-sm font-medium text-[var(--text-muted)]">Loading audit history...</p>
          </div>
        ) : sorted.length === 0 ? (
          <div className="p-16 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-950/80 text-indigo-400 border border-indigo-700/50 flex items-center justify-center mx-auto">
              <HistoryIcon className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-[var(--text-color)]">No Audits Found</h3>
            <p className="text-sm text-[var(--text-muted)] max-w-sm mx-auto">
              {searchQuery || statusFilter !== 'ALL'
                ? 'Try adjusting your search criteria or resetting the status filters.'
                : 'No packaged commodities have been audited yet. Start your first inspection.'}
            </p>
            <Link
              href="/dashboard/inspect"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-[var(--text-color)] bg-indigo-600 hover:bg-indigo-500 transition"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Audit a Commodity</span>
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[var(--card-bg)] border-b border-[var(--border-color)] text-[11px] font-bold text-[var(--text-muted)] uppercase tracking-wider">
                  <th className="py-3.5 px-6">Inspection ID & Date</th>
                  <th className="py-3.5 px-6">Commodity & Brand</th>
                  <th className="py-3.5 px-6 text-center">Score</th>
                  <th className="py-3.5 px-6">Compliance Status</th>
                  <th className="py-3.5 px-6">Inspector</th>
                  <th className="py-3.5 px-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-sm">
                {sorted.map((item) => {
                  const isPass = item.status === 'COMPLIANT';
                  const isFail = item.status === 'NON_COMPLIANT';
                  return (
                    <tr
                      key={item.inspectionId}
                      className="hover:bg-[var(--card-bg)]/40 transition group"
                    >
                      <td className="py-4 px-6 whitespace-nowrap">
                        <span className="font-mono text-xs font-bold text-indigo-300 bg-indigo-950/80 px-2 py-0.5 rounded-md border border-indigo-700/60">
                          {item.inspectionId}
                        </span>
                        <p className="text-xs text-[var(--text-muted)] mt-1">
                          {formatDate(item.createdAt)}
                        </p>
                      </td>

                      <td className="py-4 px-6">
                        <p className="font-bold text-[var(--text-color)] group-hover:text-indigo-400 transition">
                          {item.productName}
                        </p>
                        <p className="text-xs text-[var(--text-muted)]">
                          {item.officerName || 'Packaged Commodity'}
                        </p>
                      </td>

                      <td className="py-4 px-6 text-center">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-extrabold border ${
                            item.complianceScore >= 80
                              ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                              : item.complianceScore >= 50
                              ? 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                              : 'bg-rose-950/60 text-rose-300 border-rose-500/40'
                          }`}
                        >
                          {item.complianceScore}%
                        </span>
                      </td>

                      <td className="py-4 px-6 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${
                            isPass
                              ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                              : isFail
                              ? 'bg-rose-950/60 text-rose-300 border-rose-500/40'
                              : 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                          }`}
                        >
                          {isPass ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          ) : isFail ? (
                            <XCircle className="w-3.5 h-3.5 text-rose-400" />
                          ) : (
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                          )}
                          <span>{getStatusLabel(item.status)}</span>
                        </span>
                      </td>

                      <td className="py-4 px-6 whitespace-nowrap text-xs text-[var(--text-color)]">
                        <span className="font-semibold text-[var(--text-color)]">{item.officerName}</span>
                      </td>

                      <td className="py-4 px-6 whitespace-nowrap text-right">
                        <Link
                          href={`/dashboard/inspection/${item.inspectionId}`}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-300 bg-indigo-950/80 hover:bg-indigo-900/80 border border-indigo-700/50 transition"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View Notice</span>
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default function HistoryPage() {
  return (
    <Suspense
      fallback={
        <div className="p-12 text-center text-[var(--text-muted)] flex items-center justify-center gap-2">
          <Loader2 className="w-5 h-5 animate-spin text-indigo-500" />
          <span>Loading audit history...</span>
        </div>
      }
    >
      <HistoryContent />
    </Suspense>
  );
}
