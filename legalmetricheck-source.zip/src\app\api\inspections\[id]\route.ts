// ============================================================
// LegalMetriCheck — Single Inspection API
// ============================================================

import { NextRequest, NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Inspection from '@/models/Inspection';
import { getRuntimeInspectionById, updateRuntimeInspectionStatus } from '@/lib/demoData';

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    try {
      await connectDB();
      const inspection = await Inspection.findOne({
        $or: [{ inspectionId: id }, { _id: id.length === 24 ? id : undefined }],
      }).lean();

      if (inspection) {
        return NextResponse.json({
          success: true,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          data: { ...(inspection as any), _id: (inspection as any)._id.toString() },
        });
      }
    } catch {
      // DB not available, try demo data
    }

    // Fallback: search runtime / demo data
    const demo = getRuntimeInspectionById(id);
    if (demo) {
      return NextResponse.json({ success: true, data: demo });
    }

    return NextResponse.json(
      { success: false, error: 'Inspection not found' },
      { status: 404 }
    );
  } catch (error) {
    console.error('Fetch inspection error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch inspection' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { status } = body;

    if (!status) {
      return NextResponse.json({ success: false, error: 'Status is required' }, { status: 400 });
    }

    try {
      await connectDB();
      const inspection = await Inspection.findOneAndUpdate(
        { $or: [{ inspectionId: id }, { _id: id.length === 24 ? id : undefined }] },
        { status },
        { new: true }
      ).lean();

      if (inspection) {
        // also update demo data so it's in sync for offline
        updateRuntimeInspectionStatus(id, status);
        return NextResponse.json({
          success: true,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          data: { ...(inspection as any), _id: (inspection as any)._id.toString() },
        });
      }
    } catch {
      // DB not available, proceed to update demo data
    }

    // Fallback: update runtime / demo data
    const demo = updateRuntimeInspectionStatus(id, status);
    if (demo) {
      return NextResponse.json({ success: true, data: demo });
    }

    return NextResponse.json(
      { success: false, error: 'Inspection not found' },
      { status: 404 }
    );
  } catch (error) {
    console.error('Update inspection error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update inspection' },
      { status: 500 }
    );
  }
}
