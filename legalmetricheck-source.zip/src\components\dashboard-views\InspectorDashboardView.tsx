'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ClipboardCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Zap,
  ArrowRight,
  TrendingUp,
  BookOpen,
} from 'lucide-react';
import { DashboardStats, InspectionData } from '@/types';
import { formatDate } from '@/lib/utils';
import { getDemoStats } from '@/lib/demoData';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { TiltCard } from '@/components/ui/tilt-card';

export function InspectorDashboardView() {
  const [stats, setStats] = useState<DashboardStats | null>(getDemoStats());
  const [loading, setLoading] = useState(false);

  const fetchStats = () => {
    fetch('/api/inspections/stats')
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          try {
            const stored = localStorage.getItem('demoInspections');
            if (stored) {
              const localInspections = JSON.parse(stored);
              const existingIds = new Set(data.data.recentInspections.map((i: any) => i.inspectionId));
              const newLocals = localInspections.filter((i: any) => !existingIds.has(i.inspectionId));
              
              if (newLocals.length > 0) {
                data.data.recentInspections = [...newLocals, ...data.data.recentInspections].slice(0, 10);
                data.data.total = (parseInt(data.data.total) || 0) + newLocals.length;
              }
            }
          } catch (e) {
            console.error('Failed to merge local inspections', e);
          }
          setStats(data.data);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const handleUpdateStatus = async (id: string, newStatus: 'COMPLIANT' | 'NON_COMPLIANT') => {
    if (updatingId) return;
    setUpdatingId(id);
    try {
      const res = await fetch(`/api/inspections/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (data.success) {
        fetchStats();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[460px] space-y-4 animate-fade-in-scale">
        <div className="w-10 h-10 border-3 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
        <p className="text-sm font-medium text-[var(--text-muted)] font-mono tracking-wider">
          Loading Compliance Intelligence...
        </p>
      </div>
    );
  }

  if (!stats) return null;

  const statCards = [
    {
      label: 'My Inspections Today',
      value: "14",
      change: 'On Track',
      subtext: 'Target 20 daily scans',
      icon: ClipboardCheck,
      accentColor: 'text-indigo-400',
      bgAccent: 'bg-indigo-950/50 border-indigo-500/30',
      delay: 'delay-100',
    },
    {
      label: 'Pending Drafts',
      value: "3",
      change: 'Needs Action',
      subtext: 'Incomplete reports',
      icon: CheckCircle2,
      accentColor: 'text-amber-400',
      bgAccent: 'bg-amber-950/50 border-amber-500/30',
      delay: 'delay-200',
    },
    {
      label: 'Recent Violations',
      value: "2",
      change: 'Form VI Notice',
      subtext: 'Citations issued by me',
      icon: XCircle,
      accentColor: 'text-rose-400',
      bgAccent: 'bg-rose-950/50 border-rose-500/30',
      delay: 'delay-300',
    },
    {
      label: 'Active Alerts',
      value: "1",
      change: 'Priority Update',
      subtext: 'New statutory mandate',
      icon: AlertTriangle,
      accentColor: 'text-purple-400',
      bgAccent: 'bg-purple-950/50 border-purple-500/30',
      delay: 'delay-400',
    },
  ];

  return (
    <div className="space-y-10 animate-fade-in-up pb-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-2">
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-[var(--text-color)]">
            Inspector Workspace
          </h1>
          <p className="text-base font-bold text-[var(--text-color)]/90 bg-white/40 dark:bg-black/40 backdrop-blur-md px-4 py-2 rounded-xl inline-block shadow-[0_4px_12px_rgba(0,0,0,0.1)] border border-white/20 leading-relaxed mt-2">
            Ready for your next field inspection.
          </p>
        </div>
        <div className="flex gap-4">
          <Link
            href="/dashboard/inspect"
            className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-base shadow-xl shadow-indigo-500/25 transition-all hover:scale-105 active:scale-95"
          >
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-indigo-500/0 via-white/20 to-indigo-500/0 opacity-0 group-hover:opacity-100 transition-opacity -skew-x-12" />
            <Zap className="w-5 h-5 fill-white/20" />
            <span>Start New Inspection</span>
          </Link>
        </div>
      </div>

      {/* 4 Clean Minimal KPI Cards with Generous Padding & Larger Characters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6 perspective-1000">
        {statCards.map((card, idx) => (
          <TiltCard
            key={idx}
            className={`animate-fade-in-up ${card.delay} p-6 sm:p-7 flex flex-col justify-between space-y-4`}
          >
            <div className="flex items-start justify-between">
              <span className="text-xs sm:text-sm font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                {card.label}
              </span>
              <div
                className={`w-10 h-10 rounded-xl ${card.bgAccent} border flex items-center justify-center shrink-0`}
              >
                <card.icon className={`w-5 h-5 ${card.accentColor}`} />
              </div>
            </div>

            <div className="pt-2">
              <div className="text-4xl sm:text-5xl font-black text-[var(--text-color)] tracking-tight">
                {card.value}
              </div>
              <div className="flex items-center gap-2 mt-2 text-xs sm:text-sm">
                <span className="font-semibold text-slate-700 dark:text-[var(--text-color)] flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-[var(--text-muted)]" />
                  {card.change}
                </span>
                <span className="text-[var(--text-muted)] dark:text-[var(--text-muted)] font-light">
                  {card.subtext}
                </span>
              </div>
            </div>
          </TiltCard>
        ))}
      </div>

      {/* Charts & Metrics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Monthly Activity Chart */}
        <div className="lg:col-span-8 rounded-3xl p-7 sm:p-8 space-y-5 bg-white/40 dark:bg-black/40 backdrop-blur-xl border border-[var(--border-color)] shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-[var(--text-color)]">Monthly Inspection Activity</h2>
              <p className="text-xs sm:text-sm text-[var(--text-muted)] font-light mt-1">
                Field scans and compliance audits over the past months
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-[var(--text-muted)]">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-indigo-500"></span> Completed</span>
            </div>
          </div>
          <div className="h-[280px] w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.monthlyData || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" vertical={false} opacity={0.4} />
                <XAxis dataKey="month" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    borderColor: 'rgba(255, 255, 255, 0.2)',
                    borderRadius: '1rem',
                    color: '#fff',
                    boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
                  }}
                />
                <Bar dataKey="count" fill="#6366f1" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Circular Compliance Meter */}
        <div className="lg:col-span-4 rounded-3xl p-7 sm:p-8 flex flex-col items-center justify-between text-center space-y-6 bg-white/40 dark:bg-black/40 backdrop-blur-xl border border-[var(--border-color)] shadow-xl">
          <div className="w-full text-left">
            <h2 className="text-lg sm:text-xl font-bold text-[var(--text-color)]">Compliance Rate</h2>
            <p className="text-xs sm:text-sm text-[var(--text-muted)] font-light mt-1">
              Overall statutory adherence score
            </p>
          </div>

          <div className="relative flex items-center justify-center py-4">
            <div className="w-36 h-36 rounded-full border-8 border-indigo-500/20 flex items-center justify-center relative shadow-inner">
              <div className="absolute inset-0 rounded-full border-8 border-indigo-500 border-t-transparent animate-spin-slow" style={{ animationDuration: '10s' }} />
              <div className="text-center">
                <span className="text-3xl sm:text-4xl font-black text-[var(--text-color)]">
                  {stats.complianceRate || 94}%
                </span>
                <span className="block text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-wider mt-0.5">
                  Optimal
                </span>
              </div>
            </div>
          </div>

          <div className="w-full pt-2 border-t border-[var(--border-color)] flex items-center justify-between text-xs text-[var(--text-muted)] font-medium">
            <span>Target: 90%</span>
            <span className="text-emerald-400 font-bold">+4% vs last month</span>
          </div>
        </div>
      </div>

      {/* Clean Recent Inspections Table with Larger Typography & Comfortable Row Heights */}
      <div className="moody-card rounded-3xl overflow-hidden shadow-2xl">
        <div className="px-7 py-5 sm:px-8 sm:py-6 border-b border-[var(--border-color)] flex items-center justify-between">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-[var(--text-color)] flex items-center gap-2">
              Recent Field Scans
              <span className="bg-indigo-500/20 text-indigo-700 dark:text-indigo-400 text-xs px-2 py-0.5 rounded-full">{stats.total} Total</span>
            </h2>
            <p className="text-xs sm:text-sm text-[var(--text-muted)] font-light mt-1">
              Your latest submitted and draft inspection records
            </p>
          </div>
          <Link
            href="/dashboard/history"
            className="text-xs sm:text-sm font-semibold text-indigo-400 hover:text-indigo-300 inline-flex items-center gap-1.5 transition"
          >
            <span>View Full Archive</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[var(--border-color)] border-b border-[var(--border-color)] text-[var(--text-muted)] font-mono text-xs uppercase tracking-wider">
                <th className="px-7 py-4 font-semibold">Commodity</th>
                <th className="px-7 py-4 font-semibold">Date</th>
                <th className="px-7 py-4 font-semibold">Statutory Status</th>
                <th className="px-7 py-4 font-semibold">Score</th>
                <th className="px-7 py-4 font-semibold">Violations</th>
                <th className="px-7 py-4 font-semibold">Officer</th>
                <th className="px-7 py-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05] text-[var(--text-color)]">
              {stats.recentInspections.map((insp: InspectionData) => {
                const violations = (insp.validationResults || []).filter(
                  (r) => r.status === 'FAIL'
                ).length;

                return (
                  <tr
                    key={insp.inspectionId}
                    className="hover:bg-[var(--border-color)] transition-colors duration-150"
                  >
                    <td className="px-7 py-5">
                      <div className="font-bold text-[var(--text-color)] text-sm sm:text-base">{insp.productName}</div>
                      <div className="font-mono text-xs text-[var(--text-muted)] font-normal mt-0.5">
                        {insp.inspectionId}
                      </div>
                    </td>
                    <td className="px-7 py-5 text-[var(--text-color)] text-xs sm:text-sm whitespace-nowrap font-light">
                      {formatDate(insp.createdAt)}
                    </td>
                    <td className="px-7 py-5 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border ${
                          insp.status === 'COMPLIANT'
                            ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/30'
                            : insp.status === 'NON_COMPLIANT'
                            ? 'bg-rose-950/40 text-rose-300 border-rose-500/30'
                            : 'bg-amber-950/40 text-amber-300 border-amber-500/30'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            insp.status === 'COMPLIANT'
                              ? 'bg-emerald-400'
                              : insp.status === 'NON_COMPLIANT'
                              ? 'bg-rose-400'
                              : 'bg-amber-400'
                          }`}
                        />
                        {insp.status === 'COMPLIANT'
                          ? 'Compliant'
                          : insp.status === 'NON_COMPLIANT'
                          ? 'Violation'
                          : 'Under Review'}
                      </span>
                    </td>
                    <td className="px-7 py-5 font-mono font-bold text-[var(--text-color)] text-sm sm:text-base">
                      {insp.complianceScore}%
                    </td>
                    <td className="px-7 py-5 whitespace-nowrap">
                      {violations > 0 ? (
                        <span className="text-rose-400 text-xs sm:text-sm font-semibold">
                          {violations} Flagged
                        </span>
                      ) : (
                        <span className="text-[var(--text-muted)] text-xs sm:text-sm font-light">
                          0 Deficiencies
                        </span>
                      )}
                    </td>
                    <td className="px-7 py-5 text-[var(--text-color)] text-xs sm:text-sm font-medium">
                      {insp.officerName}
                    </td>
                    <td className="px-7 py-5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        {insp.status === 'NEEDS_REVIEW' && (
                          <>
                            <button
                              onClick={() => handleUpdateStatus(insp.inspectionId, 'COMPLIANT')}
                              disabled={updatingId === insp.inspectionId}
                              className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-emerald-400 hover:text-emerald-300 transition px-3 py-1.5 rounded-lg hover:bg-emerald-500/10 disabled:opacity-50"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>{updatingId === insp.inspectionId ? '...' : 'Accept'}</span>
                            </button>
                            <button
                              onClick={() => handleUpdateStatus(insp.inspectionId, 'NON_COMPLIANT')}
                              disabled={updatingId === insp.inspectionId}
                              className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-rose-400 hover:text-rose-300 transition px-3 py-1.5 rounded-lg hover:bg-rose-500/10 disabled:opacity-50"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>{updatingId === insp.inspectionId ? '...' : 'Reject'}</span>
                            </button>
                          </>
                        )}
                        <Link
                          href={`/dashboard/inspection/${insp.inspectionId}`}
                          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-[var(--text-color)] hover:text-indigo-400 transition group px-3 py-1.5 rounded-lg hover:bg-[var(--border-color)]"
                        >
                          <span>{insp.status === 'NEEDS_REVIEW' ? 'Resume' : 'View Report'}</span>
                          <ArrowRight className="w-3.5 h-3.5 text-[var(--text-muted)] group-hover:translate-x-1.5 group-hover:text-indigo-400 transition-all" />
                        </Link>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
