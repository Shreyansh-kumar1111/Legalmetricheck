@echo off
REM Wait until Next.js on port 3000 is ready, or timeout after 15 seconds
powershell -NoProfile -Command "1..15 | ForEach-Object { try { if ((Invoke-WebRequest -Uri 'http://127.0.0.1:3000' -UseBasicParsing -TimeoutSec 1).StatusCode -eq 200) { break } } catch {}; Start-Sleep -Seconds 1 }"

REM Launch URL using Windows default browser shell
start "" "http://localhost:3000"
explorer.exe "http://localhost:3000"
exit
