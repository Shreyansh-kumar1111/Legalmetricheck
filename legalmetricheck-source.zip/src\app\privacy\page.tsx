export default function PrivacyPage() {
  return (
    <div className="p-10 text-center text-white">
      <h1 className="text-2xl font-bold">Privacy Policy</h1>
      <p className="mt-4 text-slate-400">Content coming soon.</p>
    </div>
  );
}
