'use client';

import { useState, useEffect } from 'react';
import { Languages } from 'lucide-react';

export function LanguageSwitcher() {
  const [currentLang, setCurrentLang] = useState('en');
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    // Check for existing language cookie if needed
    const match = document.cookie.match(/(^| )googtrans=([^;]+)/);
    if (match) {
      const lang = match[2].split('/')[2];
      if (lang) {
        setCurrentLang(lang);
      }
    }
  }, []);

  const changeLanguage = (lang: string) => {
    // The Google Translate widget creates a hidden select box with class .goog-te-combo
    const select = document.querySelector('.goog-te-combo') as HTMLSelectElement;
    if (select) {
      select.value = lang;
      select.dispatchEvent(new Event('change'));
      setCurrentLang(lang);
      setShowDropdown(false);
    }
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setShowDropdown(!showDropdown)}
        className="p-2.5 rounded-xl text-[var(--text-color)] hover:text-[var(--text-color)] bg-[var(--border-color)] border border-[var(--border-color)] hover:border-indigo-500/30 transition flex items-center justify-center gap-2 cursor-pointer shadow-sm min-h-[42px]"
        aria-label="Switch Language"
      >
        <Languages className="w-5 h-5" />
        <span className="text-xs font-bold uppercase hidden sm:block">
          {currentLang === 'hi' ? 'HI' : 'EN'}
        </span>
      </button>

      {showDropdown && (
        <div className="absolute right-0 mt-3 w-32 rounded-xl moody-card border border-[var(--border-color)] shadow-2xl z-50 p-1.5 animate-fade-in-scale">
          <button
            onClick={() => changeLanguage('en')}
            className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
              currentLang === 'en' || currentLang === ''
                ? 'bg-indigo-500/10 text-indigo-400 font-bold'
                : 'text-[var(--text-color)] hover:bg-[var(--border-color)]'
            }`}
          >
            English
          </button>
          <button
            onClick={() => changeLanguage('hi')}
            className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
              currentLang === 'hi'
                ? 'bg-indigo-500/10 text-indigo-400 font-bold'
                : 'text-[var(--text-color)] hover:bg-[var(--border-color)]'
            }`}
          >
            हिंदी
          </button>
        </div>
      )}
    </div>
  );
}
