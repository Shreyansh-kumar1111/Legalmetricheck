// ============================================================
// LegalMetriCheck — Label Parser
// ============================================================
// Converts raw OCR text into structured ExtractedFields.
// Uses regex and heuristics. Designed to be improved over time.

import { ExtractedFields } from '@/types';

function firstMatch(text: string, patterns: RegExp[]): string | null {
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match && match[1]) {
      return match[1].trim();
    }
  }
  return null;
}

export function parseLabel(ocrText: string): ExtractedFields {
  if (!ocrText || ocrText.trim().length === 0) {
    return {
      mrp: null,
      netQuantity: null,
      manufacturerName: null,
      manufacturerAddress: null,
      manufacturingDate: null,
      consumerCare: null,
    };
  }

  const text = ocrText.replace(/\r\n/g, '\n');

  // --- MRP ---
  const mrp = firstMatch(text, [
    /(?:M\.?\s*R\.?\s*P\.?|Maximum\s+Retail\s+Price|Retail\s+Price)\s*[:\s₹Rs.INR]*\s*[₹Rs.INR]*\s*(\d+[\d,.]*)/i,
    /₹\s*(\d+[\d,.]*)/,
    /Rs\.?\s*(\d+[\d,.]*)/i,
  ]);

  // --- Net Quantity ---
  // Fixes common OCR errors where 'g' is read as '9', '0' as 'O', and handles punctuation like "Wt."
  const netQuantityMatch = firstMatch(text.replace(/O/gi, '0'), [
    /(?:Net|U|Usable)?\s*(?:Qty\.?|Quantity|Wt\.?|Weight|Vol\.?|Volume|Contents?)\s*[:=\-\s]*\s*([\d,.]+\s*(?:g|gm|gms|gram|grams|kg|kgs|ml|mL|l|L|litre|liter|oz|pieces?|pcs|nos|units?)(?:\b|9))/i,
    /(?:Contents?|Qty\.?|Weight)\s*[:=\-\s]*\s*([\d,.]+\s*(?:g|gm|gms|kg|ml|mL|l|L|oz|pcs)(?:\b|9))/i,
    /(\b[\d,.]+\s*(?:gm|gms|g|kg|ml|mL|l|L)(?:\b|9))/i,
  ]);
  
  // Clean up if '9' was appended due to OCR confusing 'g' for '9' at the end of words
  const netQuantity = netQuantityMatch ? netQuantityMatch.replace(/9$/i, 'g').trim() : null;

  // --- Manufacturer Name ---
  const manufacturerName = firstMatch(text, [
    /(?:Mfg\.?\s*(?:by)?|Manufactured\s*by|Packed\s*by|Packer|Marketed\s*by|Distributed\s*by)\s*[:\s]*\s*(.+?)(?:\n|,\s*[A-Z])/i,
    /(?:Mfg\.?\s*(?:by)?|Manufactured\s*by|Packed\s*by)\s*[:\s]*\s*(.+)/im,
  ]);

  // --- Manufacturer Address ---
  const manufacturerAddress = firstMatch(text, [
    /(?:Address|Regd\.?\s*Office|Factory|Plant)\s*[:\s]*\s*([\s\S]+?(?:\d{6}|\d{3}\s*\d{3}))/i,
    /(?:Address|Regd\.?\s*Office)\s*[:\s]*\s*([\s\S]+?(?:\n\n|\n(?:[A-Z])))/i,
  ]);

  // --- Manufacturing / Packing Date ---
  const manufacturingDate = firstMatch(text, [
    /(?:Mfg\.?\s*(?:Date|Dt\.?)|Manufacturing\s*Date|Packed\s*on|Pkg\.?\s*(?:Date|Dt\.?)|Date\s*of\s*(?:Mfg|Manufacturing|Packing|Pkg))\s*[:\s]*\s*([\w\s,.\/-]+?)(?:\n|$|Best|Exp|Use)/i,
    /(?:Mfg|MFD|DOM)\s*[:\s]*\s*(\d{1,2}[\s\/-]\w{3,9}[\s\/-]\d{2,4})/i,
    /(?:Mfg|MFD|DOM)\s*[:\s]*\s*(\d{1,2}[\s\/-]\d{1,2}[\s\/-]\d{2,4})/i,
  ]);

  // --- Consumer Care ---
  const consumerCare = firstMatch(text, [
    /(?:Consumer\s*(?:Care|Complaints?|Helpline|Service)|Customer\s*(?:Care|Service|Helpline)|Toll\s*Free|Helpline|Grievance)\s*[:\s]*\s*([\d\s\-+()@.\w]+?)(?:\n\n|\n(?:[A-Z]))/i,
    /(?:Consumer\s*Care|Customer\s*Care|Toll\s*Free|Helpline)\s*[:\s]*\s*([\d\s\-+()]+)/i,
    /(1800[\s\-]*\d{3}[\s\-]*\d{3,4})/,
  ]);

  // --- Unit Sale Price (USP) - Rule 6(1)(da) ---
  const unitSalePrice = firstMatch(text, [
    /(?:Unit\s*Sale\s*Price|USP|Unit\s*Price)\s*[:\s]*\s*([₹Rs.INR\d,.\s\/-]+?(?:g|gm|kg|ml|l|unit|piece|item))/i,
    /([₹Rs.INR]\s*[\d.]+\s*(?:\/|per)\s*(?:g|gm|kg|ml|l|piece|unit|nos))/i,
  ]);

  // --- Country of Origin - Rule 6(1)(aa) ---
  const countryOfOrigin = firstMatch(text, [
    /(?:Country\s*of\s*Origin|Made\s*in|Product\s*of|Origin)\s*[:\s]*\s*([A-Za-z\s]+?)(?:\n|,|$)/i,
  ]) || (text.toLowerCase().includes('india') ? 'India' : null);

  // --- Best Before / Expiry Date - Rule 6(1)(f) ---
  const expiryDate = firstMatch(text, [
    /(?:Best\s*Before|Expiry\s*(?:Date|Dt)?|Exp\.?\s*(?:Date|Dt)?|Use\s*by)\s*[:\s]*\s*([\w\s,.\/-]+?)(?:\n|$)/i,
    /(?:Best\s*within|Use\s*before)\s*[:\s]*\s*([\w\s]+?(?:months?|days?|years?))/i,
  ]);

  // --- Generic Name of Commodity - Rule 6(1)(c) ---
  const genericName = firstMatch(text, [
    /(?:Generic\s*Name|Common\s*Name|Commodity|Product\s*Type)\s*[:\s]*\s*([^\n,]+)/i,
  ]);

  // --- Tax Inclusion - Rule 6(3) ---
  const hasTaxInclusion = /incl\.?\s*(?:of)?\s*(?:all)?\s*taxes|inclusive\s*of\s*all\s*taxes/i.test(text);

  return {
    mrp: mrp ? (mrp.startsWith('₹') || mrp.startsWith('Rs') ? mrp : `₹ ${mrp}`) : null,
    netQuantity,
    manufacturerName,
    manufacturerAddress,
    manufacturingDate,
    consumerCare,
    unitSalePrice,
    countryOfOrigin,
    expiryDate,
    genericName,
    hasTaxInclusion: hasTaxInclusion ? 'Yes (Inclusive of all taxes)' : null,
  };
}
