'use client';

import { useUser } from '@/contexts/UserContext';
import { useState, useEffect } from 'react';
import { Settings as SettingsIcon, User as UserIcon, Bell, Palette, Brain, Sparkles, ShieldCheck } from 'lucide-react';
import { useTheme } from 'next-themes';

export default function SettingsPage() {
  const { user } = useUser();
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');
  
  const [notifications, setNotifications] = useState({
    emailReports: true,
    inspectionAlerts: true,
    systemUpdates: false,
  });

  const { theme, setTheme } = useTheme();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [department, setDepartment] = useState('');

  // Load saved settings on mount
  useEffect(() => {
    try {
      const savedNotifications = localStorage.getItem('notifications');
      if (savedNotifications) setNotifications(JSON.parse(savedNotifications));
    } catch (e) {
      console.error('Failed to load settings', e);
    }
  }, []);

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setEmail(user.email || '');
      setDepartment(user.department || '');
    }
  }, [user]);

  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme);
  };

  const handleNotificationChange = (key: keyof typeof notifications) => {
    const newNotifications = { ...notifications, [key]: !notifications[key] };
    setNotifications(newNotifications);
    localStorage.setItem('notifications', JSON.stringify(newNotifications));
  };

  const handleSaveProfile = async () => {
    setIsSaving(true);
    try {
      const res = await fetch('/api/auth/me', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, department }),
      });
      if (res.ok) {
        window.dispatchEvent(new Event('profileUpdated'));
        setSaveMessage('Preferences saved successfully!');
      } else {
        setSaveMessage('Failed to save preferences.');
      }
    } catch (e) {
      setSaveMessage('Error saving preferences.');
    } finally {
      setIsSaving(false);
      setTimeout(() => setSaveMessage(''), 3000);
    }
  };

  const isAuditor = user?.role?.toLowerCase().includes('auditor');

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-700/60 mb-2">
          <SettingsIcon className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
          <span>Application Preferences</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[var(--text-color)] tracking-tight">
          System & Officer Settings
        </h1>
        <p className="text-sm text-[var(--text-muted)] mt-1">Manage inspecting officer profile, alerts, and workspace settings.</p>
      </div>

      {/* Profile */}
      <div className="surface-card p-5 sm:p-7 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-[var(--border-color)]">
          <h3 className="text-base font-bold text-[var(--text-color)] flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-xl ${isAuditor ? 'bg-amber-50 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-700/50' : 'bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-700/50'} border flex items-center justify-center`}>
              <UserIcon className="h-4 w-4" />
            </div>
            <span>{isAuditor ? 'Auditor Profile' : 'Inspecting Officer Profile'}</span>
          </h3>
          {saveMessage && (
            <span className={`text-xs font-medium px-2.5 py-1 rounded-md border ${saveMessage.includes('successfully') ? 'text-emerald-400 bg-emerald-950/50 border-emerald-800/50' : 'text-rose-400 bg-rose-950/50 border-rose-800/50'}`}>
              {saveMessage}
            </span>
          )}
        </div>

        <div className={`p-4 rounded-xl border ${isAuditor ? 'bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-500/20' : 'bg-indigo-50 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-500/20'} mb-4`}>
          <div className="flex items-start gap-3">
            <ShieldCheck className={`w-5 h-5 mt-0.5 ${isAuditor ? 'text-amber-600 dark:text-amber-400' : 'text-indigo-600 dark:text-indigo-400'}`} />
            <div>
              <p className="text-sm font-bold text-slate-900 dark:text-[var(--text-color)]">
                Currently logged in as: <span className={isAuditor ? 'text-amber-600 dark:text-amber-400' : 'text-indigo-600 dark:text-indigo-400'}>{user?.role || 'Unknown Role'}</span>
              </p>
              <p className="text-xs text-slate-700 dark:text-[var(--text-muted)] mt-1">
                Your account type dictates your access level and dashboard features.
                To switch roles, sign out and use the 1-Click login buttons on the login screen.
              </p>
            </div>
          </div>
        </div>
        
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-[var(--text-color)] mb-1.5">Official Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[var(--border-color)] bg-[var(--card-bg)] text-base sm:text-sm text-[var(--text-color)] focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-[var(--text-color)] mb-1.5">Official Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[var(--border-color)] bg-[var(--card-bg)] text-base sm:text-sm text-[var(--text-color)] focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-[var(--text-color)] mb-1.5">Assigned Department</label>
            <input
              type="text"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[var(--border-color)] bg-[var(--card-bg)] text-base sm:text-sm text-[var(--text-color)] focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-[var(--text-color)] mb-1.5">Enforcement Jurisdiction</label>
            <input
              type="text"
              defaultValue="Department of Consumer Affairs, Delhi Circle"
              disabled
              className="w-full px-3.5 py-2.5 rounded-xl border border-[var(--border-color)] text-base sm:text-sm text-[var(--text-muted)] bg-[var(--card-bg)] cursor-not-allowed"
            />
          </div>
        </div>
        <button 
          onClick={handleSaveProfile}
          disabled={isSaving}
          className="inline-flex items-center justify-center px-5 py-2.5 bg-indigo-600 text-white text-xs sm:text-sm font-bold rounded-xl shadow-lg shadow-indigo-500/25 hover:bg-indigo-500 transition cursor-pointer min-h-[44px] disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {isSaving ? 'Saving Updates...' : 'Save Profile Updates'}
        </button>
      </div>

      {/* Notifications */}
      <div className="surface-card p-5 sm:p-7 space-y-4">
        <h3 className="text-base font-bold text-[var(--text-color)] flex items-center gap-2.5 pb-3 border-b border-[var(--border-color)]">
          <div className="w-8 h-8 rounded-xl bg-violet-50 dark:bg-violet-950/80 text-violet-600 dark:text-violet-400 border border-violet-200 dark:border-violet-700/50 flex items-center justify-center">
            <Bell className="h-4 w-4" />
          </div>
          <span>Notification & Enforcement Alerts</span>
        </h3>
        <div className="divide-y divide-white/5">
          {[
            { key: 'emailReports' as const, label: 'Statutory Weekly Dossiers', desc: 'Receive aggregated summary of all scanned batches every Monday' },
            { key: 'inspectionAlerts' as const, label: 'Instant Non-Compliance Trigger', desc: 'Alert when a scanned commodity violates high-severity Legal Metrology clauses' },
            { key: 'systemUpdates' as const, label: 'Rules & Gazette Updates', desc: 'Notifications when amendments are published under Section 18 / Section 36' },
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between py-3.5">
              <div className="pr-2">
                <p className="text-sm font-bold text-[var(--text-color)]">{item.label}</p>
                <p className="text-xs text-[var(--text-muted)] mt-0.5">{item.desc}</p>
              </div>
              <button
                type="button"
                aria-label={`Toggle ${item.label}`}
                onClick={() => handleNotificationChange(item.key)}
                className={`relative w-12 h-7 rounded-full transition-colors cursor-pointer shrink-0 ml-4 p-0.5 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 ${
                  notifications[item.key] ? 'bg-indigo-600' : 'bg-[var(--card-bg)]'
                }`}
              >
                <span
                  className={`block w-6 h-6 bg-white rounded-full shadow transition-transform ${
                    notifications[item.key] ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Appearance */}
      <div className="surface-card p-5 sm:p-7 space-y-4">
        <h3 className="text-base font-bold text-[var(--text-color)] flex items-center gap-2.5 pb-3 border-b border-[var(--border-color)]">
          <div className="w-8 h-8 rounded-xl bg-cyan-50 dark:bg-cyan-950/80 text-cyan-600 dark:text-cyan-400 border border-cyan-200 dark:border-cyan-700/50 flex items-center justify-center">
            <Palette className="h-4 w-4" />
          </div>
          <span>Theme & Visual Mode</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Dark Theme Button */}
          <button 
            onClick={() => handleThemeChange('dark')}
            className={`p-4 rounded-xl border-2 text-center cursor-pointer flex flex-col items-center justify-center min-h-[80px] transition-all ${
              theme === 'dark' 
                ? 'border-indigo-500 bg-indigo-950/40 shadow-sm' 
                : 'border-[var(--border-color)] bg-[var(--card-bg)] hover:border-indigo-500/30'
            }`}
          >
            <div className={`w-8 h-8 rounded-lg mb-2 shadow-xs flex items-center justify-center ${
              theme === 'dark' ? 'bg-slate-950 border border-indigo-400/50' : 'bg-slate-950 border border-transparent'
            }`}>
              {theme === 'dark' && <span className="w-2.5 h-2.5 rounded-full bg-indigo-400"></span>}
            </div>
            <span className={`text-xs font-bold ${theme === 'dark' ? 'text-indigo-300' : 'text-[var(--text-muted)]'}`}>
              Dark Mood {theme === 'dark' && '(Active)'}
            </span>
          </button>

          {/* Light Theme Button */}
          <button 
            onClick={() => handleThemeChange('light')}
            className={`p-4 rounded-xl border-2 text-center cursor-pointer flex flex-col items-center justify-center min-h-[80px] transition-all ${
              theme === 'light' 
                ? 'border-indigo-500 bg-indigo-950/40 shadow-sm' 
                : 'border-[var(--border-color)] bg-[var(--card-bg)] hover:border-indigo-500/30'
            }`}
          >
            <div className={`w-8 h-8 rounded-lg bg-white mb-2 shadow-xs flex items-center justify-center ${
              theme === 'light' ? 'border border-indigo-400/50' : ''
            }`}>
               {theme === 'light' && <span className="w-2.5 h-2.5 rounded-full bg-indigo-500"></span>}
            </div>
            <span className={`text-xs font-bold ${theme === 'light' ? 'text-indigo-300' : 'text-[var(--text-muted)]'}`}>
              Light Mood {theme === 'light' && '(Active)'}
            </span>
          </button>

          {/* System Theme Button */}
          <button 
            onClick={() => handleThemeChange('system')}
            className={`p-4 rounded-xl border-2 text-center cursor-pointer flex flex-col items-center justify-center min-h-[80px] transition-all ${
              theme === 'system' 
                ? 'border-indigo-500 bg-indigo-950/40 shadow-sm' 
                : 'border-[var(--border-color)] bg-[var(--card-bg)] hover:border-indigo-500/30'
            }`}
          >
            <div className={`w-8 h-8 rounded-lg bg-[var(--card-bg)]0 mb-2 shadow-xs flex items-center justify-center ${
              theme === 'system' ? 'border border-indigo-400/50' : 'border border-[var(--border-color)]'
            }`}>
               {theme === 'system' && <span className="w-2.5 h-2.5 rounded-full bg-indigo-300"></span>}
            </div>
            <span className={`text-xs font-bold ${theme === 'system' ? 'text-indigo-300' : 'text-[var(--text-muted)]'}`}>
              System Auto {theme === 'system' && '(Active)'}
            </span>
          </button>
        </div>
      </div>

      {/* Statutory About */}
      <div className="surface-card p-5 sm:p-7 space-y-3">
        <h3 className="text-base font-bold text-[var(--text-color)] flex items-center gap-2.5 pb-3 border-b border-[var(--border-color)]">
          <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-700/50 flex items-center justify-center">
            <Brain className="h-4 w-4" />
          </div>
          <span>About LegalMetriCheck</span>
        </h3>
        <p className="text-xs sm:text-sm text-[var(--text-color)] leading-relaxed">
          LegalMetriCheck is an intelligent packaged commodity compliance enforcement system built for
          Smart India Hackathon 2026 (SIH26034). It automates the screening of consumer product
          labels against the Legal Metrology (Packaged Commodities) Rules, 2011.
        </p>
        <div className="flex flex-wrap items-center gap-3 pt-2 text-xs font-semibold text-indigo-400">
          <span>Engine: Dual-Engine Active (Hybrid Offline / Neural OCR)</span>
          <span className="hidden sm:inline">•</span>
          <span>Version 2.2.0 (Premium Obsidian & Rich Jewels)</span>
        </div>
      </div>
    </div>
  );
}
