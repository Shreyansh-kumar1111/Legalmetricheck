import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const targetDir = path.resolve(__dirname, '../src/app/dashboard');

async function processDirectory(dir) {
  const files = await fs.readdir(dir, { withFileTypes: true });
  for (const file of files) {
    const fullPath = path.join(dir, file.name);
    if (file.isDirectory()) {
      await processDirectory(fullPath);
    } else if (file.isFile() && fullPath.endsWith('.tsx')) {
      const content = await fs.readFile(fullPath, 'utf8');
      
      // We want to replace exactly "text-white" with "text-slate-900 dark:text-white".
      // We don't want to replace "dark:text-white" or similar.
      // So we use a regex that negative lookbehinds for "dark:" or "-"
      let modified = content.replace(/(?<!(dark:|[\w-]))text-white(?!-)/g, 'text-slate-900 dark:text-white');
      
      // Same for text-slate-* -> text-slate-* dark:text-slate-* if needed, but the user specifically mentioned text-white
      if (content !== modified) {
        await fs.writeFile(fullPath, modified, 'utf8');
        console.log(`Updated ${fullPath}`);
      }
    }
  }
}

processDirectory(targetDir).catch(console.error);
