// ============================================================
// LegalMetriCheck — Demo Data / Seed
// ============================================================
// Provides demo inspections for dashboard population.
// Can be used as API fallback when MongoDB is unavailable.

import { InspectionData, DashboardStats, MonthlyDataPoint } from '@/types';

export const DEMO_INSPECTIONS: InspectionData[] = [
  {
    inspectionId: 'INS-2026-1001',
    userId: 'demo',
    productName: 'Parle-G Gold Biscuits 200g',
    ocrRawText: 'Parle-G Gold Biscuits\nMRP ₹20\nNet Qty: 200 g\nMfg. by: Parle Products Pvt. Ltd.\nAddress: Vile Parle, Mumbai, Maharashtra 400056\nMfg. Date: Mar 2026\nCustomer Care: 1800-123-4567',
    extractedFields: {
      mrp: '₹20',
      netQuantity: '200 g',
      manufacturerName: 'Parle Products Pvt. Ltd.',
      manufacturerAddress: 'Vile Parle, Mumbai, Maharashtra 400056',
      manufacturingDate: 'Mar 2026',
      consumerCare: '1800-123-4567',
    },
    validationResults: [
      { ruleId: 'LM-001', ruleName: 'MRP Declaration', field: 'mrp', status: 'PASS', detectedValue: '₹20', expectedCondition: 'MRP must be present', message: 'MRP detected: ₹20', severity: 'HIGH' },
      { ruleId: 'LM-002', ruleName: 'Net Quantity Declaration', field: 'netQuantity', status: 'PASS', detectedValue: '200 g', expectedCondition: 'Net quantity must be present', message: 'Net quantity detected: 200 g', severity: 'HIGH' },
      { ruleId: 'LM-003', ruleName: 'Manufacturer/Packer Name', field: 'manufacturerName', status: 'PASS', detectedValue: 'Parle Products Pvt. Ltd.', expectedCondition: 'Manufacturer name must be present', message: 'Manufacturer name detected', severity: 'HIGH' },
      { ruleId: 'LM-004', ruleName: 'Manufacturer/Packer Address', field: 'manufacturerAddress', status: 'PASS', detectedValue: 'Vile Parle, Mumbai, Maharashtra 400056', expectedCondition: 'Address must be present', message: 'Address detected', severity: 'HIGH' },
      { ruleId: 'LM-005', ruleName: 'Manufacturing/Packing Date', field: 'manufacturingDate', status: 'PASS', detectedValue: 'Mar 2026', expectedCondition: 'Date must be present', message: 'Manufacturing date detected', severity: 'HIGH' },
      { ruleId: 'LM-006', ruleName: 'Consumer Care Details', field: 'consumerCare', status: 'PASS', detectedValue: '1800-123-4567', expectedCondition: 'Consumer care must be present', message: 'Consumer care detected', severity: 'MEDIUM' },
      { ruleId: 'LM-007', ruleName: 'MRP Format Validation', field: 'mrp', status: 'PASS', detectedValue: '₹20', expectedCondition: 'Valid currency format', message: 'MRP format is valid', severity: 'MEDIUM' },
      { ruleId: 'LM-008', ruleName: 'Net Quantity Format', field: 'netQuantity', status: 'PASS', detectedValue: '200 g', expectedCondition: 'Number with unit', message: 'Net quantity format valid', severity: 'MEDIUM' },
    ],
    status: 'COMPLIANT',
    complianceScore: 100,
    officerName: 'Rajesh Kumar',
    createdAt: '2026-09-10T10:30:00Z',
  },
  {
    inspectionId: 'INS-2026-1002',
    userId: 'demo',
    productName: 'Lays Classic Salted Chips 52g',
    ocrRawText: 'Lays Classic Salted\nMRP ₹20\nNet Wt: 52 g\nManufactured by: PepsiCo India Holdings Pvt Ltd\nMfg Date: Aug 2026\nCustomer Care: 1800-12-7262',
    extractedFields: {
      mrp: '₹20',
      netQuantity: '52 g',
      manufacturerName: 'PepsiCo India Holdings Pvt Ltd',
      manufacturerAddress: null,
      manufacturingDate: 'Aug 2026',
      consumerCare: '1800-12-7262',
    },
    validationResults: [
      { ruleId: 'LM-001', ruleName: 'MRP Declaration', field: 'mrp', status: 'PASS', detectedValue: '₹20', expectedCondition: 'MRP must be present', message: 'MRP detected: ₹20', severity: 'HIGH' },
      { ruleId: 'LM-002', ruleName: 'Net Quantity Declaration', field: 'netQuantity', status: 'PASS', detectedValue: '52 g', expectedCondition: 'Net quantity must be present', message: 'Net quantity detected: 52 g', severity: 'HIGH' },
      { ruleId: 'LM-003', ruleName: 'Manufacturer/Packer Name', field: 'manufacturerName', status: 'PASS', detectedValue: 'PepsiCo India Holdings Pvt Ltd', expectedCondition: 'Manufacturer name must be present', message: 'Manufacturer name detected', severity: 'HIGH' },
      { ruleId: 'LM-004', ruleName: 'Manufacturer/Packer Address', field: 'manufacturerAddress', status: 'FAIL', detectedValue: null, expectedCondition: 'Address must be present', message: 'Manufacturer/packer address not found', severity: 'HIGH' },
      { ruleId: 'LM-005', ruleName: 'Manufacturing/Packing Date', field: 'manufacturingDate', status: 'PASS', detectedValue: 'Aug 2026', expectedCondition: 'Date must be present', message: 'Manufacturing date detected', severity: 'HIGH' },
      { ruleId: 'LM-006', ruleName: 'Consumer Care Details', field: 'consumerCare', status: 'PASS', detectedValue: '1800-12-7262', expectedCondition: 'Consumer care must be present', message: 'Consumer care detected', severity: 'MEDIUM' },
      { ruleId: 'LM-007', ruleName: 'MRP Format Validation', field: 'mrp', status: 'PASS', detectedValue: '₹20', expectedCondition: 'Valid currency format', message: 'MRP format is valid', severity: 'MEDIUM' },
      { ruleId: 'LM-008', ruleName: 'Net Quantity Format', field: 'netQuantity', status: 'PASS', detectedValue: '52 g', expectedCondition: 'Number with unit', message: 'Net quantity format valid', severity: 'MEDIUM' },
    ],
    status: 'NON_COMPLIANT',
    complianceScore: 88,
    officerName: 'Rajesh Kumar',
    createdAt: '2026-09-09T14:15:00Z',
  },
  {
    inspectionId: 'INS-2026-1003',
    userId: 'demo',
    productName: 'Nature Fresh Sunflower Oil 1L',
    ocrRawText: 'Nature Fresh Sunflower Oil\nNet Contents: 1 L\nManufactured by: Cargill India Pvt. Ltd.\nPlant Address: Kurkumbh MIDC, Pune, Maharashtra 413802\nBest Before: 12 months from packaging\nPkg Date: Jul 2026',
    extractedFields: {
      mrp: null,
      netQuantity: '1 L',
      manufacturerName: 'Cargill India Pvt. Ltd.',
      manufacturerAddress: 'Kurkumbh MIDC, Pune, Maharashtra 413802',
      manufacturingDate: 'Jul 2026',
      consumerCare: null,
    },
    validationResults: [
      { ruleId: 'LM-001', ruleName: 'MRP Declaration', field: 'mrp', status: 'FAIL', detectedValue: null, expectedCondition: 'MRP must be present', message: 'MRP not found on label', severity: 'HIGH' },
      { ruleId: 'LM-002', ruleName: 'Net Quantity Declaration', field: 'netQuantity', status: 'PASS', detectedValue: '1 L', expectedCondition: 'Net quantity must be present', message: 'Net quantity detected: 1 L', severity: 'HIGH' },
      { ruleId: 'LM-003', ruleName: 'Manufacturer/Packer Name', field: 'manufacturerName', status: 'PASS', detectedValue: 'Cargill India Pvt. Ltd.', expectedCondition: 'Manufacturer name must be present', message: 'Manufacturer name detected', severity: 'HIGH' },
      { ruleId: 'LM-004', ruleName: 'Manufacturer/Packer Address', field: 'manufacturerAddress', status: 'PASS', detectedValue: 'Kurkumbh MIDC, Pune, Maharashtra 413802', expectedCondition: 'Address must be present', message: 'Address detected', severity: 'HIGH' },
      { ruleId: 'LM-005', ruleName: 'Manufacturing/Packing Date', field: 'manufacturingDate', status: 'PASS', detectedValue: 'Jul 2026', expectedCondition: 'Date must be present', message: 'Manufacturing date detected', severity: 'HIGH' },
      { ruleId: 'LM-006', ruleName: 'Consumer Care Details', field: 'consumerCare', status: 'FAIL', detectedValue: null, expectedCondition: 'Consumer care must be present', message: 'Consumer care details not found', severity: 'MEDIUM' },
      { ruleId: 'LM-007', ruleName: 'MRP Format Validation', field: 'mrp', status: 'FAIL', detectedValue: null, expectedCondition: 'Valid currency format', message: 'MRP not present, cannot validate format', severity: 'MEDIUM' },
      { ruleId: 'LM-008', ruleName: 'Net Quantity Format', field: 'netQuantity', status: 'PASS', detectedValue: '1 L', expectedCondition: 'Number with unit', message: 'Net quantity format valid', severity: 'MEDIUM' },
    ],
    status: 'NON_COMPLIANT',
    complianceScore: 63,
    officerName: 'Priya Sharma',
    createdAt: '2026-09-08T09:00:00Z',
  },
  {
    inspectionId: 'INS-2026-1004',
    userId: 'demo',
    productName: 'Dettol Original Soap 75g',
    ocrRawText: 'Dettol Original Soap\nMRP ₹42\nNet Wt: 75 g\nMfg by: Reckitt Benckiser (India) Pvt. Ltd.\nAddress: H-4, DLF Phase II, Gurugram, Haryana 122002\nMfg Dt: Jun 2026\nConsumer Helpline: 1800-102-3286',
    extractedFields: {
      mrp: '₹42',
      netQuantity: '75 g',
      manufacturerName: 'Reckitt Benckiser (India) Pvt. Ltd.',
      manufacturerAddress: 'H-4, DLF Phase II, Gurugram, Haryana 122002',
      manufacturingDate: 'Jun 2026',
      consumerCare: '1800-102-3286',
    },
    validationResults: [
      { ruleId: 'LM-001', ruleName: 'MRP Declaration', field: 'mrp', status: 'PASS', detectedValue: '₹42', expectedCondition: 'MRP must be present', message: 'MRP detected: ₹42', severity: 'HIGH' },
      { ruleId: 'LM-002', ruleName: 'Net Quantity Declaration', field: 'netQuantity', status: 'PASS', detectedValue: '75 g', expectedCondition: 'Net quantity must be present', message: 'Net quantity detected: 75 g', severity: 'HIGH' },
      { ruleId: 'LM-003', ruleName: 'Manufacturer/Packer Name', field: 'manufacturerName', status: 'PASS', detectedValue: 'Reckitt Benckiser (India) Pvt. Ltd.', expectedCondition: 'Manufacturer name must be present', message: 'Manufacturer name detected', severity: 'HIGH' },
      { ruleId: 'LM-004', ruleName: 'Manufacturer/Packer Address', field: 'manufacturerAddress', status: 'PASS', detectedValue: 'H-4, DLF Phase II, Gurugram, Haryana 122002', expectedCondition: 'Address must be present', message: 'Address detected', severity: 'HIGH' },
      { ruleId: 'LM-005', ruleName: 'Manufacturing/Packing Date', field: 'manufacturingDate', status: 'PASS', detectedValue: 'Jun 2026', expectedCondition: 'Date must be present', message: 'Manufacturing date detected', severity: 'HIGH' },
      { ruleId: 'LM-006', ruleName: 'Consumer Care Details', field: 'consumerCare', status: 'PASS', detectedValue: '1800-102-3286', expectedCondition: 'Consumer care must be present', message: 'Consumer care detected', severity: 'MEDIUM' },
      { ruleId: 'LM-007', ruleName: 'MRP Format Validation', field: 'mrp', status: 'PASS', detectedValue: '₹42', expectedCondition: 'Valid currency format', message: 'MRP format is valid', severity: 'MEDIUM' },
      { ruleId: 'LM-008', ruleName: 'Net Quantity Format', field: 'netQuantity', status: 'PASS', detectedValue: '75 g', expectedCondition: 'Number with unit', message: 'Net quantity format valid', severity: 'MEDIUM' },
    ],
    status: 'COMPLIANT',
    complianceScore: 100,
    officerName: 'Priya Sharma',
    createdAt: '2026-09-07T16:45:00Z',
  },
  {
    inspectionId: 'INS-2026-1005',
    userId: 'demo',
    productName: 'Local Brand Namkeen Mix 150g',
    ocrRawText: 'Namkeen Mix\nWeight: 150 g approx',
    extractedFields: {
      mrp: null,
      netQuantity: '150 g',
      manufacturerName: null,
      manufacturerAddress: null,
      manufacturingDate: null,
      consumerCare: null,
    },
    validationResults: [
      { ruleId: 'LM-001', ruleName: 'MRP Declaration', field: 'mrp', status: 'FAIL', detectedValue: null, expectedCondition: 'MRP must be present', message: 'MRP not found on label', severity: 'HIGH' },
      { ruleId: 'LM-002', ruleName: 'Net Quantity Declaration', field: 'netQuantity', status: 'PASS', detectedValue: '150 g', expectedCondition: 'Net quantity must be present', message: 'Net quantity detected: 150 g', severity: 'HIGH' },
      { ruleId: 'LM-003', ruleName: 'Manufacturer/Packer Name', field: 'manufacturerName', status: 'FAIL', detectedValue: null, expectedCondition: 'Manufacturer name must be present', message: 'Manufacturer/packer name not found', severity: 'HIGH' },
      { ruleId: 'LM-004', ruleName: 'Manufacturer/Packer Address', field: 'manufacturerAddress', status: 'FAIL', detectedValue: null, expectedCondition: 'Address must be present', message: 'Manufacturer/packer address not found', severity: 'HIGH' },
      { ruleId: 'LM-005', ruleName: 'Manufacturing/Packing Date', field: 'manufacturingDate', status: 'FAIL', detectedValue: null, expectedCondition: 'Date must be present', message: 'Manufacturing/packing date not found', severity: 'HIGH' },
      { ruleId: 'LM-006', ruleName: 'Consumer Care Details', field: 'consumerCare', status: 'FAIL', detectedValue: null, expectedCondition: 'Consumer care must be present', message: 'Consumer care details not found', severity: 'MEDIUM' },
      { ruleId: 'LM-007', ruleName: 'MRP Format Validation', field: 'mrp', status: 'FAIL', detectedValue: null, expectedCondition: 'Valid currency format', message: 'MRP not present, cannot validate format', severity: 'MEDIUM' },
      { ruleId: 'LM-008', ruleName: 'Net Quantity Format', field: 'netQuantity', status: 'PASS', detectedValue: '150 g', expectedCondition: 'Number with unit', message: 'Net quantity format valid', severity: 'MEDIUM' },
    ],
    status: 'NEEDS_REVIEW',
    complianceScore: 25,
    officerName: 'Rajesh Kumar',
    createdAt: '2026-09-06T11:20:00Z',
  },
];

export const DEMO_MONTHLY: MonthlyDataPoint[] = [
  { month: 'Jan', compliant: 45, nonCompliant: 12, needsReview: 5 },
  { month: 'Feb', compliant: 52, nonCompliant: 9, needsReview: 7 },
  { month: 'Mar', compliant: 61, nonCompliant: 15, needsReview: 4 },
  { month: 'Apr', compliant: 58, nonCompliant: 8, needsReview: 6 },
  { month: 'May', compliant: 70, nonCompliant: 11, needsReview: 3 },
  { month: 'Jun', compliant: 84, nonCompliant: 14, needsReview: 5 },
];

export function getDemoStats(): DashboardStats {
  const runtimeList = runtimeInspections;
  const runtimeCompliant = runtimeList.filter(i => i.status === 'COMPLIANT').length;
  const runtimeNonCompliant = runtimeList.filter(i => i.status === 'NON_COMPLIANT').length;
  const runtimeNeedsReview = runtimeList.filter(i => i.status === 'NEEDS_REVIEW').length;

  const baseHistoric = 123;
  const total = baseHistoric + runtimeList.length;
  const compliant = 82 + runtimeCompliant;
  const nonCompliant = 33 + runtimeNonCompliant;
  const needsReview = 8 + runtimeNeedsReview;

  return {
    total,
    compliant,
    nonCompliant,
    needsReview,
    complianceRate: total > 0 ? Math.round((compliant / total) * 100) : 0,
    recentInspections: runtimeList.slice(0, 10),
    monthlyData: DEMO_MONTHLY,
  };
}

// In-memory runtime storage for demo / offline operation
export const runtimeInspections: InspectionData[] = [...DEMO_INSPECTIONS];

export function addRuntimeInspection(inspection: InspectionData): InspectionData {
  runtimeInspections.unshift(inspection);
  return inspection;
}

export function getRuntimeInspections(status?: string | null, search?: string | null): InspectionData[] {
  let list = [...runtimeInspections];
  if (status && status !== 'ALL') {
    list = list.filter(i => i.status === status);
  }
  if (search) {
    const s = search.toLowerCase();
    list = list.filter(i =>
      i.productName.toLowerCase().includes(s) ||
      i.inspectionId.toLowerCase().includes(s) ||
      (i.officerName && i.officerName.toLowerCase().includes(s))
    );
  }
  return list;
}

export function getRuntimeInspectionById(id: string): InspectionData | undefined {
  return runtimeInspections.find(i => i.inspectionId === id || i._id === id);
}

export function updateRuntimeInspectionStatus(id: string, status: string): InspectionData | undefined {
  const item = runtimeInspections.find(i => i.inspectionId === id || i._id === id);
  if (item) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    item.status = status as any;
  }
  return item;
}

