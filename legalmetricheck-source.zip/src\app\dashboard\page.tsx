'use client';

import React from 'react';
import { useUser } from '@/contexts/UserContext';
import { AuditorDashboardView } from '@/components/dashboard-views/AuditorDashboardView';
import { InspectorDashboardView } from '@/components/dashboard-views/InspectorDashboardView';

export default function DashboardPage() {
  const { user, loading } = useUser();

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[460px] space-y-4 animate-fade-in-scale">
        <div className="w-10 h-10 border-3 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
        <p className="text-sm font-medium text-[var(--text-muted)] font-mono tracking-wider">
          Loading Workspace...
        </p>
      </div>
    );
  }

  const isAuditor = user?.role?.toLowerCase().includes('auditor') || false;

  if (isAuditor) {
    return <AuditorDashboardView />;
  }

  return <InspectorDashboardView />;
}
