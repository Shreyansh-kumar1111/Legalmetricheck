// ============================================================
// LegalMetriCheck — Login API
// ============================================================

import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { connectDB } from '@/lib/db';
import User from '@/models/User';
import { setSession } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const { email, password, passcode, details } = await request.json();

    if (!email || !password) {
      return NextResponse.json(
        { success: false, error: 'Email and password are required' },
        { status: 400 }
      );
    }

    const cleanEmail = (email || '').toLowerCase().trim();
    const isAdminLogin = cleanEmail.includes('admin');
    
    if (isAdminLogin && !passcode) {
      return NextResponse.json(
        { success: false, error: 'Admin passcode is required for elevated access' },
        { status: 403 }
      );
    }
    if (isAdminLogin && passcode !== '8899') {
      return NextResponse.json(
        { success: false, error: 'Invalid admin passcode' },
        { status: 403 }
      );
    }

    if (!isAdminLogin && !details) {
      return NextResponse.json(
        { success: false, error: 'Employee details are required for standard login' },
        { status: 403 }
      );
    }

    // 1. Instant zero-latency demo accounts (Inspector & Auditor)
    if (
      cleanEmail === 'officer@legalmetri.demo' ||
      cleanEmail === 'auditor@legalmetri.demo' ||
      cleanEmail === 'admin@legalmetri.demo' ||
      cleanEmail.includes('demo')
    ) {
      const isAuditor = cleanEmail.includes('auditor');
      const isAdmin = cleanEmail.includes('admin');
      const demoUser = {
        _id: isAuditor ? 'demo-auditor-1' : isAdmin ? 'demo-admin-1' : 'demo-officer-1',
        name: isAuditor ? 'Auditor Priya Sharma' : isAdmin ? 'Director General S. K. Verma' : 'Inspector Rajesh Kumar',
        email: cleanEmail,
        role: isAuditor ? 'Compliance Auditor' : isAdmin ? 'Director (Legal Metrology)' : 'Senior Legal Metrology Officer',
        department: 'Department of Consumer Affairs, Legal Metrology Division, Govt. of India',
      };
      await setSession(demoUser._id);
      return NextResponse.json({
        success: true,
        data: demoUser,
      });
    }

    // 2. Database authentication if MongoDB is configured
    try {
      await connectDB();
      const user = await User.findOne({ email: cleanEmail });
      if (user) {
        const isValid = await bcrypt.compare(password, user.password);
        if (isValid) {
          await setSession(user._id.toString());
          return NextResponse.json({
            success: true,
            data: {
              _id: user._id.toString(),
              name: user.name,
              email: user.email,
              role: user.role,
              department: user.department,
            },
          });
        }
      }
    } catch {
      // If DB is offline, still permit login for demonstration
      const fallbackUser = {
        _id: 'demo-officer-1',
        name: 'Inspector Rajesh Kumar',
        email: cleanEmail,
        role: 'Senior Legal Metrology Officer',
        department: 'Department of Consumer Affairs, Legal Metrology Division',
      };
      await setSession(fallbackUser._id);
      return NextResponse.json({
        success: true,
        data: fallbackUser,
      });
    }

    return NextResponse.json(
      { success: false, error: 'Invalid email or password' },
      { status: 401 }
    );
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { success: false, error: 'An error occurred during login' },
      { status: 500 }
    );
  }
}
