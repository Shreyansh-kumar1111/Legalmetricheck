const http = require('http');
const { spawn, exec } = require('child_process');
const path = require('path');

const projectDir = path.resolve(__dirname, '..');

function checkServer(cb) {
  let finished = false;
  const done = (val) => {
    if (!finished) {
      finished = true;
      cb(val);
    }
  };

  const req = http.get({
    host: '127.0.0.1',
    port: 3000,
    path: '/',
    timeout: 1200
  }, (res) => {
    res.resume();
    done(true);
  });

  req.on('error', () => done(false));
  req.on('timeout', () => {
    req.destroy();
    done(false);
  });
}

function openBrowser() {
  console.log('\n=============================================================');
  console.log('  LegalMetriCheck is LIVE at http://localhost:3000');
  console.log('  Opening your web browser now...');
  console.log('=============================================================\n');
  exec('cmd.exe /c start http://localhost:3000', (err) => {
    if (err) {
      exec('powershell -NoProfile -Command "Start-Process http://localhost:3000"');
    }
  });
}

console.log('Checking LegalMetriCheck status...');

checkServer((alreadyRunning) => {
  if (alreadyRunning) {
    console.log('\n[SUCCESS] LegalMetriCheck server is already running in background!');
    openBrowser();
    console.log('The web application is active. Keep this window open or minimize it.\n');
    return;
  }

  console.log('Starting application server...');
  console.log('Your browser will open automatically as soon as the server is ready.\n');

  let browserOpened = false;
  const pollTimer = setInterval(() => {
    checkServer((ready) => {
      if (ready && !browserOpened) {
        browserOpened = true;
        clearInterval(pollTimer);
        openBrowser();
      }
    });
  }, 1000);

  setTimeout(() => {
    if (!browserOpened) {
      browserOpened = true;
      clearInterval(pollTimer);
      openBrowser();
    }
  }, 15000);

  const npmCmd = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  const child = spawn(npmCmd, ['run', 'dev'], {
    cwd: projectDir,
    stdio: 'inherit'
  });

  child.on('exit', (code) => {
    clearInterval(pollTimer);
    if (code !== 0) {
      console.log(`\nNext.js exited with code ${code}.`);
    }
  });
});
