// ============================================================
// LegalMetriCheck — Inspection Model
// ============================================================

import mongoose, { Schema, Document, Model } from 'mongoose';

const ExtractedFieldsSchema = new Schema({
  mrp: { type: String, default: null },
  netQuantity: { type: String, default: null },
  manufacturerName: { type: String, default: null },
  manufacturerAddress: { type: String, default: null },
  manufacturingDate: { type: String, default: null },
  consumerCare: { type: String, default: null },
}, { _id: false });

const ValidationCheckSchema = new Schema({
  ruleId: { type: String, required: true },
  ruleName: { type: String, required: true },
  field: { type: String, required: true },
  status: { type: String, enum: ['PASS', 'FAIL', 'WARNING'], required: true },
  detectedValue: { type: String, default: null },
  expectedCondition: { type: String },
  message: { type: String },
  severity: { type: String, enum: ['HIGH', 'MEDIUM', 'LOW'], required: true },
}, { _id: false });

export interface IInspection extends Document {
  inspectionId: string;
  userId: string;
  productName: string;
  imageBase64?: string;
  ocrRawText: string;
  extractedFields: {
    mrp: string | null;
    netQuantity: string | null;
    manufacturerName: string | null;
    manufacturerAddress: string | null;
    manufacturingDate: string | null;
    consumerCare: string | null;
  };
  validationResults: Array<{
    ruleId: string;
    ruleName: string;
    field: string;
    status: 'PASS' | 'FAIL' | 'WARNING';
    detectedValue: string | null;
    expectedCondition: string;
    message: string;
    severity: 'HIGH' | 'MEDIUM' | 'LOW';
  }>;
  status: 'COMPLIANT' | 'NON_COMPLIANT' | 'NEEDS_REVIEW' | 'PENDING';
  complianceScore: number;
  officerName: string;
  createdAt: Date;
}

const InspectionSchema = new Schema<IInspection>({
  inspectionId: { type: String, required: true, unique: true },
  userId: { type: String, required: true },
  productName: { type: String, required: true, default: 'Unknown Product' },
  imageBase64: { type: String },
  ocrRawText: { type: String, default: '' },
  extractedFields: { type: ExtractedFieldsSchema, required: true },
  validationResults: [ValidationCheckSchema],
  status: {
    type: String,
    enum: ['COMPLIANT', 'NON_COMPLIANT', 'NEEDS_REVIEW', 'PENDING'],
    default: 'PENDING',
  },
  complianceScore: { type: Number, default: 0 },
  officerName: { type: String, default: 'Inspector' },
  createdAt: { type: Date, default: Date.now },
});

const Inspection: Model<IInspection> = mongoose.models.Inspection || mongoose.model<IInspection>('Inspection', InspectionSchema);
export default Inspection;
