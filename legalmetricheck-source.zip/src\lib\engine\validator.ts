// ============================================================
// LegalMetriCheck — Validation Engine
// ============================================================
// Pure function: receives extracted fields + rules, returns validation result.
// Designed for testability and future extensibility.

import { ExtractedFields, InspectionStatus, ValidationCheckResult, ValidationResult } from '@/types';
import { DEFAULT_RULES } from './rules';

export function validateProduct(fields: ExtractedFields): ValidationResult {
  const activeRules = DEFAULT_RULES.filter(r => r.isActive);
  const results: ValidationCheckResult[] = activeRules.map(rule => rule.validate(fields));

  const passedChecks = results.filter(r => r.status === 'PASS').length;
  const failedChecks = results.filter(r => r.status === 'FAIL').length;
  const totalChecks = results.length;

  const complianceScore = totalChecks > 0
    ? Math.round((passedChecks / totalChecks) * 100)
    : 0;

  // Determine overall status
  let status: InspectionStatus = 'COMPLIANT';

  const hasHighSeverityFail = results.some(
    r => r.status === 'FAIL' && r.severity === 'HIGH'
  );
  const hasMediumOrLowFail = results.some(
    r => r.status === 'FAIL' && (r.severity === 'MEDIUM' || r.severity === 'LOW')
  );

  if (hasHighSeverityFail) {
    status = 'NON_COMPLIANT';
  } else if (hasMediumOrLowFail) {
    status = 'NEEDS_REVIEW';
  }

  return {
    status,
    complianceScore,
    totalChecks,
    passedChecks,
    failedChecks,
    results,
  };
}
