const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx')) {
      results.push(file);
    }
  });
  return results;
}

const files = walk('c:/Users/dell/.gemini/antigravity-ide/scratch/legalmetricheck/src/app/dashboard');
let count = 0;

files.forEach(f => {
  let content = fs.readFileSync(f, 'utf8');
  let original = content;

  // Backgrounds
  content = content.replace(/bg-slate-900\/80/g, 'bg-[var(--card-bg)]');
  content = content.replace(/bg-slate-950\/80/g, 'bg-[var(--card-bg)]');
  content = content.replace(/bg-slate-900\/40/g, 'bg-[var(--card-bg)]');
  content = content.replace(/bg-slate-950\/40/g, 'bg-[var(--card-bg)]');
  content = content.replace(/bg-slate-800/g, 'bg-[var(--card-bg)]');
  content = content.replace(/bg-slate-50/g, 'bg-[var(--card-bg)]');
  
  // Translucent highlights (like hover states or subtle borders)
  // Instead of border-color, let's just make it a subtle text-color alpha
  // Since Tailwind can parse arbitrary values like `bg-[var(--text-color)]/5` if defined right, 
  // but let's stick to safe `bg-[var(--border-color)]`
  content = content.replace(/bg-white\/\[0\.05\]/g, 'bg-[var(--border-color)]');
  content = content.replace(/bg-white\/\[0\.02\]/g, 'bg-[var(--border-color)]');
  content = content.replace(/bg-white\/\[0\.03\]/g, 'bg-[var(--border-color)]');
  content = content.replace(/bg-white\/\[0\.04\]/g, 'bg-[var(--border-color)]');
  content = content.replace(/bg-white\/\[0\.06\]/g, 'bg-[var(--border-color)]');
  content = content.replace(/bg-white\/10/g, 'bg-[var(--border-color)]');

  // Borders
  content = content.replace(/border-white\/10/g, 'border-[var(--border-color)]');
  content = content.replace(/border-white\/15/g, 'border-[var(--border-color)]');
  content = content.replace(/border-white\/20/g, 'border-[var(--border-color)]');
  content = content.replace(/border-white\/25/g, 'border-[var(--border-color)]');
  content = content.replace(/border-white\/\[0\.08\]/g, 'border-[var(--border-color)]');
  content = content.replace(/border-slate-200\/50/g, 'border-[var(--border-color)]');
  content = content.replace(/border-slate-200/g, 'border-[var(--border-color)]');

  // Text
  content = content.replace(/text-slate-200/g, 'text-[var(--text-color)]');
  content = content.replace(/text-slate-300/g, 'text-[var(--text-color)]');

  if (content !== original) {
    fs.writeFileSync(f, content);
    count++;
  }
});

console.log('Replaced UI hardcoded values in ' + count + ' files');
