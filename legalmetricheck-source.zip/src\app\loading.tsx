import React from 'react';
import { Brain } from 'lucide-react';

export default function Loading() {
  return (
    <div className="fixed inset-0 z-[9999] bg-[#09090b] flex flex-col items-center justify-center">
      <div className="relative flex flex-col items-center justify-center">
        {/* Pulsing ring */}
        <div className="absolute w-32 h-32 rounded-full border border-indigo-500/30 animate-[ping_2.5s_cubic-bezier(0,0,0.2,1)_infinite]" />
        
        {/* Inner rotating gradient ring */}
        <div className="absolute w-24 h-24 rounded-full bg-gradient-to-tr from-indigo-600 via-purple-600 to-cyan-500 opacity-20 blur-xl animate-pulse" />
        
        {/* Brain logo container */}
        <div className="relative w-16 h-16 rounded-2xl bg-[#09090b] border border-white/10 flex items-center justify-center shadow-2xl z-10 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/20 to-purple-500/20" />
          <Brain className="w-8 h-8 text-indigo-400 animate-pulse" />
        </div>
        
        {/* Loading Text */}
        <div className="mt-8 flex flex-col items-center gap-2">
          <h2 className="text-white font-semibold tracking-wider uppercase text-sm flex items-center gap-1">
            Loading System
            <span className="flex gap-0.5">
              <span className="w-1 h-1 rounded-full bg-indigo-500 animate-[bounce_1.4s_infinite_0ms]" />
              <span className="w-1 h-1 rounded-full bg-indigo-500 animate-[bounce_1.4s_infinite_200ms]" />
              <span className="w-1 h-1 rounded-full bg-indigo-500 animate-[bounce_1.4s_infinite_400ms]" />
            </span>
          </h2>
          <p className="text-xs text-white/40 font-mono">Initializing LegalMetriCheck</p>
        </div>
      </div>
    </div>
  );
}
