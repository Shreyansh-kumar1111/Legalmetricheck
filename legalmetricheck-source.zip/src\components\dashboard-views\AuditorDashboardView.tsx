'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ShieldCheck,
  ClipboardCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Zap,
  ArrowRight,
  TrendingUp,
  BookOpen,
} from 'lucide-react';
import { DashboardStats, InspectionData } from '@/types';
import { formatDate } from '@/lib/utils';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { TiltCard } from '@/components/ui/tilt-card';
import { getDemoStats } from '@/lib/demoData';

export function AuditorDashboardView() {
  const [stats, setStats] = useState<DashboardStats | null>(getDemoStats());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch('/api/inspections/stats')
      .then((res) => res.json())
      .then((data) => {
        if (data.success) setStats(data.data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[460px] space-y-4 animate-fade-in-scale">
        <div className="w-10 h-10 border-3 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
        <p className="text-sm font-medium text-[var(--text-muted)] font-mono tracking-wider">
          Loading Compliance Intelligence...
        </p>
      </div>
    );
  }

  if (!stats) return null;

  const statCards = [
    {
      label: 'Total Packaged Units',
      value: stats.total,
      change: '+18.4%',
      subtext: 'vs last month',
      icon: ClipboardCheck,
      accentColor: 'text-indigo-400',
      bgAccent: 'bg-indigo-950/50 border-indigo-500/30',
      delay: 'delay-100',
    },
    {
      label: 'Compliant Packages',
      value: stats.compliant,
      change: `${stats.complianceRate}%`,
      subtext: 'statutory pass rate',
      icon: CheckCircle2,
      accentColor: 'text-emerald-400',
      bgAccent: 'bg-emerald-950/50 border-emerald-500/30',
      delay: 'delay-200',
    },
    {
      label: 'Violations Flagged',
      value: stats.nonCompliant,
      change: 'Form VI Notice',
      subtext: 'statutory citations',
      icon: XCircle,
      accentColor: 'text-rose-400',
      bgAccent: 'bg-rose-950/50 border-rose-500/30',
      delay: 'delay-300',
    },
    {
      label: 'Under Officer Review',
      value: stats.needsReview,
      change: 'Pending',
      subtext: 'manual verification',
      icon: AlertTriangle,
      accentColor: 'text-amber-400',
      bgAccent: 'bg-amber-950/50 border-amber-500/30',
      delay: 'delay-400',
    },
  ];

  return (
    <div className="space-y-10 animate-fade-in-up pb-12">
      {/* Top Header & Quick Actions with Generous Distance & 2-4pt Larger Buttons */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 pb-2">
        <div className="space-y-1.5">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[var(--text-color)] tracking-tight">
            Compliance Command Center
          </h1>
          <p className="text-sm sm:text-base text-[var(--text-muted)] font-normal">
            Real-time packaged commodity compliance oversight and statutory audit records.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <Link
            href="/dashboard/history?status=NON_COMPLIANT"
            className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl text-sm sm:text-base font-semibold text-[var(--text-color)] bg-[var(--card-bg)] hover:bg-[var(--border-color)] border border-[var(--border-color)] hover:border-[var(--border-color)] transition active:scale-95 shadow-sm"
          >
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Review Flagged</span>
          </Link>
          <button
            className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl text-sm sm:text-base font-bold text-white bg-indigo-600 hover:bg-indigo-500 shadow-md shadow-indigo-500/20 hover:shadow-indigo-500/40 transition active:scale-95"
          >
            <BookOpen className="w-4 h-4 text-white/80" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* 4 Clean Minimal KPI Cards with Generous Padding & Larger Characters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6 perspective-1000">
        {statCards.map((card, idx) => (
          <TiltCard
            key={idx}
            className={`animate-fade-in-up ${card.delay} p-6 sm:p-7 flex flex-col justify-between space-y-4`}
          >
            <div className="flex items-start justify-between">
              <span className="text-xs sm:text-sm font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                {card.label}
              </span>
              <div
                className={`w-10 h-10 rounded-xl ${card.bgAccent} border flex items-center justify-center shrink-0`}
              >
                <card.icon className={`w-5 h-5 ${card.accentColor}`} />
              </div>
            </div>

            <div className="pt-2">
              <div className="text-4xl sm:text-5xl font-black text-[var(--text-color)] tracking-tight">
                {card.value}
              </div>
              <div className="flex items-center gap-2 mt-2 text-xs sm:text-sm">
                <span className="font-semibold text-slate-700 dark:text-[var(--text-color)] flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-[var(--text-muted)]" />
                  {card.change}
                </span>
                <span className="text-[var(--text-muted)] dark:text-[var(--text-muted)] font-light">
                  {card.subtext}
                </span>
              </div>
            </div>
          </TiltCard>
        ))}
      </div>

      {/* Analytics Chart + Circular Compliance Meter */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
        {/* Monthly Activity Chart */}
        <div className="lg:col-span-8 rounded-3xl p-7 sm:p-8 space-y-5 bg-white/40 dark:bg-black/40 backdrop-blur-xl border border-[var(--border-color)] shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[var(--border-color)] gap-3">
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-[var(--text-color)]">Monthly Compliance Activity</h2>
              <p className="text-xs sm:text-sm text-[var(--text-muted)] font-light mt-1">
                Audit volume categorized by statutory compliance status
              </p>
            </div>
            <span className="text-xs font-mono text-[var(--text-color)] px-3 py-1 rounded-full bg-[var(--border-color)] border border-[var(--border-color)] self-start sm:self-auto">
              Period 2026
            </span>
          </div>

          <div className="h-72 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f293d" vertical={false} opacity={0.6} />
                <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(11, 15, 25, 0.95)',
                    borderRadius: '14px',
                    border: '1px solid rgba(255, 255, 255, 0.12)',
                    boxShadow: '0 12px 35px rgba(0,0,0,0.8)',
                    fontSize: '12px',
                    color: '#f8fafc',
                  }}
                  cursor={{ fill: 'rgba(255, 255, 255, 0.02)' }}
                />
                <Bar dataKey="compliant" name="Compliant" fill="#6366f1" radius={[5, 5, 0, 0]} />
                <Bar dataKey="nonCompliant" name="Violations" fill="#f43f5e" radius={[5, 5, 0, 0]} />
                <Bar dataKey="needsReview" name="Review" fill="#64748b" radius={[5, 5, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Circular Compliance Meter */}
        <div className="lg:col-span-4 rounded-3xl p-7 sm:p-8 flex flex-col items-center justify-between text-center space-y-6 bg-white/40 dark:bg-black/40 backdrop-blur-xl border border-[var(--border-color)] shadow-xl">
          <div className="w-full text-left pb-4 border-b border-[var(--border-color)]">
            <h2 className="text-lg sm:text-xl font-bold text-[var(--text-color)]">Overall Compliance</h2>
            <p className="text-xs sm:text-sm text-[var(--text-muted)] font-light mt-1">
              Aggregated pass rate across verified batches
            </p>
          </div>

          <div className="relative w-48 h-48 my-auto flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
              <circle cx="60" cy="60" r="50" fill="none" stroke="#172033" strokeWidth="10" />
              <circle
                cx="60"
                cy="60"
                r="50"
                fill="none"
                stroke="#6366f1"
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={`${(stats.complianceRate / 100) * 314} 314`}
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl sm:text-5xl font-black text-[var(--text-color)] tracking-tight">
                {stats.complianceRate}%
              </span>
              <span className="text-xs font-mono tracking-wider text-indigo-300 mt-1.5 px-3 py-0.5 rounded-full bg-indigo-950/60 border border-indigo-500/30">
                Active Benchmark
              </span>
            </div>
          </div>

          <div className="w-full pt-4 border-t border-[var(--border-color)] text-xs sm:text-sm text-[var(--text-muted)] flex items-center justify-between font-light">
            <span>Statutory Threshold:</span>
            <span className="font-semibold text-[var(--text-color)]">100% Target</span>
          </div>
        </div>
      </div>

      {/* Clean Recent Inspections Table with Larger Typography & Comfortable Row Heights */}
      <div className="moody-card rounded-3xl overflow-hidden shadow-2xl">
        <div className="px-7 py-5 sm:px-8 sm:py-6 border-b border-[var(--border-color)] flex items-center justify-between">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-[var(--text-color)] flex items-center gap-2">
              Action Required Queue
              <span className="bg-rose-500/20 text-rose-600 dark:text-rose-400 text-xs px-2 py-0.5 rounded-full">{stats.needsReview} Pending</span>
            </h2>
            <p className="text-xs sm:text-sm text-[var(--text-muted)] font-light mt-1">
              Violations and audits needing Auditor review
            </p>
          </div>
          <Link
            href="/dashboard/history"
            className="text-xs sm:text-sm font-semibold text-indigo-400 hover:text-indigo-300 inline-flex items-center gap-1.5 transition"
          >
            <span>View Full Archive</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[var(--border-color)] border-b border-[var(--border-color)] text-[var(--text-muted)] font-mono text-xs uppercase tracking-wider">
                <th className="px-7 py-4 font-semibold">Commodity</th>
                <th className="px-7 py-4 font-semibold">Date</th>
                <th className="px-7 py-4 font-semibold">Statutory Status</th>
                <th className="px-7 py-4 font-semibold">Score</th>
                <th className="px-7 py-4 font-semibold">Violations</th>
                <th className="px-7 py-4 font-semibold">Officer</th>
                <th className="px-7 py-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05] text-[var(--text-color)]">
              {stats.recentInspections.map((insp: InspectionData) => {
                const violations = (insp.validationResults || []).filter(
                  (r) => r.status === 'FAIL'
                ).length;

                return (
                  <tr
                    key={insp.inspectionId}
                    className="hover:bg-[var(--border-color)] transition-colors duration-150"
                  >
                    <td className="px-7 py-5">
                      <div className="font-bold text-[var(--text-color)] text-sm sm:text-base">{insp.productName}</div>
                      <div className="font-mono text-xs text-[var(--text-muted)] font-normal mt-0.5">
                        {insp.inspectionId}
                      </div>
                    </td>
                    <td className="px-7 py-5 text-[var(--text-color)] text-xs sm:text-sm whitespace-nowrap font-light">
                      {formatDate(insp.createdAt)}
                    </td>
                    <td className="px-7 py-5 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border ${
                          insp.status === 'COMPLIANT'
                            ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/30'
                            : insp.status === 'NON_COMPLIANT'
                            ? 'bg-rose-950/40 text-rose-300 border-rose-500/30'
                            : 'bg-amber-950/40 text-amber-300 border-amber-500/30'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            insp.status === 'COMPLIANT'
                              ? 'bg-emerald-400'
                              : insp.status === 'NON_COMPLIANT'
                              ? 'bg-rose-400'
                              : 'bg-amber-400'
                          }`}
                        />
                        {insp.status === 'COMPLIANT'
                          ? 'Compliant'
                          : insp.status === 'NON_COMPLIANT'
                          ? 'Violation'
                          : 'Under Review'}
                      </span>
                    </td>
                    <td className="px-7 py-5 font-mono font-bold text-[var(--text-color)] text-sm sm:text-base">
                      {insp.complianceScore}%
                    </td>
                    <td className="px-7 py-5 whitespace-nowrap">
                      {violations > 0 ? (
                        <span className="text-rose-400 text-xs sm:text-sm font-semibold">
                          {violations} Flagged
                        </span>
                      ) : (
                        <span className="text-[var(--text-muted)] text-xs sm:text-sm font-light">
                          0 Deficiencies
                        </span>
                      )}
                    </td>
                    <td className="px-7 py-5 text-[var(--text-color)] text-xs sm:text-sm font-medium">
                      {insp.officerName}
                    </td>
                    <td className="px-7 py-5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        <button className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--text-muted)] hover:text-white transition px-2 py-1.5 rounded-lg hover:bg-white/10">
                          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                          <span>Print</span>
                        </button>
                        <button className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--text-muted)] hover:text-white transition px-2 py-1.5 rounded-lg hover:bg-white/10">
                          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                          <span>Export</span>
                        </button>
                        <Link
                          href={`/dashboard/inspection/${insp.inspectionId}`}
                          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-indigo-400 hover:text-indigo-300 transition group px-3 py-1.5 rounded-lg hover:bg-indigo-500/10 ml-2"
                        >
                          <span>Review</span>
                          <ArrowRight className="w-3.5 h-3.5 text-indigo-400/70 group-hover:translate-x-1.5 transition-transform" />
                        </Link>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
