import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';

export async function POST(req: NextRequest) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    const { imageBase64 } = await req.json();
    
    if (!imageBase64) {
      return NextResponse.json(
        { success: false, error: 'No image provided.' },
        { status: 400 }
      );
    }

    if (!apiKey) {
      console.log('No Gemini API key found. Using Free Public Cloud OCR (OCR.Space Engine 2) fallback.');
      
      try {
        const formData = new FormData();
        formData.append('base64Image', imageBase64);
        formData.append('language', 'eng');
        formData.append('apikey', 'helloworld');
        formData.append('isOverlayRequired', 'false');
        formData.append('OCREngine', '3'); // Engine 3 is specifically trained on handwriting, cursive, and stylized/custom fonts

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);

        const ocrSpaceRes = await fetch('https://api.ocr.space/parse/image', {
          method: 'POST',
          body: formData,
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        
        const ocrData = await ocrSpaceRes.json();
        
        if (ocrData.IsErroredOnProcessing || !ocrData.ParsedResults || ocrData.ParsedResults.length === 0) {
          throw new Error('Public OCR failed');
        }
        
        const rawText = ocrData.ParsedResults[0].ParsedText;
        
        // Return in the format our frontend expects, so labelParser.ts can take over
        return NextResponse.json({ 
          success: true, 
          data: {
            rawText: rawText,
            extractedFields: null, // Let frontend parseLabel handle this
            productName: null
          }
        });
      } catch (err) {
        return NextResponse.json(
          { success: false, error: 'Public Cloud OCR failed. Falling back to local OCR.' },
          { status: 501 }
        );
      }
    }

    // Initialize Gemini SDK
    const ai = new GoogleGenAI({ apiKey });

    // Remove the data URL prefix to get raw base64
    const base64Data = imageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, '');

    const prompt = `You are a Legal Metrology AI Agent. Your task is to extract exact compliance declarations from the provided product packaging image with absolute 100% accuracy (0 mistakes).
    
Extract the following information and output ONLY valid JSON matching this schema:
{
  "rawText": "A complete, perfectly accurate raw transcription of all text visible on the label, preserving newlines.",
  "extractedFields": {
    "mrp": "Maximum Retail Price (e.g., '₹ 25.00' or null)",
    "netQuantity": "Net Weight or Volume (e.g., '200 g' or null)",
    "unitSalePrice": "USP if declared (e.g., '₹ 0.125 / g' or null)",
    "countryOfOrigin": "Country of origin (e.g., 'India' or null)",
    "manufacturerName": "Name of the manufacturer, packer, or marketer (or null)",
    "manufacturerAddress": "Full address of the manufacturer (or null)",
    "manufacturingDate": "Date of manufacturing/packing (or null)",
    "expiryDate": "Best before/expiry date (or null)",
    "consumerCare": "Customer care details like phone/email (or null)",
    "hasTaxInclusion": "Set to 'Yes (Inclusive of all taxes)' if 'inclusive of all taxes' or 'incl. of all taxes' is written, else null",
    "genericName": "Generic name of the commodity if declared (or null)"
  },
  "productName": "The brand name or main product logo text. Only fill this if clearly a brand logo/name."
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inlineData: {
                data: base64Data,
                mimeType: 'image/jpeg',
              },
            },
          ],
        },
      ],
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text;
    if (!responseText) {
        throw new Error("Empty response from Gemini.");
    }
    const data = JSON.parse(responseText);

    return NextResponse.json({ success: true, data });
  } catch (error: any) {
    console.error('Gemini OCR API Error:', error);
    return NextResponse.json(
      { success: false, error: 'Gemini AI failed to process image. Falling back to local OCR.' },
      { status: 500 }
    );
  }
}
