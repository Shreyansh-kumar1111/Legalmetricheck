'use client';

import React, { useEffect, useRef } from 'react';

export const CanvasVortex = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };
    window.addEventListener('resize', resize);

    const lines = 120;
    const ySteps = 40;
    let time = 0;

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      const cx = width / 2;
      ctx.lineWidth = 1;

      for (let i = 0; i < lines; i++) {
        const offset = (i / lines) * Math.PI * 2;
        ctx.beginPath();
        
        for (let j = 0; j <= ySteps; j++) {
          const yNormalized = j / ySteps;
          const y = yNormalized * height;
          const ny = yNormalized * 2 - 1;
          const radius = (ny * ny * ny * ny) * (width * 0.4) + (width * 0.05);
          const angle = time * 1.5 + offset + (ny * 2.5);
          const x = cx + Math.cos(angle) * radius;
          
          let opacity = 0.4;
          if (yNormalized < 0.2) opacity *= (yNormalized / 0.2);
          if (yNormalized > 0.8) opacity *= ((1 - yNormalized) / 0.2);
          
          const zDepth = Math.sin(angle);
          opacity = opacity * (0.5 + (zDepth + 1) * 0.25);

          ctx.strokeStyle = `rgba(255, 255, 255, ${opacity})`;

          if (j === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      }

      time += 0.005;
      requestAnimationFrame(draw);
    };

    draw();

    return () => window.removeEventListener('resize', resize);
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 w-full h-full pointer-events-none z-0 mix-blend-screen opacity-80"
    />
  );
};
