// ============================================================
// LegalMetriCheck — Current User API
// ============================================================

import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ success: false, error: 'Not authenticated' }, { status: 401 });
    }
    return NextResponse.json({ success: true, data: user });
  } catch (error) {
    console.error('Auth check error:', error);
    return NextResponse.json({ success: false, error: 'Auth check failed' }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ success: false, error: 'Not authenticated' }, { status: 401 });
    }

    const data = await req.json();
    const { name, email, department } = data;

    // We will handle the demo user override via cookie if it's a demo user, 
    // but the actual cookie setting has to be done carefully.
    // Wait, setting a cookie in a route handler requires NextResponse.
    const response = NextResponse.json({ success: true, data: { ...user, name, email, department } });

    if (user._id?.startsWith('demo-')) {
      // Set a demo profile override cookie
      const overrideData = JSON.stringify({ name, email, department });
      response.cookies.set('lmc_demo_profile', overrideData, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 60 * 60 * 24 * 7, // 7 days
        path: '/',
      });
      return response;
    }

    // For real users, we would connect to DB and update
    const { connectDB } = require('@/lib/db');
    const User = require('@/models/User').default;
    await connectDB();
    await User.findByIdAndUpdate(user._id, { name, email, department });

    return response;
  } catch (error) {
    console.error('Profile update error:', error);
    return NextResponse.json({ success: false, error: 'Profile update failed' }, { status: 500 });
  }
}
