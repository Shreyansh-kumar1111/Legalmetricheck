'use client';

import React, { useState, useEffect } from 'react';
import { BookOpen, Search, Shield, ShieldCheck, AlertCircle, X, Scale, Sparkles } from 'lucide-react';
import { RuleData } from '@/types';

import { getRuleData } from '@/lib/engine/rules';

export default function RulesPage() {
  const [rules, setRules] = useState<RuleData[]>(getRuleData());
  const [search, setSearch] = useState('');
  const [severityFilter, setSeverityFilter] = useState('ALL');

  const filtered = rules.filter((r) => {
    const matchesSearch =
      r.ruleId.toLowerCase().includes(search.toLowerCase()) ||
      r.name.toLowerCase().includes(search.toLowerCase()) ||
      r.description.toLowerCase().includes(search.toLowerCase());

    const matchesSeverity =
      severityFilter === 'ALL' || r.severity === severityFilter;

    return matchesSearch && matchesSeverity;
  });

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-950/80 text-indigo-300 border border-indigo-700/60 mb-2">
            <Scale className="w-3.5 h-3.5 text-indigo-400" />
            <span>Statutory Regulations</span>
          </div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[var(--text-color)] tracking-tight">
              Legal Metrology Rules
            </h1>
            <span className="text-xs font-bold text-indigo-300 bg-indigo-950/80 border border-indigo-700/60 px-2.5 py-0.5 rounded-full">
              12 Clauses
            </span>
          </div>
          <p className="text-sm text-[var(--text-muted)] mt-1">
            Mandatory declarations under the Legal Metrology (Packaged Commodities) Rules, 2011.
          </p>
        </div>
      </div>

      {/* Advisory Banner — Simple & Light */}
      <div className="bg-[var(--card-bg)] border border-indigo-500/20 rounded-2xl p-5 flex items-center gap-4">
        <div className="w-10 h-10 rounded-xl bg-indigo-600 text-[var(--text-color)] flex items-center justify-center shrink-0 shadow-md shadow-indigo-600/30">
          <Scale className="w-5 h-5" />
        </div>
        <div className="space-y-0.5 text-sm">
          <p className="font-bold text-[var(--text-color)]">Section 18 Statutory Mandate</p>
          <p className="text-[var(--text-color)] text-xs sm:text-sm">
            Packaged commodities distributed in India must display all mandatory declarations to prevent enforcement penalties under Section 36.
          </p>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="p-4 sm:p-5 bg-[var(--card-bg)] rounded-2xl border border-[var(--border-color)] space-y-3">
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="flex-1 w-full max-w-md flex items-center gap-3 px-4 py-2.5 rounded-xl bg-[var(--card-bg)] border border-[var(--border-color)] focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20 transition-all shadow-inner group">
            <Search className="w-4 h-4 text-[var(--text-muted)] group-focus-within:text-indigo-400 shrink-0 pointer-events-none transition-colors" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by rule clause, title, or keyword..."
              className="w-full bg-transparent text-sm font-normal text-[var(--text-color)] placeholder:text-[var(--text-muted)] focus:outline-none leading-normal tracking-wide"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch('')}
                className="text-[var(--text-muted)] hover:text-[var(--text-color)] p-1 transition"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            {[
              { id: 'ALL', label: 'All Clauses' },
              { id: 'HIGH', label: 'High Severity' },
              { id: 'MEDIUM', label: 'Medium' },
              { id: 'LOW', label: 'Low' },
            ].map((sev) => (
              <button
                key={sev.id}
                type="button"
                onClick={() => setSeverityFilter(sev.id)}
                className={`px-3.5 py-2 sm:py-1.5 rounded-xl text-xs sm:text-sm font-semibold border transition cursor-pointer whitespace-nowrap min-h-[38px] ${
                  severityFilter === sev.id
                    ? 'bg-indigo-600 text-[var(--text-color)] border-transparent shadow-sm shadow-indigo-500/25'
                    : 'bg-[var(--card-bg)] text-[var(--text-muted)] border-[var(--border-color)] hover:bg-[var(--card-bg)] hover:text-[var(--text-color)]'
                }`}
              >
                {sev.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Rules Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-[var(--card-bg)] rounded-2xl border border-[var(--border-color)] p-8 space-y-3">
          <BookOpen className="w-10 h-10 text-[var(--text-muted)] mx-auto" />
          <h3 className="text-base font-bold text-[var(--text-color)]">No Rules Found</h3>
          <p className="text-sm text-[var(--text-muted)]">Try adjusting your search query.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((rule) => {
            const isHigh = rule.severity === 'HIGH';
            const isMed = rule.severity === 'MEDIUM';
            return (
              <div
                key={rule.ruleId}
                className="p-5 rounded-2xl bg-[var(--card-bg)] border border-[var(--border-color)] shadow-sm hover:border-indigo-500/30 transition flex flex-col justify-between space-y-3 group"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-indigo-300 bg-indigo-950/80 px-2.5 py-1 rounded-lg border border-indigo-700/60">
                      {rule.referenceText || rule.ruleId}
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                        isHigh
                          ? 'bg-rose-950/60 text-rose-300 border-rose-500/40'
                          : isMed
                          ? 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                          : 'bg-cyan-950/60 text-cyan-300 border-cyan-500/40'
                      }`}
                    >
                      {rule.severity} Severity
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-base text-[var(--text-color)] group-hover:text-indigo-400 transition">
                      {rule.name}
                    </h4>
                    <p className="text-xs sm:text-sm text-[var(--text-color)] mt-1 leading-relaxed">
                      {rule.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
