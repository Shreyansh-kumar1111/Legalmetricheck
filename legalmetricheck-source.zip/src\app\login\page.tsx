'use client';

import React, { useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Brain, Eye, EyeOff, LogIn, Info, UserCheck, ShieldAlert, ArrowRight, Zap, Sparkles } from 'lucide-react';
import { WebGLShader } from '@/components/ui/web-gl-shader';

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passcode, setPasscode] = useState('');
  const [details, setDetails] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState(searchParams?.get('error') || '');
  const [loading, setLoading] = useState(false);

  const isAdmin = email.toLowerCase().includes('admin');

  const executeLogin = async (loginEmail: string, loginPass: string, loginPasscode: string = '', loginDetails: string = '') => {
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail, password: loginPass, passcode: loginPasscode, details: loginDetails }),
      });

      const data = await res.json();

      if (data.success) {
        window.location.href = '/dashboard';
      } else {
        setError(data.error || 'Login failed. Please check your credentials.');
      }
    } catch {
      setError('Unable to connect. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    await executeLogin(email, password, passcode, details);
  };

  const handleQuickLogin = (role: 'officer' | 'auditor' | 'admin') => {
    let creds;
    if (role === 'officer') creds = { email: 'officer@legalmetri.demo', pass: 'Demo@123', details: 'Emp-4421' };
    else if (role === 'auditor') creds = { email: 'auditor@legalmetri.demo', pass: 'Demo@123', details: 'Aud-9902' };
    else creds = { email: 'admin@legalmetri.demo', pass: 'Admin@123', passcode: '8899' };
    
    setEmail(creds.email);
    setPassword(creds.pass);
    if (creds.passcode) setPasscode(creds.passcode);
    if (creds.details) setDetails(creds.details);
    
    executeLogin(creds.email, creds.pass, creds.passcode, creds.details);
  };

  return (
    <div className="min-h-[100dvh] flex flex-col justify-center items-center py-6 px-4 sm:p-6 selection:bg-indigo-600 selection:text-white font-sans relative overflow-hidden">
      {/* WebGL Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <WebGLShader distortion={0.03} xScale={0.8} yScale={0.4} />
      </div>
      <div className="fixed inset-0 bg-radial from-transparent via-black/50 to-[#09090b]/95 pointer-events-none z-[1]" />

      {/* Brand Header */}
      <Link href="/" className="mb-5 sm:mb-6 flex items-center gap-3 group relative z-10">
        <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-cyan-500 flex items-center justify-center text-white shadow-xl shadow-indigo-500/25 group-hover:scale-105 transition-transform">
          <Brain className="w-6 h-6" />
        </div>
        <div className="text-left">
          <span className="font-extrabold text-2xl tracking-tight text-white block">
            LegalMetri<span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">Check</span>
          </span>
          <span className="text-[11px] uppercase font-bold tracking-widest text-slate-400 block">
            Compliance Officer Portal
          </span>
        </div>
      </Link>

      <div className="w-full max-w-md px-1 sm:px-0 relative z-10">
        {/* Main Dark Card */}
        <div className="bg-[#0B0F19]/90 backdrop-blur-xl rounded-2xl sm:rounded-3xl border border-white/10 p-5 sm:p-7 md:p-8 shadow-2xl shadow-indigo-500/10 space-y-5 sm:space-y-6">
          <div className="space-y-1.5 text-center">
            <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight">
              Officer Sign In
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Pick a 1-click test profile or sign in with your credentials
            </p>
          </div>

          {error && (
            <div className="p-3.5 sm:p-4 rounded-2xl bg-rose-950/80 border border-rose-500/40 text-rose-300 text-xs sm:text-sm font-semibold flex items-center gap-2.5">
              <ShieldAlert className="w-5 h-5 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {/* 1-Click Test Access Cards */}
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-indigo-400">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>1-Click Hackathon Access</span>
            </div>

            <button
              type="button"
              onClick={() => handleQuickLogin('officer')}
              disabled={loading}
              className="w-full p-3.5 sm:p-4 rounded-2xl border-2 border-indigo-900/60 bg-gradient-to-r from-indigo-950/60 to-purple-950/40 hover:border-indigo-500 hover:shadow-lg hover:shadow-indigo-500/20 transition-all text-left flex items-center justify-between group cursor-pointer min-h-[52px] active:scale-[0.99]"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center font-bold text-sm shadow-md shadow-indigo-500/20 shrink-0">
                  RK
                </div>
                <div>
                  <span className="font-extrabold text-xs sm:text-sm text-white group-hover:text-indigo-300 block transition">
                    Inspector Rajesh Kumar
                  </span>
                  <span className="text-[11px] sm:text-xs text-slate-400 block">
                    Senior Field Officer · Legal Metrology
                  </span>
                </div>
              </div>
              <span className="text-xs font-bold text-indigo-300 bg-indigo-900/80 px-2.5 py-1 rounded-lg border border-indigo-700/60 group-hover:bg-indigo-600 group-hover:text-white transition shrink-0 ml-2">
                Enter →
              </span>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('auditor')}
              disabled={loading}
              className="w-full p-3.5 sm:p-4 rounded-2xl border-2 border-purple-900/60 bg-gradient-to-r from-purple-950/60 to-pink-950/40 hover:border-purple-500 hover:shadow-lg hover:shadow-purple-500/20 transition-all text-left flex items-center justify-between group cursor-pointer min-h-[52px] active:scale-[0.99]"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 to-pink-600 text-white flex items-center justify-center font-bold text-sm shadow-md shadow-purple-500/20 shrink-0">
                  SS
                </div>
                <div>
                  <span className="font-extrabold text-xs sm:text-sm text-white group-hover:text-purple-300 block transition">
                    Auditor Sunita Sharma
                  </span>
                  <span className="text-[11px] sm:text-xs text-slate-400 block">
                    Quality & Legal Cell Lead
                  </span>
                </div>
              </div>
              <span className="text-xs font-bold text-purple-300 bg-purple-900/80 px-2.5 py-1 rounded-lg border border-purple-700/60 group-hover:bg-purple-600 group-hover:text-white transition shrink-0 ml-2">
                Enter →
              </span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex-1 border-t border-white/10" />
            <span className="text-[11px] sm:text-xs text-slate-500 font-bold uppercase tracking-wider">or sign in with email</span>
            <div className="flex-1 border-t border-white/10" />
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                Email
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="officer@legalmetri.demo"
                required
                className="w-full px-4 py-3.5 sm:py-3 rounded-xl border border-white/10 text-white text-base sm:text-sm placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/20 transition bg-slate-900/80 focus:bg-slate-900"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full px-4 py-3.5 sm:py-3 rounded-xl border border-white/10 text-white text-base sm:text-sm placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/20 transition pr-12 bg-slate-900/80 focus:bg-slate-900"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-2"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {isAdmin ? (
              <div>
                <label htmlFor="passcode" className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Admin Passcode
                </label>
                <input
                  id="passcode"
                  type="password"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  placeholder="Enter 4-digit passcode"
                  required
                  className="w-full px-4 py-3.5 sm:py-3 rounded-xl border border-white/10 text-white text-base sm:text-sm placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/20 transition bg-slate-900/80 focus:bg-slate-900"
                />
              </div>
            ) : (
              <div>
                <label htmlFor="details" className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Employee Details
                </label>
                <input
                  id="details"
                  type="text"
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="Enter employee ID or details"
                  required
                  className="w-full px-4 py-3.5 sm:py-3 rounded-xl border border-white/10 text-white text-base sm:text-sm placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/20 transition bg-slate-900/80 focus:bg-slate-900"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl text-sm sm:text-base font-bold text-white bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 hover:opacity-95 shadow-lg shadow-indigo-500/25 transition-all cursor-pointer disabled:opacity-60 min-h-[48px] active:scale-[0.99]"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  <span>Sign In</span>
                </>
              )}
            </button>
          </form>
        </div>

        <div className="mt-8 text-center text-xs text-slate-400">
          <Link href="/" className="hover:text-white transition inline-flex items-center gap-1 font-semibold">
            <span>← Back to Public Portal</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center text-white">Loading...</div>}>
      <LoginForm />
    </Suspense>
  );
}
