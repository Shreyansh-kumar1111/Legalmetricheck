// ============================================================
// LegalMetriCheck — Compliance Rule Definitions
// ============================================================
// These are configurable validation checks, NOT official legal determinations.
// Rules can be extended, modified, or replaced as requirements evolve.

import { ExtractedFields, RuleDefinition, ValidationCheckResult, RuleData } from '@/types';

function createCheck(
  rule: Omit<RuleDefinition, 'validate'>,
  detectedValue: string | null,
  passed: boolean,
  message?: string
): ValidationCheckResult {
  return {
    ruleId: rule.ruleId,
    ruleName: rule.name,
    field: rule.field,
    status: passed ? 'PASS' : 'FAIL',
    detectedValue: detectedValue,
    expectedCondition: rule.description,
    message: message || (passed ? `${rule.name}: Detected` : `${rule.name}: Not found or invalid`),
    severity: rule.severity,
  };
}

function extractStringVal(value: any): string | null {
  if (value === null || value === undefined) return null;
  if (typeof value === 'object') {
    if ('value' in value && typeof value.value === 'string') {
      return value.value;
    }
    if ('value' in value && value.value === null) {
      return null;
    }
  }
  return typeof value === 'string' ? value : String(value);
}

function isPresent(value: any): boolean {
  const str = extractStringVal(value);
  return !!str && str.trim().length > 0;
}

export const DEFAULT_RULES: RuleDefinition[] = [
  {
    ruleId: 'LM-001',
    name: 'MRP Declaration',
    description: 'Maximum Retail Price (MRP) must be declared on the package.',
    category: 'MANDATORY_DECLARATION',
    severity: 'HIGH',
    field: 'mrp',
    isActive: true,
    referenceText: 'Rule 6(1)(d) — Every package shall bear the retail sale price.',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.mrp);
      return createCheck(DEFAULT_RULES[0], val, isPresent(val),
        isPresent(val) ? `MRP detected: ${val}` : 'MRP not found on label');
    },
  },
  {
    ruleId: 'LM-002',
    name: 'Net Quantity Declaration',
    description: 'Net quantity must be declared on the package.',
    category: 'MANDATORY_DECLARATION',
    severity: 'HIGH',
    field: 'netQuantity',
    isActive: true,
    referenceText: 'Rule 6(1)(b) — Every package shall bear the net quantity.',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.netQuantity);
      return createCheck(DEFAULT_RULES[1], val, isPresent(val),
        isPresent(val) ? `Net quantity detected: ${val}` : 'Net quantity not found on label');
    },
  },
  {
    ruleId: 'LM-003',
    name: 'Manufacturer/Packer Name',
    description: 'Name of the manufacturer or packer must be declared.',
    category: 'MANDATORY_DECLARATION',
    severity: 'HIGH',
    field: 'manufacturerName',
    isActive: true,
    referenceText: 'Rule 6(1)(a) — Name and address of the manufacturer/packer/importer.',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.manufacturerName);
      return createCheck(DEFAULT_RULES[2], val, isPresent(val),
        isPresent(val) ? `Manufacturer name detected: ${val}` : 'Manufacturer/packer name not found');
    },
  },
  {
    ruleId: 'LM-004',
    name: 'Manufacturer/Packer Address',
    description: 'Address of the manufacturer or packer must be declared.',
    category: 'MANDATORY_DECLARATION',
    severity: 'HIGH',
    field: 'manufacturerAddress',
    isActive: true,
    referenceText: 'Rule 6(1)(a) — Name and address of the manufacturer/packer/importer.',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.manufacturerAddress);
      return createCheck(DEFAULT_RULES[3], val, isPresent(val),
        isPresent(val) ? `Manufacturer address detected: ${val}` : 'Manufacturer/packer address not found');
    },
  },
  {
    ruleId: 'LM-005',
    name: 'Manufacturing/Packing Date',
    description: 'Date of manufacturing or packing must be declared.',
    category: 'MANDATORY_DECLARATION',
    severity: 'HIGH',
    field: 'manufacturingDate',
    isActive: true,
    referenceText: 'Rule 6(1)(e) — Date of manufacture/packing/import shall be mentioned.',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.manufacturingDate);
      return createCheck(DEFAULT_RULES[4], val, isPresent(val),
        isPresent(val) ? `Manufacturing date detected: ${val}` : 'Manufacturing/packing date not found');
    },
  },
  {
    ruleId: 'LM-006',
    name: 'Consumer Care Details',
    description: 'Consumer care / helpline details must be declared.',
    category: 'MANDATORY_DECLARATION',
    severity: 'MEDIUM',
    field: 'consumerCare',
    isActive: true,
    referenceText: 'Rule 6(2) — Consumer complaints contact details.',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.consumerCare);
      return createCheck(DEFAULT_RULES[5], val, isPresent(val),
        isPresent(val) ? `Consumer care info detected: ${val}` : 'Consumer care details not found');
    },
  },
  {
    ruleId: 'LM-007',
    name: 'MRP Format Validation',
    description: 'MRP should follow a recognizable currency/value pattern (e.g., ₹50, Rs. 120.00).',
    category: 'FORMAT_VALIDATION',
    severity: 'MEDIUM',
    field: 'mrp',
    isActive: true,
    referenceText: 'Format check — MRP value should be a valid currency amount.',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.mrp);
      if (!isPresent(val)) {
        return createCheck(DEFAULT_RULES[6], val, false, 'MRP not present, cannot validate format');
      }
      const pattern = /\d+(\.\d{1,2})?/;
      const passed = pattern.test(val!);
      return createCheck(DEFAULT_RULES[6], val, passed,
        passed ? `MRP format is valid: ${val}` : `MRP format may be invalid: ${val}`);
    },
  },
  {
    ruleId: 'LM-008',
    name: 'Net Quantity Format Validation',
    description: 'Net quantity should contain a numerical value with a recognized unit (g, kg, ml, L, etc.).',
    category: 'FORMAT_VALIDATION',
    severity: 'MEDIUM',
    field: 'netQuantity',
    isActive: true,
    referenceText: 'Format check — Net quantity should include a number and standard unit.',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.netQuantity);
      if (!isPresent(val)) {
        return createCheck(DEFAULT_RULES[7], val, false, 'Net quantity not present, cannot validate format');
      }
      const pattern = /\d+[\d,.]*\s*(?:g|gm|gms|gram|grams|kg|kgs|kilogram|ml|mL|millilitre|l|L|litre|liter|oz|pieces?|pcs|nos|units?)/i;
      const passed = pattern.test(val!);
      return createCheck(DEFAULT_RULES[7], val, passed,
        passed ? `Net quantity format valid: ${val}` : `Net quantity format may be invalid: ${val}`);
    },
  },
  {
    ruleId: 'LM-009',
    name: 'Unit Sale Price (USP) Declaration',
    description: 'Unit Sale Price must be declared per g, per ml, per kg, or per unit for packages > 1g/1ml/1piece.',
    category: 'MANDATORY_DECLARATION',
    severity: 'HIGH',
    field: 'unitSalePrice',
    isActive: true,
    referenceText: 'Rule 6(1)(da) — Unit Sale Price mandatory for pre-packaged commodities (2021/2022 Amendment).',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.unitSalePrice);
      return createCheck(DEFAULT_RULES[8], val, isPresent(val),
        isPresent(val) ? `Unit Sale Price detected: ${val}` : 'Unit Sale Price (USP) not found on label');
    },
  },
  {
    ruleId: 'LM-010',
    name: 'Country of Origin Declaration',
    description: 'Country of Origin or Manufacture must be clearly declared on the package.',
    category: 'MANDATORY_DECLARATION',
    severity: 'HIGH',
    field: 'countryOfOrigin',
    isActive: true,
    referenceText: 'Rule 6(1)(aa) — Every package shall state the name of the country of origin.',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.countryOfOrigin);
      return createCheck(DEFAULT_RULES[9], val, isPresent(val),
        isPresent(val) ? `Country of Origin declared: ${val}` : 'Country of Origin not found on package label');
    },
  },
  {
    ruleId: 'LM-011',
    name: 'Best Before / Expiry Declaration',
    description: 'Best before or expiry date must be declared for food, cosmetic, and perishable packaged commodities.',
    category: 'MANDATORY_DECLARATION',
    severity: 'MEDIUM',
    field: 'expiryDate',
    isActive: true,
    referenceText: 'Rule 6(1)(f) — Best before, expiry, or use-by date must be mentioned.',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.expiryDate);
      return createCheck(DEFAULT_RULES[10], val, isPresent(val),
        isPresent(val) ? `Expiry / Best Before detected: ${val}` : 'Expiry or Best Before declaration not found');
    },
  },
  {
    ruleId: 'LM-012',
    name: 'Tax Inclusion Clause on MRP',
    description: 'The retail sale price must explicitly state "inclusive of all taxes" or "incl. of all taxes".',
    category: 'CONTENT_VALIDATION',
    severity: 'LOW',
    field: 'hasTaxInclusion',
    isActive: true,
    referenceText: 'Rule 6(3) — Maximum retail price shall include words "inclusive of all taxes".',
    validate: (fields: ExtractedFields) => {
      const val = extractStringVal(fields.hasTaxInclusion);
      const isCompliant = isPresent(val) || (typeof fields.mrp === 'string' && /incl/i.test(fields.mrp));
      return createCheck(DEFAULT_RULES[11], val || 'Present', isCompliant,
        isCompliant ? 'Tax inclusion clause declared on MRP' : 'MRP does not explicitly declare "inclusive of all taxes"');
    },
  },
];

export function getRuleData(): RuleData[] {
  return DEFAULT_RULES.map(r => ({
    ruleId: r.ruleId,
    name: r.name,
    description: r.description,
    category: r.category,
    severity: r.severity,
    field: r.field,
    isActive: r.isActive,
    referenceText: r.referenceText,
  }));
}
