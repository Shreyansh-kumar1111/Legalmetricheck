// ============================================================
// LegalMetriCheck — Dashboard Stats API
// ============================================================

import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Inspection from '@/models/Inspection';
import { getDemoStats } from '@/lib/demoData';

export async function GET() {
  try {
    try {
      await connectDB();
      const total = await Inspection.countDocuments();

      if (total === 0) {
        return NextResponse.json({ success: true, data: getDemoStats() });
      }

      const compliant = await Inspection.countDocuments({ status: 'COMPLIANT' });
      const nonCompliant = await Inspection.countDocuments({ status: 'NON_COMPLIANT' });
      const needsReview = await Inspection.countDocuments({ status: 'NEEDS_REVIEW' });

      const recentInspections = await Inspection.find()
        .sort({ createdAt: -1 })
        .limit(10)
        .lean();

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const mapped = recentInspections.map((i: any) => ({ ...i, _id: i._id.toString() }));

      return NextResponse.json({
        success: true,
        data: {
          total,
          compliant,
          nonCompliant,
          needsReview,
          complianceRate: total > 0 ? Math.round((compliant / total) * 100) : 0,
          recentInspections: mapped,
          monthlyData: getDemoStats().monthlyData,
        },
      });
    } catch {
      return NextResponse.json({ success: true, data: getDemoStats() });
    }
  } catch (error) {
    console.error('Stats error:', error);
    return NextResponse.json({ success: true, data: getDemoStats() });
  }
}
