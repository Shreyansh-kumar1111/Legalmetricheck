export const FAMOUS_BRANDS = [
  // --- SNACKS & BISCUITS ---
  "Lays", "Lay's", "Kurkure", "Doritos", "Cheetos", "Pringles", "Bingo", "Haldiram", 
  "Haldiram's", "Bikano", "Balaji", "Britannia", "Parle", "Parle-G", "Sunfeast", 
  "Oreo", "Monaco", "Krackjack", "Hide & Seek", "Good Day", "Marie Gold", "Bourbon",
  "Priyagold", "Duke's", "Bisk Farm", "Cremica", "Unibic", "Yellow Diamond", "Makhan",
  "Crax", "Natkhat", "Prataap Snacks", "Gopal",
  
  // --- CHOCOLATES & SWEETS ---
  "Cadbury", "Dairy Milk", "5 Star", "KitKat", "Kit Kat", "Munch", "Perk", "Snickers",
  "Milkybar", "Gems", "Amul", "Ferrero Rocher", "Kinder", "Toblerone", "Hershey's",
  "Mars", "Bounty", "Twix", "Campco", "Lotte", "Choco Pie", "Center Fresh", "Mentos",
  "Happydent", "Tic Tac", "Polo", "Kismi", "Pulse", "Melody", "Mango Bite", "Kaccha Mango Bite",
  
  // --- BEVERAGES (Cold & Hot) ---
  "Coca-Cola", "Coke", "Pepsi", "Sprite", "7UP", "Thums Up", "Fanta", "Mirinda",
  "Mountain Dew", "Maaza", "Slice", "Frooti", "Paper Boat", "Tropicana", "Real",
  "Red Bull", "Sting", "Monster", "Nescafe", "Bru", "Tata Tea", "Brooke Bond", 
  "Red Label", "Taj Mahal", "Lipton", "Tetley", "Bournvita", "Horlicks", "Complan",
  "Boost", "Milo", "Rooh Afza", "Mapro", "Mala's", "Kissan", "B Natural", "Appy",
  "Appy Fizz", "Catch", "Bisleri", "Kinley", "Aquafina", "Bailley",
  
  // --- DAIRY & ICE CREAM ---
  "Amul", "Mother Dairy", "Nandini", "Kwality Wall's", "Vadilal", "Baskin Robbins",
  "Magnum", "Govardhan", "Milky Mist", "Epigamia", "Danone", "Aavin", "Milma", "Sudha",
  "Saras", "Verka", "Vita", "Sanchi", "Heritage", "Jersey", "Arun", "Dinshaw's", "Havmor",
  "Gowardhan", "Chitale Dairy", "Parag", "Gyan",
  
  // --- STAPLES & PACKAGED FOOD (FMCG) ---
  "Maggi", "Yippee", "Top Ramen", "Knorr", "Ching's", "Aashirvaad", "Fortune",
  "Patanjali", "Tata Salt", "Saffola", "Dhara", "India Gate", "Kohinoor", "Daawat",
  "MTR", "Gits", "Suhana", "Everest", "MDH", "Catch", "Smith & Jones", "Pillsbury",
  "Nature Fresh", "Gemini", "Swaad", "Annapurna", "Chakki Gold", "Patanjali", "Baidyanath",
  "Dabur", "Chyawanprash", "Hajmola", "Safal", "Veeba", "FunFoods", "Dr. Oetker", 
  "Nutella", "Pintola", "MyFitness", "Sundrop", "Nutrela", "Soya Bari", "Pillsbury",
  "Betty Crocker", "Weikfield", "Catch", "Badshah", "Ramdev", "Pravin", "Nilon's", "Mother's Recipe",
  
  // --- PERSONAL CARE & HYGIENE ---
  "Dove", "Pears", "Lux", "Lifebuoy", "Dettol", "Cinthol", "Santoor", "Fiama",
  "Head & Shoulders", "Clinic Plus", "Sunsilk", "Pantene", "TRESemme", "Garnier",
  "L'Oreal", "Nivea", "Pond's", "Olay", "Fair & Lovely", "Glow & Lovely", 
  "Himalaya", "Colgate", "Pepsodent", "Sensodyne", "Close Up", "Oral-B",
  "Gillette", "Old Spice", "Axe", "Wild Stone", "Engage", "Fogg", "Denver", "Park Avenue",
  "Set Wet", "Biotique", "Lotus Herbals", "Mamaearth", "WOW Skin Science", "Plum", "Nykaa",
  "Sugar Cosmetics", "Lakme", "Colorbar", "Maybelline", "Revlon", "MAC", "Envy", "Yardley",
  "Vicco", "Medimix", "Hamam", "Margo", "Chandrika", "Savlon", "Whisper", "Stayfree", "Kotex", "Sofy",
  
  // --- CLEANING & HOME ---
  "Surf Excel", "Tide", "Ariel", "Rin", "Wheel", "Nirma", "Vim", "Pril",
  "Lizol", "Harpic", "Colin", "Domex", "Odonil", "Godrej", "Hit", "Mortein",
  "All Out", "Good Knight", "Maxo", "Comfort", "Ezee", "Genteel", "Ujala", "OxiClean",
  "Vanish", "Trix", "Exo", "Scotch-Brite", "Kiwi", "Cherry Blossom",
  
  // --- MEDICAL, PHARMA & HEALTHCARE ---
  "Cipla", "Sun Pharma", "Dr. Reddy's", "Lupin", "Aurobindo", "Zydus", "Cadila",
  "Torrent Pharma", "Alkem", "Glenmark", "Mankind", "Abbott", "GSK", "GlaxoSmithKline",
  "Pfizer", "Novartis", "Sanofi", "AstraZeneca", "Johnson & Johnson", "Bayer", "Roche",
  "Vicks", "Zandu", "Iodex", "Moov", "Volini", "Amrutanjan", "D'Cold", "Crocin",
  "Paracetamol", "Dolo", "Combiflam", "Saridon", "Digene", "Gelusil", "Eno", "Pudin Hara",
  "ORS", "Electral", "Revital", "Supradyn", "Becosules", "Shelcal", "Ostocalcium",
  "B-Tex", "Itch Guard", "Ring Guard", "Kril", "Relispray", "Boroline", "BoroPlus",
  "Betadine", "Soframycin", "Neosporin", "Candid", "Sebamed", "Cetaphil", "Hansaplast",
  "Band-Aid", "Vissco", "Tynor", "Omron", "Accu-Chek", "Dr. Morepen", "Hicks",
  "Volini", "Omnigel", "Zandu Balm", "Tiger Balm",
  
  // --- MISC / ELECTRONICS / STATIONERY ---
  "ITC", "HUL", "Nestle", "Samsung", "LG", "Sony", "Panasonic", "Whirlpool", "Godrej",
  "Haier", "Voltas", "Blue Star", "Havells", "Bajaj", "Crompton", "Philips", "Syska",
  "Usha", "Orient", "V-Guard", "Luminous", "Microtek", "Exide", "Amara Raja",
  "Classmate", "Navneet", "Camel", "Camlin", "Faber-Castell", "Doms", "Nataraj", "Apsara",
  "Reynolds", "Cello", "Linc", "Pentel", "Parker", "Waterman", "Pierre Cardin"
];

/**
 * Searches raw OCR text for any famous brand.
 * Returns the matched brand name, or empty string if none is found.
 */
export function identifyFamousBrand(rawText: string): string {
  if (!rawText) return "";
  
  // Normalize text for easier searching
  const normalizedText = rawText.toLowerCase().replace(/\s+/g, ' ');
  
  // Sort by length descending so "Mother Dairy" matches before "Mother"
  const sortedBrands = [...FAMOUS_BRANDS].sort((a, b) => b.length - a.length);
  
  for (const brand of sortedBrands) {
    // Create a boundary regex to match whole words/phrases
    const regex = new RegExp(`\\b${brand.toLowerCase().replace(/[.*+?^$\{}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (regex.test(normalizedText)) {
      return brand; // Return the properly capitalized famous brand name
    }
  }
  
  return "";
}
