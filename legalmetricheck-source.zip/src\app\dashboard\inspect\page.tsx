'use client';

import React, { useState, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  Upload,
  Image as ImageIcon,
  CheckCircle2,
  Loader2,
  AlertCircle,
  ScanLine,
  FileCheck,
  RotateCcw,
  Sparkles,
  ShieldAlert,
  ArrowRight,
  ShieldCheck,
  Zap,
  Camera,
  Check,
  XCircle,
} from 'lucide-react';
import { ExtractedFields, ValidationResult } from '@/types';
import { extractTextFromImage } from '@/lib/ocr/tesseract';
import { parseLabel } from '@/lib/parser/labelParser';
import { validateProduct } from '@/lib/engine/validator';
import { identifyFamousBrand } from '@/lib/data/brands';

const parseQuantity = (str: string | null) => {
  if (!str) return { val: '', unit: 'g' };
  const match = str.match(/^([\d.,]+)\s*([a-zA-Z]+)?$/);
  if (match) {
    const parsedUnit = match[2] ? match[2].toLowerCase() : 'g';
    return { 
      val: match[1], 
      unit: ['g', 'kg', 'ml', 'l', 'l', 'pieces', 'pcs'].includes(parsedUnit) ? (parsedUnit === 'l' ? 'l' : parsedUnit) : 'g' 
    };
  }
  const val = str.replace(/[a-zA-Z]/g, '').trim();
  const rawUnit = str.replace(/[\d.,\s]/g, '').toLowerCase();
  const unit = ['g', 'kg', 'ml', 'l'].includes(rawUnit) ? rawUnit : 'g';
  return { val, unit };
};

const compressImage = (file: File, maxWidth = 1200, quality = 0.75): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        if (width > maxWidth) {
          height = Math.round((maxWidth / width) * height);
          width = maxWidth;
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(event.target?.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = (e) => reject(e);
    };
    reader.onerror = (e) => reject(e);
  });
};

type Step = 'upload' | 'processing' | 'review' | 'result';

const PRESET_SAMPLES = [
  {
    title: 'Parle-G Gold Biscuits',
    subtitle: '200g Pack · Complete Declarations',
    badge: '100% Compliant',
    badgeColor: 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40',
    border: 'border-emerald-500/30 hover:border-emerald-500/60',
    productName: 'Parle-G Gold Biscuits 200g',
    ocrText: `Parle-G Gold Biscuits\nNet Qty: 200 g\nMRP Rs. 25.00 (incl. of all taxes)\nUnit Sale Price: Rs. 0.125 / g\nMfg. by: Parle Products Pvt. Ltd.\nRegd. Office: Vile Parle East, Mumbai, Maharashtra 400057\nDate of Mfg: 12/01/2026\nBest Before: 12/07/2026\nCountry of Origin: India\nConsumer Care: 1800-22-7788 | care@parle.biz`,
    fields: {
      mrp: '₹25.00',
      netQuantity: '200 g',
      unitSalePrice: '₹ 0.125 / g',
      countryOfOrigin: 'India',
      manufacturerName: 'Parle Products Pvt. Ltd.',
      manufacturerAddress: 'Vile Parle East, Mumbai, Maharashtra 400057',
      manufacturingDate: '12/01/2026',
      expiryDate: '12/07/2026',
      consumerCare: '1800-22-7788 | care@parle.biz',
      hasTaxInclusion: 'Yes (Inclusive of all taxes)',
    },
  },
  {
    title: 'Lays Classic Salted Chips',
    subtitle: '52g Pack · Missing Address & Unit Price',
    badge: 'Violations (67%)',
    badgeColor: 'bg-rose-950/80 text-rose-300 border-rose-500/40',
    border: 'border-rose-500/30 hover:border-rose-500/60',
    productName: 'Lays Classic Salted Potato Chips 52g',
    ocrText: `Lays Classic Salted\nNet Wt: 52 g\nMRP Rs. 20 (incl. of all taxes)\nManufactured by: PepsiCo India Holdings Pvt Ltd\nMfg Date: 18/02/2026\nExpiry: Best before 4 months\nCountry of Origin: India\nCustomer Care: 1800-22-4020`,
    fields: {
      mrp: '₹20.00',
      netQuantity: '52 g',
      unitSalePrice: null,
      countryOfOrigin: 'India',
      manufacturerName: 'PepsiCo India Holdings Pvt Ltd',
      manufacturerAddress: null,
      manufacturingDate: '18/02/2026',
      expiryDate: 'Best before 4 months',
      consumerCare: '1800-22-4020',
      hasTaxInclusion: 'Yes (Inclusive of all taxes)',
    },
  },
  {
    title: 'Ayur Herbal Face Cream',
    subtitle: '50g Jar · Missing Origin & Care',
    badge: 'Needs Review',
    badgeColor: 'bg-amber-950/80 text-amber-300 border-amber-500/40',
    border: 'border-amber-500/30 hover:border-amber-500/60',
    productName: 'Ayur Herbals Sandal Face Cream 50g',
    ocrText: `Ayur Herbals Sandal Cream\nNet Wt: 50 g\nMRP: Rs. 85.00\nUnit Sale Price: Rs. 1.70 / g\nMfg by: Three-N-Products Pvt Ltd\nAddress: 2/42 Industrial Area, Solan, HP 173211\nMfg Date: 05/01/2026\nBest Before: 24 months from mfg`,
    fields: {
      mrp: '₹85.00',
      netQuantity: '50 g',
      unitSalePrice: '₹ 1.70 / g',
      countryOfOrigin: null,
      manufacturerName: 'Three-N-Products Pvt Ltd',
      manufacturerAddress: '2/42 Industrial Area, Solan, HP 173211',
      manufacturingDate: '05/01/2026',
      expiryDate: '24 months from mfg',
      consumerCare: null,
      hasTaxInclusion: null,
    },
  },
  {
    title: 'Haldiram Nagpur Aloo Bhujia',
    subtitle: '150g Pouch · Complete Declarations',
    badge: '100% Compliant',
    badgeColor: 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40',
    border: 'border-emerald-500/30 hover:border-emerald-500/60',
    productName: 'Haldirams Nagpur Aloo Bhujia 150g',
    ocrText: `Haldirams Nagpur Aloo Bhujia\nNet Qty: 150 g\nMRP: Rs. 40.00 (incl. of all taxes)\nUnit Sale Price: Rs. 0.26 / g\nCountry of Origin: India\nMfg by: Haldiram Foods International Pvt Ltd\nAddress: Plot 145/146, MIDC, Nagpur, Maharashtra 440028\nPacked on: 22/02/2026\nBest Before: 6 months from packaging\nConsumer Helpline: 0712-2779451, feedback@haldirams.com`,
    fields: {
      mrp: '₹40.00',
      netQuantity: '150 g',
      unitSalePrice: '₹ 0.26 / g',
      countryOfOrigin: 'India',
      manufacturerName: 'Haldiram Foods International Pvt Ltd',
      manufacturerAddress: 'Plot 145/146, MIDC, Nagpur, Maharashtra 440028',
      manufacturingDate: '22/02/2026',
      expiryDate: '6 months from packaging',
      consumerCare: '0712-2779451, feedback@haldirams.com',
      hasTaxInclusion: 'Yes (Inclusive of all taxes)',
    },
  },
];

export default function NewInspectionPage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [step, setStep] = useState<Step>('upload');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string>('');
  const [ocrText, setOcrText] = useState('');
  const [ocrProgress, setOcrProgress] = useState(0);
  const [ocrStatus, setOcrStatus] = useState('');
  const [extractedFields, setExtractedFields] = useState<ExtractedFields>({
    mrp: null,
    netQuantity: null,
    manufacturerName: null,
    manufacturerAddress: null,
    manufacturingDate: null,
    consumerCare: null,
  });
  const [productName, setProductName] = useState('');
  const [manualMode, setManualMode] = useState(false);
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [dragOver, setDragOver] = useState(false);

  const handleFileSelect = useCallback(async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file (JPG, PNG, WEBP)');
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      setError('Image must be less than 15 MB');
      return;
    }

    setError('');
    setStep('processing');

    try {
      setOcrStatus('Optimizing image for fast transmission...');
      const dataUrl = await compressImage(file, 1200, 0.75);
      
      setImagePreview(dataUrl);
      setImageBase64(dataUrl);

      setOcrStatus('Calling Cloud AI for 0-Mistake Analysis...');
      setOcrProgress(50);
      
      let apiSuccess = false;
      try {
        const res = await fetch('/api/ocr', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ imageBase64: dataUrl })
        });
        
        if (res.ok) {
          const result = await res.json();
          if (result.success && result.data) {
            const rawText = result.data.rawText || '';
            setOcrText(rawText);
            
            // Ensure we merge default fields with what Gemini found
            const parsedFields = result.data.extractedFields || {};
            setExtractedFields((prev) => ({
              ...prev,
              ...parsedFields
            }));
            
            const famousBrand = identifyFamousBrand(rawText);
            if (famousBrand) {
              setProductName(famousBrand);
            } else {
              setProductName(''); // Force user to enter underrated/unknown brands manually
            }
            
            setOcrProgress(100);
            setOcrStatus('Analysis Complete');
            apiSuccess = true;
          }
        }
      } catch (apiErr) {
        console.log("Cloud OCR failed or unavailable, falling back to local OCR");
      }

      // --- FALLBACK TO LOCAL TESSERACT OCR ---
      if (!apiSuccess) {
        setOcrStatus('Scanning label geometry (Local Mode)...');
        const result = await extractTextFromImage(file, (progress, statusText) => {
          setOcrProgress(progress);
          setOcrStatus(statusText);
        });

        const text = result.text;
        setOcrText(text);

        setOcrStatus('Reading declarations...');
        const parsed = parseLabel(text);
        setExtractedFields(parsed);

        const famousBrand = identifyFamousBrand(text);
        if (famousBrand) {
          setProductName(famousBrand);
        } else {
          setProductName(''); // Force manual input for unknown brands
        }
      }

      setStep('review');
    } catch (err: any) {
      console.error('OCR failure:', err);
      setError('OCR scanning encountered an issue. You can verify and fill fields manually.');
      setManualMode(true);
      setStep('review');
    }
  }, [productName]);

  const handlePresetSelect = (preset: typeof PRESET_SAMPLES[0]) => {
    setProductName(preset.productName);
    setOcrText(preset.ocrText);
    setExtractedFields(preset.fields as any);
    setImagePreview(null);
    setStep('review');
  };

  const handleValidate = () => {
    const result = validateProduct(extractedFields);
    setValidationResult(result);
    setStep('result');
  };

  const handleSaveInspection = async () => {
    if (!validationResult) return;
    setSaving(true);
    setError('');

    try {
      const payload = {
        productName: productName || 'Packaged Commodity Audit',
        ocrText,
        extractedFields,
        validationResult,
        imageBase64: imageBase64 ? imageBase64.slice(0, 500000) : undefined,
      };

      const res = await fetch('/api/inspections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success && data.data?.inspectionId) {
        if (data.data._id && data.data._id.toString().startsWith('demo-')) {
          try {
            const existingCache = localStorage.getItem('demoInspections');
            const cachedArr = existingCache ? JSON.parse(existingCache) : [];
            cachedArr.unshift(data.data);
            localStorage.setItem('demoInspections', JSON.stringify(cachedArr));
          } catch (e) {
            console.error('Failed to cache demo inspection:', e);
          }
        }
        router.push(`/dashboard/inspection/${data.data.inspectionId}`);
      } else {
        setError(data.error || 'Failed to save audit record.');
      }
    } catch {
      setError('Network connection error while saving.');
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    setStep('upload');
    setImagePreview(null);
    setImageBase64('');
    setOcrText('');
    setOcrProgress(0);
    setOcrStatus('');
    setExtractedFields({
      mrp: null,
      netQuantity: null,
      manufacturerName: null,
      manufacturerAddress: null,
      manufacturingDate: null,
      consumerCare: null,
    });
    setProductName('');
    setValidationResult(null);
    setError('');
  };

  const updateField = (field: keyof ExtractedFields, value: string) => {
    setExtractedFields((prev) => ({ ...prev, [field]: value || null }));
  };

  const STEPS_NAV = [
    { id: 'upload', label: '1. Select Product', active: step === 'upload' },
    { id: 'processing', label: '2. Scanning', active: step === 'processing' },
    { id: 'review', label: '3. Verify Values', active: step === 'review' },
    { id: 'result', label: '4. Legal Verdict', active: step === 'result' },
  ];

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-black text-[var(--text-color)] tracking-tight flex flex-wrap items-center gap-2.5 sm:gap-3">
            <span>Compliance Scanner</span>
            <span className="text-[11px] sm:text-xs font-semibold text-indigo-300 bg-indigo-950/80 px-2.5 py-1 rounded-full border border-indigo-700/60">
              Live Studio
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-[var(--text-muted)] mt-1">
            Scan or select a product label to audit mandatory packaging declarations.
          </p>
        </div>

        {step !== 'upload' && (
          <button
            onClick={handleReset}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-[var(--border-color)] bg-[var(--card-bg)] text-xs sm:text-sm font-bold text-[var(--text-color)] hover:bg-[var(--card-bg)] transition cursor-pointer min-h-[44px]"
          >
            <RotateCcw className="w-4 h-4 text-[var(--text-muted)]" />
            <span>Reset Scanner</span>
          </button>
        )}
      </div>

      {/* Step Indicator */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5 p-1.5 sm:p-2 bg-[var(--card-bg)] rounded-2xl border border-[var(--border-color)]">
        {STEPS_NAV.map((s) => (
          <div
            key={s.id}
            className={`py-2 sm:py-2.5 px-2 sm:px-3 rounded-xl text-xs sm:text-sm font-bold transition text-center ${
              s.active
                ? 'bg-indigo-600 text-[var(--text-color)] shadow-md shadow-indigo-500/25'
                : 'text-[var(--text-muted)]'
            }`}
          >
            <span>{s.label}</span>
          </div>
        ))}
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-300 text-xs sm:text-sm font-semibold flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* STEP 1: Select Preset Commodity or Upload */}
      {step === 'upload' && (
        <div className="space-y-8">
          {/* Preset Test Commodities */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm sm:text-base font-bold text-[var(--text-color)] flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <span>Instant Test Samples</span>
              </h3>
              <span className="text-xs text-[var(--text-muted)]">Tap to audit instantly</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4">
              {PRESET_SAMPLES.map((p, idx) => (
                <div
                  key={idx}
                  onClick={() => handlePresetSelect(p)}
                  className={`p-4 sm:p-5 rounded-2xl bg-[var(--card-bg)] border ${p.border} hover:border-indigo-500/50 transition cursor-pointer flex flex-col justify-between space-y-3 sm:space-y-4 group active:scale-[0.99]`}
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                        <h4 className="font-bold text-sm sm:text-base text-[var(--text-color)] group-hover:text-indigo-400 transition leading-snug">
                          {p.title}
                        </h4>
                      <span className={`text-[10px] sm:text-[11px] font-bold px-2.5 py-0.5 rounded-full border shrink-0 ${p.badgeColor}`}>
                        {p.badge}
                      </span>
                    </div>
                    <p className="text-xs text-[var(--text-muted)] pl-8 sm:pl-9">{p.subtitle}</p>
                  </div>

                  <div className="pt-3 border-t border-[var(--border-color)] flex items-center justify-between text-xs font-bold text-indigo-400">
                    <span>Audit Sample →</span>
                    <span className="text-[var(--text-muted)] font-medium">Ready</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upload Photo Dropzone */}
          <div className="space-y-3">
            <h3 className="text-sm sm:text-base font-bold text-[var(--text-color)] flex items-center gap-2">
              <Camera className="w-4 h-4 text-indigo-400" />
              <span>Or Upload Custom Label Photo</span>
            </h3>

            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                if (e.dataTransfer.files?.[0]) handleFileSelect(e.dataTransfer.files[0]);
              }}
              onClick={() => fileInputRef.current?.click()}
              className={`p-8 sm:p-12 lg:p-16 rounded-3xl border-[2.5px] sm:border-[3px] border-dashed text-center cursor-pointer transition-all duration-200 bg-white/40 dark:bg-black/40 hover:bg-white/60 dark:hover:bg-black/60 backdrop-blur-md flex flex-col items-center justify-center space-y-4 active:scale-[0.99] shadow-[0_8px_30px_rgba(0,0,0,0.12)] border-white/40 dark:border-white/10 ${
                dragOver
                  ? 'border-indigo-400 bg-indigo-950/40 shadow-indigo-500/20'
                  : 'border-indigo-500/40 hover:border-indigo-400/80 hover:bg-indigo-950/15'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.[0]) handleFileSelect(e.target.files[0]);
                }}
              />
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-indigo-600 text-[var(--text-color)] flex items-center justify-center shadow-xl shadow-indigo-500/30 border border-indigo-400/30">
                <Upload className="w-7 h-7 sm:w-8 sm:h-8" />
              </div>
              <div className="space-y-1.5 max-w-md">
                <p className="text-base sm:text-lg font-bold text-[var(--text-color)] tracking-tight">
                  Drop product photo here or tap to select
                </p>
                <p className="text-xs sm:text-sm text-[var(--text-color)] font-bold mt-1 drop-shadow-sm">
                  Supports smartphone camera photos or JPG, PNG, WEBP packaging files
                </p>
              </div>

              {/* Shifted Down for Clear Visibility and Breathing Space */}
              <div className="pt-4 sm:pt-6">
                <button
                  type="button"
                  className="px-7 py-3.5 rounded-xl text-sm sm:text-base font-bold text-[var(--text-color)] bg-indigo-600 hover:bg-indigo-500 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer min-h-[48px] inline-flex items-center gap-2.5 shadow-xl shadow-indigo-600/30 border border-indigo-400/40 hover:border-indigo-300"
                >
                  <Camera className="w-5 h-5" />
                  <span>Take Photo / Choose File</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: Processing */}
      {step === 'processing' && (
        <div className="p-6 sm:p-10 bg-slate-900/95 rounded-2xl sm:rounded-3xl border border-[var(--border-color)] text-center space-y-8 max-w-xl mx-auto relative overflow-hidden shadow-2xl shadow-indigo-900/20 backdrop-blur-xl">
          <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/10 to-transparent pointer-events-none" />
          
          {/* Animated Image Preview */}
          <div className="relative w-full max-w-sm mx-auto aspect-[4/3] rounded-2xl overflow-hidden border-2 border-indigo-500/30 shadow-[0_0_30px_rgba(79,70,229,0.2)] bg-black/50">
            {imagePreview ? (
              <img src={imagePreview} alt="Scanning" className="w-full h-full object-cover opacity-60 mix-blend-luminosity" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <ScanLine className="w-12 h-12 text-indigo-500/50" />
              </div>
            )}
            
            {/* Laser Line */}
            <div 
              className="absolute left-0 right-0 h-1 bg-indigo-400 shadow-[0_0_20px_4px_rgba(99,102,241,0.8)] z-10"
              style={{
                top: `${ocrProgress}%`,
                transition: 'top 0.3s ease-out'
              }}
            />
            {/* Laser Gradient Overlay */}
            <div 
              className="absolute left-0 right-0 bottom-0 bg-gradient-to-t from-indigo-500/30 to-transparent z-0 transition-all duration-300"
              style={{ top: 0, height: `${ocrProgress}%` }}
            />
            {/* Grid Overlay */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(99,102,241,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(99,102,241,0.1)_1px,transparent_1px)] bg-[length:20px_20px] pointer-events-none" />
          </div>

          <div className="space-y-3 relative z-20">
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight drop-shadow-md">Scanning Product Label</h3>
            <p className="text-sm sm:text-base text-indigo-200 font-bold uppercase tracking-widest animate-pulse">{ocrStatus || 'Parsing packaging text...'}</p>
          </div>

          <div className="space-y-3 max-w-sm mx-auto w-full pt-2 relative z-20">
            <div className="flex justify-between text-sm font-bold text-white tracking-wide">
              <span>Analysis Progress</span>
              <span className="text-indigo-300">{ocrProgress}%</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden border border-slate-700/50 shadow-inner relative">
              <div
                className="bg-gradient-to-r from-indigo-600 via-indigo-400 to-indigo-500 h-full rounded-full transition-all duration-300 ease-out shadow-[0_0_10px_rgba(99,102,241,0.5)] relative overflow-hidden"
                style={{ width: `${ocrProgress}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* STEP 3: Review Detected Declarations */}
      {step === 'review' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6">
          {/* Left: Preview */}
          <div className="lg:col-span-5 space-y-4">
            {imagePreview && (
              <div className="p-4 sm:p-5 bg-[var(--card-bg)] rounded-2xl border border-[var(--border-color)] space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)] flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-indigo-400" /> Label Image
                </h4>
                <img
                  src={imagePreview}
                  alt="Label"
                  className="w-full aspect-16-10 sm:aspect-16-9 max-h-72 object-contain rounded-xl border border-[var(--border-color)] bg-slate-950/60"
                />
              </div>
            )}

            {ocrText && (
              <div className="p-4 sm:p-5 bg-[var(--card-bg)] rounded-2xl border border-[var(--border-color)] space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)] flex items-center gap-2">
                  <ScanLine className="w-4 h-4 text-indigo-400" /> Extracted Label Text
                </h4>
                <pre className="p-3.5 sm:p-4 bg-[var(--card-bg)] text-[var(--text-color)] rounded-xl text-xs font-mono max-h-52 overflow-y-auto border border-[var(--border-color)] whitespace-pre-wrap leading-relaxed">
                  {ocrText}
                </pre>
              </div>
            )}
          </div>

          {/* Right: Form */}
          <div className="lg:col-span-7 p-5 sm:p-7 bg-[var(--card-bg)] rounded-2xl sm:rounded-3xl border border-[var(--border-color)] space-y-4 sm:space-y-5">
            <div>
              <h3 className="text-base sm:text-lg font-bold text-[var(--text-color)]">Verify Extracted Declarations</h3>
              <p className="text-xs text-[var(--text-muted)] mt-0.5">
                Review values before running the 12 Legal Metrology rule checks
              </p>
            </div>

            <div className="space-y-3.5 sm:space-y-4 text-xs sm:text-sm">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-semibold text-[var(--text-color)]">Product / Commodity Name</label>
                  <span className="text-[11px] text-[var(--text-muted)]">Label Identifier</span>
                </div>
                <input
                  type="text"
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  placeholder="e.g., Parle-G Gold Biscuits 200g"
                  className="w-full px-3.5 sm:px-4 py-3 sm:py-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-white/50 dark:bg-black/50 backdrop-blur-md text-base sm:text-sm text-[var(--text-color)] font-medium placeholder-[var(--text-color)]/60 focus:border-indigo-500 outline-none transition shadow-inner"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="font-semibold text-[var(--text-color)]">Maximum Retail Price</label>
                    <span className="text-[10px] sm:text-[11px] font-mono text-indigo-400">Rule 6(1)(d)</span>
                  </div>
                  <input
                    type="text"
                    value={extractedFields.mrp || ''}
                    onChange={(e) => updateField('mrp', e.target.value)}
                    placeholder="e.g., ₹25.00"
                    className="w-full px-3.5 sm:px-4 py-3 sm:py-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-white/50 dark:bg-black/50 backdrop-blur-md text-base sm:text-sm text-[var(--text-color)] font-medium placeholder-[var(--text-color)]/60 focus:border-indigo-500 outline-none transition shadow-inner"
                  />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="font-semibold text-[var(--text-color)]">Net Quantity</label>
                    <span className="text-[10px] sm:text-[11px] font-mono text-indigo-400">Rule 6(1)(b)</span>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={parseQuantity(extractedFields.netQuantity).val}
                      onChange={(e) => {
                        const unit = parseQuantity(extractedFields.netQuantity).unit;
                        updateField('netQuantity', `${e.target.value} ${unit}`);
                      }}
                      placeholder="e.g., 200"
                      className="w-full px-3.5 sm:px-4 py-3 sm:py-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-white/50 dark:bg-black/50 backdrop-blur-md text-base sm:text-sm text-[var(--text-color)] font-medium placeholder-[var(--text-color)]/60 focus:border-indigo-500 outline-none transition shadow-inner"
                    />
                    <select
                      value={parseQuantity(extractedFields.netQuantity).unit}
                      onChange={(e) => {
                        const val = parseQuantity(extractedFields.netQuantity).val;
                        updateField('netQuantity', `${val} ${e.target.value}`);
                      }}
                      className="w-24 px-2 py-3 sm:py-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-white/50 dark:bg-black/50 backdrop-blur-md text-base sm:text-sm text-[var(--text-color)] font-medium focus:border-indigo-500 outline-none transition shadow-inner cursor-pointer"
                    >
                      <option value="g">g</option>
                      <option value="kg">kg</option>
                      <option value="ml">ml</option>
                      <option value="l">L</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="font-semibold text-[var(--text-color)]">Unit Sale Price (USP)</label>
                    <span className="text-[10px] sm:text-[11px] font-mono text-indigo-400">Rule 6(1)(da)</span>
                  </div>
                  <input
                    type="text"
                    value={extractedFields.unitSalePrice || ''}
                    onChange={(e) => updateField('unitSalePrice', e.target.value)}
                    placeholder="e.g., ₹0.125 / g"
                    className="w-full px-3.5 sm:px-4 py-3 sm:py-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-white/50 dark:bg-black/50 backdrop-blur-md text-base sm:text-sm text-[var(--text-color)] font-medium placeholder-[var(--text-color)]/60 focus:border-indigo-500 outline-none transition shadow-inner"
                  />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="font-semibold text-[var(--text-color)]">Country of Origin</label>
                    <span className="text-[10px] sm:text-[11px] font-mono text-indigo-400">Rule 6(1)(aa)</span>
                  </div>
                  <input
                    type="text"
                    value={extractedFields.countryOfOrigin || ''}
                    onChange={(e) => updateField('countryOfOrigin', e.target.value)}
                    placeholder="e.g., India"
                    className="w-full px-3.5 sm:px-4 py-3 sm:py-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-white/50 dark:bg-black/50 backdrop-blur-md text-base sm:text-sm text-[var(--text-color)] font-medium placeholder-[var(--text-color)]/60 focus:border-indigo-500 outline-none transition shadow-inner"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-semibold text-[var(--text-color)]">Manufacturer Name</label>
                  <span className="text-[10px] sm:text-[11px] font-mono text-indigo-400">Rule 6(1)(a)</span>
                </div>
                <input
                  type="text"
                  value={extractedFields.manufacturerName || ''}
                  onChange={(e) => updateField('manufacturerName', e.target.value)}
                  placeholder="e.g., Parle Products Pvt. Ltd."
                  className="w-full px-3.5 sm:px-4 py-3 sm:py-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-white/50 dark:bg-black/50 backdrop-blur-md text-base sm:text-sm text-[var(--text-color)] font-medium placeholder-[var(--text-color)]/60 focus:border-indigo-500 outline-none transition shadow-inner"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-semibold text-[var(--text-color)]">Manufacturer Street Address</label>
                  <span className="text-[10px] sm:text-[11px] font-mono text-indigo-400">Rule 6(1)(a)</span>
                </div>
                <input
                  type="text"
                  value={extractedFields.manufacturerAddress || ''}
                  onChange={(e) => updateField('manufacturerAddress', e.target.value)}
                  placeholder="e.g., Vile Parle East, Mumbai 400057"
                  className="w-full px-3.5 sm:px-4 py-3 sm:py-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-white/50 dark:bg-black/50 backdrop-blur-md text-base sm:text-sm text-[var(--text-color)] font-medium placeholder-[var(--text-color)]/60 focus:border-indigo-500 outline-none transition shadow-inner"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="font-semibold text-[var(--text-color)]">Packing / Mfg Date</label>
                    <span className="text-[10px] sm:text-[11px] font-mono text-indigo-400">Rule 6(1)(e)</span>
                  </div>
                  <input
                    type="text"
                    value={extractedFields.manufacturingDate || ''}
                    onChange={(e) => updateField('manufacturingDate', e.target.value)}
                    placeholder="e.g., 12/01/2026"
                    className="w-full px-3.5 sm:px-4 py-3 sm:py-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-white/50 dark:bg-black/50 backdrop-blur-md text-base sm:text-sm text-[var(--text-color)] font-medium placeholder-[var(--text-color)]/60 focus:border-indigo-500 outline-none transition shadow-inner"
                  />
                </div>
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="font-semibold text-[var(--text-color)]">Consumer Helpline</label>
                    <span className="text-[10px] sm:text-[11px] font-mono text-indigo-400">Rule 6(2)</span>
                  </div>
                  <input
                    type="text"
                    value={extractedFields.consumerCare || ''}
                    onChange={(e) => updateField('consumerCare', e.target.value)}
                    placeholder="e.g., 1800-22-7788"
                    className="w-full px-3.5 sm:px-4 py-3 sm:py-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-white/50 dark:bg-black/50 backdrop-blur-md text-base sm:text-sm text-[var(--text-color)] font-medium placeholder-[var(--text-color)]/60 focus:border-indigo-500 outline-none transition shadow-inner"
                  />
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleValidate}
              className="w-full mt-4 flex items-center justify-center gap-2 py-3.5 rounded-xl text-sm sm:text-base font-bold text-[var(--text-color)] bg-indigo-600 hover:opacity-95 shadow-lg shadow-indigo-500/25 transition cursor-pointer min-h-[48px] active:scale-[0.99]"
            >
              <FileCheck className="w-5 h-5" />
              <span>Validate 12 Statutory Clauses</span>
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Compliance Verdict */}
      {step === 'result' && validationResult && (
        <div className="space-y-6">
          {/* Main Verdict Banner */}
          <div
            className={`p-6 sm:p-8 lg:p-10 rounded-2xl sm:rounded-3xl border text-center shadow-xl space-y-4 ${
              validationResult.status === 'COMPLIANT'
                ? 'bg-gradient-to-br from-emerald-600 to-emerald-800 border-emerald-500/50 shadow-emerald-500/20'
                : validationResult.status === 'NON_COMPLIANT'
                ? 'bg-gradient-to-br from-rose-600 to-rose-800 border-rose-500/50 shadow-rose-500/20'
                : 'bg-gradient-to-br from-amber-600 to-amber-800 border-amber-500/50 shadow-amber-500/20'
            }`}
          >
            <div className="flex justify-center">
              {validationResult.status === 'COMPLIANT' ? (
                <div className="w-14 h-14 rounded-2xl bg-white/20 text-white flex items-center justify-center shadow-lg backdrop-blur-md">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
              ) : validationResult.status === 'NON_COMPLIANT' ? (
                <div className="w-14 h-14 rounded-2xl bg-white/20 text-white flex items-center justify-center shadow-lg backdrop-blur-md">
                  <ShieldAlert className="w-8 h-8" />
                </div>
              ) : (
                <div className="w-14 h-14 rounded-2xl bg-white/20 text-white flex items-center justify-center shadow-lg backdrop-blur-md">
                  <AlertCircle className="w-8 h-8" />
                </div>
              )}
            </div>

            <div className="space-y-1">
              <span className="text-xs font-bold uppercase tracking-wider text-white/90 shadow-sm">
                Evaluation Verdict
              </span>
              <h2 className="text-xl sm:text-2xl lg:text-3xl font-black text-white drop-shadow-sm">
                {validationResult.status === 'COMPLIANT'
                  ? '100% Fully Compliant'
                  : validationResult.status === 'NON_COMPLIANT'
                  ? 'Packaging Violations Detected'
                  : 'Requires Officer Review'}
              </h2>
              <p className="text-xs sm:text-sm text-white/90 font-medium">
                Compliance Score: <strong className="text-white font-extrabold text-base">{validationResult.complianceScore}%</strong> across 12 Legal Metrology Rules
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 pt-3">
              <button
                type="button"
                onClick={handleSaveInspection}
                disabled={saving}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl text-sm font-bold text-[var(--text-color)] bg-indigo-600 hover:opacity-95 shadow-lg shadow-indigo-500/25 transition cursor-pointer disabled:opacity-60 min-h-[48px] active:scale-[0.99]"
              >
                {saving ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <FileCheck className="w-4 h-4" />
                    <span>Save & Generate Form VI Notice</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleReset}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-sm font-bold text-[var(--text-color)] bg-[var(--card-bg)] border border-[var(--border-color)] hover:bg-[var(--card-bg)] transition cursor-pointer min-h-[48px]"
              >
                <RotateCcw className="w-4 h-4 text-[var(--text-muted)]" />
                <span>Scan Another</span>
              </button>
            </div>
          </div>

          {/* 12 Clauses Summary */}
          <div className="bg-[var(--card-bg)] rounded-2xl sm:rounded-3xl border border-[var(--border-color)] p-5 sm:p-7 space-y-4">
            <h3 className="font-bold text-sm sm:text-base text-[var(--text-color)]">12-Clause Statutory Breakdown</h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              {validationResult.results?.map((r) => (
                <div
                  key={r.ruleId}
                  className={`p-3.5 sm:p-4 rounded-xl sm:rounded-2xl border flex items-start justify-between gap-3 shadow-md ${
                    r.status === 'PASS'
                      ? 'bg-emerald-600 border-emerald-500/50'
                      : r.status === 'FAIL'
                      ? 'bg-rose-600 border-rose-500/50'
                      : 'bg-amber-600 border-amber-500/50'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-black px-2 py-0.5 rounded bg-[#00000066] text-[#ffffff] shadow-sm border border-white/20">
                        {r.ruleId}
                      </span>
                      <span className="text-xs font-semibold text-[#ffffffcc] drop-shadow-sm">{r.field}</span>
                    </div>
                    <h5 className="font-bold text-xs sm:text-sm text-[#ffffff] drop-shadow-sm">{r.ruleName}</h5>
                    <p className="text-xs text-[#ffffffe6] font-medium drop-shadow-sm leading-relaxed">{r.message}</p>
                  </div>

                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full shrink-0 border ${
                      r.status === 'PASS'
                        ? 'bg-white/20 text-[#ffffff] border-white/30 backdrop-blur-sm'
                        : r.status === 'FAIL'
                        ? 'bg-white/20 text-[#ffffff] border-white/30 backdrop-blur-sm'
                        : 'bg-white/20 text-[#ffffff] border-white/30 backdrop-blur-sm'
                    }`}
                  >
                    {r.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
