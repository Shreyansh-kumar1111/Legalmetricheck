'use client';

import React, { createContext, useContext } from 'react';
import { UserData } from '@/types';

interface UserContextType {
  user: UserData | null;
  loading: boolean;
}

const UserContext = createContext<UserContextType>({ user: null, loading: true });

export const useUser = () => useContext(UserContext);

export const UserProvider = ({ children, user, loading }: { children: React.ReactNode, user: UserData | null, loading: boolean }) => {
  return (
    <UserContext.Provider value={{ user, loading }}>
      {children}
    </UserContext.Provider>
  );
};
