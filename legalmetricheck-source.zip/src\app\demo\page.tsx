'use client';

import React from 'react';
import Link from 'next/link';
import { ArrowLeft, Send } from 'lucide-react';

export default function DemoPage() {
  return (
    <div className="w-full min-h-screen bg-black text-white font-sans flex flex-col items-center justify-center p-6 relative">
      {/* Background Subtle Gradient */}
      <div 
        className="fixed inset-0 pointer-events-none z-0" 
        style={{ background: 'radial-gradient(ellipse at top, rgba(79, 70, 229, 0.15) 0%, rgba(0,0,0,1) 70%)' }}
      />
      
      <div className="relative z-10 w-full max-w-md bg-slate-900/80 p-8 rounded-3xl border border-white/10 shadow-2xl backdrop-blur-md">
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white transition mb-6">
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>
        
        <h1 className="text-3xl font-bold mb-2">Request a Demo</h1>
        <p className="text-slate-400 text-sm mb-8">
          Enter your details below and our team will get in touch to schedule a personalized walkthrough of the LegalMetriCheck platform.
        </p>

        <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Full Name</label>
            <input 
              type="text" 
              placeholder="Officer / Inspector Name" 
              className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition text-white"
            />
          </div>
          
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Department / Jurisdiction</label>
            <input 
              type="text" 
              placeholder="e.g. Legal Metrology Dept, Delhi" 
              className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Email Address</label>
            <input 
              type="email" 
              placeholder="gov.in email preferred" 
              className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition text-white"
            />
          </div>

          <button 
            type="button"
            className="w-full mt-6 bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 transition"
            onClick={() => alert('Demo request submitted successfully! Our team will contact you shortly.')}
          >
            <Send className="w-4 h-4" />
            Submit Request
          </button>
        </form>
      </div>
    </div>
  );
}
