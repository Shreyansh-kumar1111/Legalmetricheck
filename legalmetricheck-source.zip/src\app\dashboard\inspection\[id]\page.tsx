'use client';

import React, { useState, useEffect, use } from 'react';
import Link from 'next/link';
import {
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
  Download,
  PlusCircle,
  FileText,
  Printer,
  ShieldCheck,
  Building2,
  Calendar,
  AlertTriangle,
  Scale,
  Sparkles,
} from 'lucide-react';
import { InspectionData } from '@/types';
import { formatDateTime, getStatusLabel } from '@/lib/utils';
import { useUser } from '@/contexts/UserContext';

export default function InspectionDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { user } = useUser();
  const [inspection, setInspection] = useState<InspectionData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkLocalStorage = () => {
      try {
        const stored = localStorage.getItem('demoInspections');
        if (stored) {
          const inspections = JSON.parse(stored);
          const found = inspections.find((i: any) => i.inspectionId === id || i._id === id);
          if (found) setInspection(found);
        }
      } catch (e) {
        console.error('Failed to parse localStorage', e);
      }
    };

    fetch(`/api/inspections/${id}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          setInspection(data.data);
        } else {
          checkLocalStorage();
        }
      })
      .catch((err) => {
        console.error(err);
        checkLocalStorage();
      })
      .finally(() => setLoading(false));
  }, [id]);

  const [updating, setUpdating] = useState(false);

  const handleUpdateStatus = async (newStatus: 'COMPLIANT' | 'NON_COMPLIANT') => {
    if (!inspection || updating) return;
    setUpdating(true);
    try {
      const res = await fetch(`/api/inspections/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (data.success) {
        setInspection(data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUpdating(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!inspection) return;
    const { generateComplianceReport } = await import('@/lib/pdf/reportGenerator');
    generateComplianceReport(inspection);
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] space-y-3">
        <div className="w-10 h-10 border-3 border-indigo-900 border-t-indigo-500 rounded-full animate-spin" />
        <p className="text-sm font-semibold text-[var(--text-muted)]">Loading inspection audit record...</p>
      </div>
    );
  }

  if (!inspection) {
    return (
      <div className="text-center py-20 bg-[var(--card-bg)] rounded-2xl border border-[var(--border-color)] p-10 space-y-4 max-w-lg mx-auto shadow-sm backdrop-blur-sm">
        <AlertCircle className="w-14 h-14 text-[var(--text-muted)] mx-auto" />
        <h2 className="text-xl font-bold text-[var(--text-color)]">Inspection Record Not Found</h2>
        <p className="text-sm text-[var(--text-muted)]">
          The requested inspection record could not be located in the compliance database.
        </p>
        <Link
          href="/dashboard/history"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-indigo-300 bg-indigo-950/80 border border-indigo-700/50 hover:bg-indigo-900/80 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Audit History</span>
        </Link>
      </div>
    );
  }

  const results = inspection.validationResults || [];
  const violations = results.filter((r) => r.status === 'FAIL');
  const passed = results.filter((r) => r.status === 'PASS');

  const renderVal = (v: any): string | null => {
    if (v === null || v === undefined) return null;
    if (typeof v === 'object' && 'value' in v) {
      return v.value ? String(v.value) : null;
    }
    const s = String(v).trim();
    return s.length > 0 ? s : null;
  };

  const isCompliant = inspection.status === 'COMPLIANT';
  const isNonCompliant = inspection.status === 'NON_COMPLIANT';

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Top Bar Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5 pb-6 border-b border-[var(--border-color)]">
        <div className="flex items-start gap-3 sm:gap-4">
          <Link
            href="/dashboard/history"
            className="p-2.5 rounded-xl border border-[var(--border-color)] bg-[var(--card-bg)] text-[var(--text-color)] hover:text-[var(--text-color)] hover:bg-[var(--card-bg)] transition print:hidden shadow-sm shrink-0 mt-0.5 min-h-[44px] min-w-[44px] flex items-center justify-center"
            title="Back to History"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-slate-900 dark:text-[var(--text-color)] tracking-tight break-words">
                {inspection.productName}
              </h1>
              <span className="font-mono text-xs px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-700/60 text-indigo-700 dark:text-indigo-300 font-bold shrink-0">
                {inspection.inspectionId}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-[var(--text-color)] font-bold mt-1 drop-shadow-sm">
              Inspected on {formatDateTime(inspection.createdAt)} by <span className="font-extrabold">{inspection.officerName}</span>
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-2.5 sm:gap-3 print:hidden w-full sm:w-auto">
          {inspection.status === 'NEEDS_REVIEW' && !user?.role?.toLowerCase().includes('auditor') && (
            <>
              <button
                onClick={() => handleUpdateStatus('COMPLIANT')}
                disabled={updating}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-500/20 transition hover:scale-[1.02] min-h-[44px] disabled:opacity-50"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{updating ? 'Updating...' : 'Approve Scan'}</span>
              </button>
              <button
                onClick={() => handleUpdateStatus('NON_COMPLIANT')}
                disabled={updating}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-white bg-rose-600 hover:bg-rose-500 shadow-md shadow-rose-500/20 transition hover:scale-[1.02] min-h-[44px] disabled:opacity-50"
              >
                <AlertCircle className="w-4 h-4" />
                <span>{updating ? 'Updating...' : 'Reject Scan'}</span>
              </button>
            </>
          )}

          <button
            onClick={() => window.print()}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-[var(--text-color)] bg-[var(--card-bg)] border border-[var(--border-color)] hover:bg-[var(--card-bg)] transition shadow-sm cursor-pointer min-h-[44px]"
          >
            <Printer className="w-4 h-4 text-[var(--text-muted)]" />
            <span>Print Notice</span>
          </button>

          <button
            onClick={handleDownloadPDF}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 hover:opacity-95 shadow-lg shadow-indigo-500/25 transition cursor-pointer hover:scale-[1.02] min-h-[44px]"
          >
            <Download className="w-4 h-4" />
            <span>Export PDF Notice</span>
          </button>

          {!user?.role?.toLowerCase().includes('auditor') && (
            <Link
              href="/dashboard/inspect"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-[var(--text-color)] bg-[var(--card-bg)] border border-[var(--border-color)] hover:bg-[var(--card-bg)] transition shadow-sm min-h-[44px]"
            >
              <PlusCircle className="w-4 h-4 text-[var(--text-muted)]" />
              <span>New Scan</span>
            </Link>
          )}
        </div>
      </div>

      {/* Official Notice Verdict Banner */}
      <div
        className={`p-6 sm:p-8 lg:p-10 rounded-2xl sm:rounded-3xl border text-center relative overflow-hidden transition-all shadow-xl backdrop-blur-md ${
          isCompliant
            ? 'bg-gradient-to-br from-emerald-600 to-emerald-800 border-emerald-500/50 shadow-emerald-500/20'
            : isNonCompliant
            ? 'bg-gradient-to-br from-rose-600 to-rose-800 border-rose-500/50 shadow-rose-500/20'
            : 'bg-gradient-to-br from-amber-600 to-amber-800 border-amber-500/50 shadow-amber-500/20'
        }`}
      >
        <div className="flex items-center justify-center gap-2 mb-2">
          <ShieldCheck className="w-5 h-5 text-white" />
          <span className="text-xs font-bold uppercase tracking-wider text-white/90 shadow-sm">
            Form VI Statutory Inspection Memo
          </span>
        </div>

        <h2
          className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white drop-shadow-sm"
        >
          {getStatusLabel(inspection.status).toUpperCase()}
        </h2>

        <p className="text-xs sm:text-sm text-white/90 font-medium mt-2">
          {violations.length === 0 ? 'All 12 mandatory packaging clauses passed' : `${violations.length} statutory violation(s) flagged`} · Compliance Score:{' '}
          <strong className="text-white font-extrabold text-base">{inspection.complianceScore}%</strong>
        </p>
      </div>

      {/* Two Column Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Detected Declarations Table */}
        <div className="lg:col-span-7 bg-[var(--card-bg)] rounded-2xl border border-[var(--border-color)] p-6 sm:p-7 shadow-sm backdrop-blur-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[var(--border-color)]">
            <h3 className="font-bold text-base text-[var(--text-color)]">Mandatory Label Declarations</h3>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-700/60 px-2.5 py-1 rounded-lg">
              Rule 6 Audit
            </span>
          </div>

          <div className="divide-y divide-white/5 text-sm">
            {[
              { label: 'Maximum Retail Price', rule: 'Rule 6(1)(d)', raw: inspection.extractedFields.mrp },
              { label: 'Net Quantity', rule: 'Rule 6(1)(b)', raw: inspection.extractedFields.netQuantity },
              { label: 'Unit Sale Price (USP)', rule: 'Rule 6(1)(da)', raw: inspection.extractedFields.unitSalePrice },
              { label: 'Country of Origin', rule: 'Rule 6(1)(aa)', raw: inspection.extractedFields.countryOfOrigin },
              { label: 'Manufacturer Name', rule: 'Rule 6(1)(a)', raw: inspection.extractedFields.manufacturerName },
              { label: 'Manufacturer Address', rule: 'Rule 6(1)(a)', raw: inspection.extractedFields.manufacturerAddress },
              { label: 'Mfg / Packing Date', rule: 'Rule 6(1)(e)', raw: inspection.extractedFields.manufacturingDate },
              { label: 'Expiry / Best Before', rule: 'Rule 6(1)(f)', raw: inspection.extractedFields.expiryDate },
              { label: 'Consumer Care Helpline', rule: 'Rule 6(2)', raw: inspection.extractedFields.consumerCare },
              { label: 'Tax Inclusion Clause', rule: 'Rule 6(3)', raw: inspection.extractedFields.hasTaxInclusion },
            ].map((f, i) => {
              const val = renderVal(f.raw);
              return (
                <div key={i} className="py-3 flex items-start justify-between gap-4">
                  <div className="space-y-0.5">
                    <span className="font-bold text-[var(--text-color)] block text-xs sm:text-sm">{f.label}</span>
                    <span className="text-[11px] font-mono text-[var(--text-muted)] block">{f.rule}</span>
                  </div>
                  <span
                    className={`text-xs sm:text-sm font-semibold text-right max-w-xs ${
                      val ? 'text-[var(--text-color)]' : 'text-rose-400 font-bold'
                    }`}
                  >
                    {val || 'Missing / Non-Compliant ✗'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Inspection Audit Meta */}
        <div className="lg:col-span-5 bg-[var(--card-bg)] rounded-2xl border border-[var(--border-color)] p-6 sm:p-7 shadow-sm backdrop-blur-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[var(--border-color)]">
            <h3 className="font-bold text-base text-[var(--text-color)]">Official Audit Metadata</h3>
            <span className="text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/80 px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-700/60">
              Verified Dossier
            </span>
          </div>

          <div className="space-y-3 text-xs sm:text-sm">
            <div className="flex justify-between py-2 border-b border-[var(--border-color)]">
              <span className="text-[var(--text-muted)]">Inspection ID:</span>
              <span className="font-mono font-bold text-[var(--text-color)]">{inspection.inspectionId}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-[var(--border-color)]">
              <span className="text-[var(--text-muted)]">Inspecting Officer:</span>
              <span className="font-bold text-[var(--text-color)]">{inspection.officerName}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-[var(--border-color)]">
              <span className="text-[var(--text-muted)]">Timestamp:</span>
              <span className="font-bold text-[var(--text-color)]">{formatDateTime(inspection.createdAt)}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-[var(--border-color)]">
              <span className="text-[var(--text-muted)]">Compliance Score:</span>
              <span className="font-extrabold text-indigo-400 text-base">
                {inspection.complianceScore}%
              </span>
            </div>
            <div className="flex justify-between py-2 border-b border-[var(--border-color)]">
              <span className="text-[var(--text-muted)]">Passed Clauses:</span>
              <span className="font-bold text-emerald-400">{passed.length} passed</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-[var(--text-muted)]">Violations Identified:</span>
              <span className="font-bold text-rose-400">{violations.length} violations</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[var(--card-bg)] border border-[var(--border-color)] text-[var(--text-color)] text-xs leading-relaxed">
            <strong className="text-[var(--text-color)]">Statutory Notice:</strong> This inspection memo records findings under Section 18 of the Legal Metrology Act, 2009. Packaged commodities violating these clauses are liable for penalties under Section 36.
          </div>
        </div>
      </div>

      {/* Clause-by-Clause Evaluation Cards */}
      <div className="bg-[var(--card-bg)] rounded-2xl border border-[var(--border-color)] p-6 sm:p-8 shadow-sm backdrop-blur-sm space-y-6">
        <div>
          <h3 className="font-bold text-lg text-[var(--text-color)]">Rule Findings</h3>
          <p className="text-xs sm:text-sm text-[var(--text-muted)] mt-0.5">Evaluation against the 12 Legal Metrology clauses</p>
        </div>

        <div className="space-y-3.5">
          {results.map((check, idx) => (
            <div
              key={idx}
              className={`p-4 sm:p-5 rounded-xl border flex items-start gap-3.5 transition-all shadow-md ${
                check.status === 'PASS'
                  ? 'bg-emerald-600 border-emerald-500/50 text-[#ffffff]'
                  : 'bg-rose-600 border-rose-500/50 text-[#ffffff]'
              }`}
            >
              <div className="mt-0.5">
                {check.status === 'PASS' ? (
                  <CheckCircle2 className="w-5 h-5 text-[#ffffff] shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-[#ffffff] shrink-0" />
                )}
              </div>

              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-sm text-[#ffffff] drop-shadow-sm">{check.ruleName}</span>
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#00000066] text-[#ffffff] border border-white/20 font-black shadow-sm">
                    {check.ruleId}
                  </span>
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border bg-white/20 text-[#ffffff] border-white/30 backdrop-blur-sm`}
                  >
                    {check.severity} Severity
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-[#ffffffe6] font-medium drop-shadow-sm">{check.message}</p>
                {check.status === 'FAIL' && check.expectedCondition && (
                  <p className="text-xs font-bold text-[#ffffff] drop-shadow-sm mt-1">
                    Mandatory Statutory Requirement: {check.expectedCondition}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
