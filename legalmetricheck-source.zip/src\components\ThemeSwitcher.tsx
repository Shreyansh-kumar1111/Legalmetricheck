"use client";

import { useTheme } from "next-themes";
import { useEffect, useState, useRef } from "react";
import { Palette } from "lucide-react";

export function ThemeSwitcher() {
  const [mounted, setMounted] = useState(false);
  const { theme, setTheme } = useTheme();

  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: Event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("touchstart", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => setMounted(true), 0);
    return () => clearTimeout(timer);
  }, []);

  if (!mounted) {
    return null;
  }

  const themes = [
    { name: "Light", value: "light", color: "#ffffff", ring: "ring-slate-300" },
    { name: "Dark", value: "dark", color: "#000000", ring: "ring-slate-700" },
    { name: "Indigo", value: "indigo", color: "#4f46e5", ring: "ring-indigo-400" },
    { name: "Rose", value: "rose", color: "#e11d48", ring: "ring-rose-400" },
    { name: "Emerald", value: "emerald", color: "#059669", ring: "ring-emerald-400" },
    { name: "Sky Blue", value: "skyblue", color: "#38bdf8", ring: "ring-sky-400" },
    { name: "Cream", value: "cream", color: "#fef3c7", ring: "ring-amber-200" },
    { name: "Midnight", value: "midnight", color: "#020617", ring: "ring-slate-800" },
  ];

  return (
    <div ref={dropdownRef} className="relative flex items-center justify-center p-2">
      <div 
        className="flex items-center justify-center w-9 h-9 rounded-full bg-white/40 dark:bg-black/40 backdrop-blur-md border border-white/40 dark:border-white/10 hover:border-white/60 dark:hover:border-white/20 hover:shadow-lg transition cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Palette className="w-4 h-4 text-slate-800 dark:text-slate-200" />
      </div>
      
      <div className={`absolute right-0 top-12 ${isOpen ? 'flex' : 'hidden'} flex-col gap-2 p-3 bg-white dark:bg-[#090C13]/95 backdrop-blur-xl border border-slate-200 dark:border-white/10 rounded-xl shadow-xl z-50 animate-in fade-in zoom-in-95 duration-200`}>
        <div className="text-xs font-semibold text-slate-500 mb-1 px-1">Theme Color</div>
        <div className="flex gap-2">
          {themes.map((t) => (
            <button
              key={t.value}
              onClick={() => {
                setTheme(t.value);
                setIsOpen(false);
              }}
              className={`w-6 h-6 rounded-full cursor-pointer hover:scale-110 transition shadow-sm ${
                theme === t.value ? `ring-2 ring-offset-2 ring-offset-white dark:ring-offset-[#090C13] ${t.ring}` : ''
              }`}
              style={{ backgroundColor: t.color }}
              title={t.name}
              aria-label={`Select ${t.name} theme`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
