// ============================================================
// LegalMetriCheck — Type Definitions
// ============================================================

export type InspectionStatus = 'COMPLIANT' | 'NON_COMPLIANT' | 'NEEDS_REVIEW' | 'PENDING';

export type Severity = 'HIGH' | 'MEDIUM' | 'LOW';

export type RuleCategory = 'MANDATORY_DECLARATION' | 'FORMAT_VALIDATION' | 'CONTENT_VALIDATION';

// ---------- Extracted Fields ----------
export interface ExtractedFields {
  mrp: string | null;
  netQuantity: string | null;
  manufacturerName: string | null;
  manufacturerAddress: string | null;
  manufacturingDate: string | null;
  consumerCare: string | null;
  [key: string]: string | null;
}

// ---------- Validation ----------
export interface ValidationCheckResult {
  ruleId: string;
  ruleName: string;
  field: string;
  status: 'PASS' | 'FAIL' | 'WARNING';
  detectedValue: string | null;
  expectedCondition: string;
  message: string;
  severity: Severity;
}

export interface ValidationResult {
  status: InspectionStatus;
  complianceScore: number;
  totalChecks: number;
  passedChecks: number;
  failedChecks: number;
  results: ValidationCheckResult[];
}

// ---------- Rule ----------
export interface RuleDefinition {
  ruleId: string;
  name: string;
  description: string;
  category: RuleCategory;
  severity: Severity;
  field: string;
  isActive: boolean;
  referenceText: string;
  validate: (fields: ExtractedFields) => ValidationCheckResult;
}

export interface RuleData {
  ruleId: string;
  name: string;
  description: string;
  category: RuleCategory;
  severity: Severity;
  field: string;
  isActive: boolean;
  referenceText: string;
}

// ---------- Inspection ----------
export interface InspectionData {
  _id?: string;
  inspectionId: string;
  userId: string;
  productName: string;
  imageBase64?: string;
  ocrRawText: string;
  extractedFields: ExtractedFields;
  validationResults: ValidationCheckResult[];
  status: InspectionStatus;
  complianceScore: number;
  officerName: string;
  createdAt: string;
}

// ---------- User ----------
export interface UserData {
  _id?: string;
  name: string;
  email: string;
  role: string;
  department: string;
}

// ---------- Dashboard Stats ----------
export interface DashboardStats {
  total: number;
  compliant: number;
  nonCompliant: number;
  needsReview: number;
  complianceRate: number;
  recentInspections: InspectionData[];
  monthlyData: MonthlyDataPoint[];
}

export interface MonthlyDataPoint {
  month: string;
  compliant: number;
  nonCompliant: number;
  needsReview: number;
}

// ---------- API Responses ----------
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}
