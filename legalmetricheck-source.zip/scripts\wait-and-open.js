const http = require('http');
const { exec } = require('child_process');

let attempts = 0;
const maxAttempts = 60;
let opened = false;

function launch() {
  if (opened) return;
  opened = true;
  console.log('\n=============================================================');
  console.log('  LegalMetriCheck is READY! Opening http://localhost:3000 ...');
  console.log('=============================================================\n');
  
  // Try Windows start command, fallback to PowerShell Start-Process
  exec('cmd.exe /c start http://localhost:3000', (err) => {
    if (err) {
      exec('powershell -NoProfile -Command "Start-Process http://localhost:3000"');
    }
  });

  setTimeout(() => {
    process.exit(0);
  }, 2000);
}

function checkHost(host) {
  const req = http.get({
    host: host,
    port: 3000,
    path: '/',
    timeout: 1500
  }, (res) => {
    launch();
  });

  req.on('error', () => {
    // Wait for next poll
  });

  req.on('timeout', () => {
    req.destroy();
  });
}

function poll() {
  if (opened) return;
  attempts++;

  // Check 127.0.0.1 explicitly to avoid Windows Node.js IPv6 ::1 lookup issues
  checkHost('127.0.0.1');
  checkHost('localhost');

  if (attempts >= maxAttempts) {
    console.log('\nServer startup took longer than expected.');
    console.log('Attempting to open http://localhost:3000 anyway...\n');
    launch();
  } else {
    setTimeout(poll, 1000);
  }
}

// Start polling
setTimeout(poll, 1000);
