// ============================================================
// LegalMetriCheck — PDF Report Generator
// ============================================================

'use client';

import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { InspectionData, ValidationCheckResult } from '@/types';
import { formatDateTime, getStatusLabel } from '@/lib/utils';

export function generateComplianceReport(inspection: InspectionData): void {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 15;

  // ---------- Header ----------
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, pageWidth, 40, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('LEGAL METROLOGY COMPLIANCE REPORT', pageWidth / 2, 18, { align: 'center' });

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('LegalMetriCheck — Automated Screening System', pageWidth / 2, 26, { align: 'center' });

  doc.setFontSize(8);
  doc.text('Generated: ' + formatDateTime(new Date().toISOString()), pageWidth / 2, 34, { align: 'center' });

  y = 50;

  // ---------- Inspection Info ----------
  doc.setTextColor(30, 41, 59); // slate-800
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Inspection Details', 14, y);
  y += 8;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');

  const info = [
    ['Inspection ID', inspection.inspectionId],
    ['Product Name', inspection.productName || 'N/A'],
    ['Date & Time', formatDateTime(inspection.createdAt)],
    ['Officer', inspection.officerName || 'N/A'],
    ['Status', getStatusLabel(inspection.status)],
    ['Compliance Score', `${inspection.complianceScore}%`],
  ];

  autoTable(doc, {
    startY: y,
    head: [],
    body: info,
    theme: 'plain',
    styles: { fontSize: 10, cellPadding: 3 },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 50 },
      1: { cellWidth: 120 },
    },
    margin: { left: 14 },
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  y = (doc as any).lastAutoTable.finalY + 10;

  // ---------- Status Banner ----------
  const statusColor = inspection.status === 'COMPLIANT'
    ? [22, 163, 74]   // green
    : inspection.status === 'NON_COMPLIANT'
    ? [220, 38, 38]   // red
    : [217, 119, 6];  // amber

  doc.setFillColor(statusColor[0], statusColor[1], statusColor[2]);
  doc.roundedRect(14, y, pageWidth - 28, 16, 3, 3, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(getStatusLabel(inspection.status).toUpperCase(), pageWidth / 2, y + 11, { align: 'center' });

  y += 26;

  // ---------- Extracted Fields ----------
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Extracted Information', 14, y);
  y += 6;

  function formatFieldValue(v: any): string {
    if (v === null || v === undefined) return 'Not detected';
    if (typeof v === 'object' && 'value' in v) {
      return v.value ? String(v.value) : 'Not detected';
    }
    const s = String(v).trim();
    return s.length > 0 ? s : 'Not detected';
  }

  const fields = inspection.extractedFields;
  const fieldRows = [
    ['MRP (Rule 6(1)(d))', formatFieldValue(fields.mrp)],
    ['Net Quantity (Rule 6(1)(b))', formatFieldValue(fields.netQuantity)],
    ['Unit Sale Price (Rule 6(1)(da))', formatFieldValue(fields.unitSalePrice)],
    ['Country of Origin (Rule 6(1)(aa))', formatFieldValue(fields.countryOfOrigin)],
    ['Manufacturer Name (Rule 6(1)(a))', formatFieldValue(fields.manufacturerName)],
    ['Manufacturer Address (Rule 6(1)(a))', formatFieldValue(fields.manufacturerAddress)],
    ['Mfg / Packing Date (Rule 6(1)(e))', formatFieldValue(fields.manufacturingDate)],
    ['Expiry / Best Before (Rule 6(1)(f))', formatFieldValue(fields.expiryDate)],
    ['Consumer Care (Rule 6(2))', formatFieldValue(fields.consumerCare)],
  ];

  autoTable(doc, {
    startY: y,
    head: [['Field', 'Value']],
    body: fieldRows,
    theme: 'striped',
    headStyles: { fillColor: [30, 64, 175], fontSize: 10 },
    styles: { fontSize: 9, cellPadding: 4 },
    margin: { left: 14 },
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  y = (doc as any).lastAutoTable.finalY + 10;

  // ---------- Validation Results ----------
  if (y > 240) {
    doc.addPage();
    y = 20;
  }

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Validation Results', 14, y);
  y += 6;

  const validationRows = inspection.validationResults.map((r: ValidationCheckResult) => [
    r.ruleId,
    r.ruleName,
    r.status === 'PASS' ? '✓ Pass' : '✗ Fail',
    r.detectedValue || 'N/A',
    r.severity,
    r.message || '',
  ]);

  autoTable(doc, {
    startY: y,
    head: [['Rule ID', 'Check', 'Result', 'Detected', 'Severity', 'Details']],
    body: validationRows,
    theme: 'striped',
    headStyles: { fillColor: [30, 64, 175], fontSize: 8 },
    styles: { fontSize: 7, cellPadding: 3 },
    columnStyles: {
      0: { cellWidth: 18 },
      1: { cellWidth: 30 },
      2: { cellWidth: 16 },
      3: { cellWidth: 35 },
      4: { cellWidth: 18 },
      5: { cellWidth: 55 },
    },
    margin: { left: 14 },
    didParseCell: (data) => {
      if (data.column.index === 2 && data.section === 'body') {
        const val = data.cell.raw as string;
        if (val.includes('Pass')) {
          data.cell.styles.textColor = [22, 163, 74];
          data.cell.styles.fontStyle = 'bold';
        } else if (val.includes('Fail')) {
          data.cell.styles.textColor = [220, 38, 38];
          data.cell.styles.fontStyle = 'bold';
        }
      }
    },
  });

  // ---------- Footer / Disclaimer ----------
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    const pageHeight = doc.internal.pageSize.getHeight();

    doc.setDrawColor(203, 213, 225);
    doc.line(14, pageHeight - 25, pageWidth - 14, pageHeight - 25);

    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);
    doc.setFont('helvetica', 'italic');
    doc.text(
      'DISCLAIMER: This is an automated screening report generated by LegalMetriCheck.',
      pageWidth / 2,
      pageHeight - 18,
      { align: 'center' }
    );
    doc.text(
      'Final legal determination remains subject to applicable law and authorized inspection.',
      pageWidth / 2,
      pageHeight - 13,
      { align: 'center' }
    );
    doc.text(
      `Page ${i} of ${pageCount}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  // ---------- Download ----------
  doc.save(`LMC-Report-${inspection.inspectionId}.pdf`);
}
