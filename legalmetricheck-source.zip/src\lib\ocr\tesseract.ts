// ============================================================
// LegalMetriCheck — OCR Service (Tesseract.js)
// ============================================================
// Isolated module for OCR processing.
// Runs client-side. Can be replaced with cloud OCR or AI vision later.

'use client';

import Tesseract from 'tesseract.js';

export type OcrProgressCallback = (progress: number, status: string) => void;

export interface OcrResult {
  text: string;
  confidence: number;
  success: boolean;
  error?: string;
  largestText?: string;
}

export async function extractTextFromImage(
  imageSource: string | File,
  onProgress?: OcrProgressCallback
): Promise<OcrResult> {
  try {
    // 1. Pre-process image using Canvas for better OCR accuracy
    let processedSource = imageSource;
    if (typeof window !== 'undefined' && imageSource instanceof File) {
      const img = new Image();
      img.src = URL.createObjectURL(imageSource);
      await new Promise((resolve) => (img.onload = resolve));
      
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Scale appropriately: if image is huge, scale down; if small, scale up.
        // Target max dimension around 1500px for good speed/accuracy tradeoff.
        const maxDim = Math.max(img.width, img.height);
        const scale = maxDim > 1500 ? 1500 / maxDim : (maxDim < 800 ? 2.0 : 1.0);
        
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        
        // Use better interpolation if available
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        
        ctx.scale(scale, scale);
        ctx.drawImage(img, 0, 0);
        
        // Advanced Computer Vision Preprocessing Pipeline
        // 1. Convert to high-contrast grayscale
        const width = canvas.width;
        const height = canvas.height;
        let imageData = ctx.getImageData(0, 0, width, height);
        let data = imageData.data;
        
        const grayData = new Uint8Array(width * height);
        for (let i = 0; i < data.length; i += 4) {
          // Standard luminance
          grayData[i / 4] = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
        }

        // 2. Adaptive Local Thresholding (Bradley-Roth inspired)
        // Removes shadows and glare by comparing pixel to its local neighborhood average
        const s = Math.floor(width / 16); // Window size
        const t = 15; // Threshold percentage
        
        // Compute integral image for fast local averaging
        const integral = new Uint32Array(width * height);
        for (let y = 0; y < height; y++) {
          let sum = 0;
          for (let x = 0; x < width; x++) {
            sum += grayData[y * width + x];
            if (y === 0) {
              integral[y * width + x] = sum;
            } else {
              integral[y * width + x] = integral[(y - 1) * width + x] + sum;
            }
          }
        }

        // Apply adaptive threshold
        for (let y = 0; y < height; y++) {
          for (let x = 0; x < width; x++) {
            const x1 = Math.max(x - s, 0);
            const x2 = Math.min(x + s, width - 1);
            const y1 = Math.max(y - s, 0);
            const y2 = Math.min(y + s, height - 1);
            
            const count = (x2 - x1) * (y2 - y1);
            
            let sum = integral[y2 * width + x2];
            if (y1 > 0 && x1 > 0) sum += integral[(y1 - 1) * width + (x1 - 1)];
            if (y1 > 0) sum -= integral[(y1 - 1) * width + x2];
            if (x1 > 0) sum -= integral[y2 * width + (x1 - 1)];
            
            const idx = (y * width + x) * 4;
            // If pixel is darker than the local average (minus t%), it's text (black), else background (white)
            if (grayData[y * width + x] * count <= sum * (100 - t) / 100) {
              data[idx] = 0; data[idx+1] = 0; data[idx+2] = 0;
            } else {
              data[idx] = 255; data[idx+1] = 255; data[idx+2] = 255;
            }
          }
        }
        
        ctx.putImageData(imageData, 0, 0);
        processedSource = canvas.toDataURL('image/png', 1.0);
      }
    }

    // Set initialization options to improve recognition of product labels/packages
    const result = await Tesseract.recognize(processedSource, 'eng', {
      logger: (m) => {
        if (m.status && onProgress) {
          const progress = typeof m.progress === 'number' ? Math.round(m.progress * 100) : 0;
          onProgress(progress, m.status);
        }
      }
    });

    const text = result.data.text?.trim() || '';
    const confidence = result.data.confidence || 0;

    // Find the largest text block (Product Name / Logo) using a heuristic scoring model
    let bestProductName = '';
    let highestScore = -1000;
    
    // We need the overall image height to determine text position
    // If we don't have it directly from Tesseract, we estimate based on max y1
    let maxY = 0;
    const dataAny = result.data as any;
    if (dataAny.lines) {
      dataAny.lines.forEach((line: any) => { if (line.bbox && line.bbox.y1 > maxY) maxY = line.bbox.y1; });
    }

    if (dataAny.lines && dataAny.lines.length > 0) {
      // 1. Calculate the median text height on the label
      const heights = dataAny.lines
        .filter((line: any) => line.bbox)
        .map((line: any) => line.bbox.y1 - line.bbox.y0)
        .sort((a: number, b: number) => a - b);
      
      const medianHeight = heights.length > 0 ? heights[Math.floor(heights.length / 2)] : 0;
      
      // STRICT LOGO REQUIREMENT: A logo must be significantly larger than normal body text.
      // If the largest text is not at least 1.8x the median text size, we assume there is no
      // distinct logo detected (just a wall of text), and we leave it blank for manual entry.
      const LOGO_HEIGHT_THRESHOLD = medianHeight * 1.8;

      dataAny.lines.forEach((line: any) => {
        if (!line.bbox) return;
        
        const cleanText = line.text.trim();
        const height = line.bbox.y1 - line.bbox.y0;
        const width = line.bbox.x1 - line.bbox.x0;
        const yCenter = (line.bbox.y0 + line.bbox.y1) / 2;
        
        // Base requirements: Must have letters, be at least 3 chars long
        if (cleanText.length < 3 || !/[a-zA-Z]{2,}/.test(cleanText)) return;
        
        // STRICT LOGO CHECK: Is this text actually a logo/brand name?
        if (height < LOGO_HEIGHT_THRESHOLD) return;
        
        // --- HEURISTIC SCORING MODEL ---
        let score = 0;
        
        // 1. Size Score (Larger text = higher probability of being a brand/logo)
        score += (height * 2.0); 
        score += (width * 0.1);
        
        // 2. Position Score (Brand names are usually in the top 40% of the package)
        if (maxY > 0) {
          const relativePos = yCenter / maxY;
          if (relativePos < 0.2) score += 50;
          else if (relativePos < 0.4) score += 25;
          else if (relativePos > 0.7) score -= 50; // Penalize text at the very bottom
        }
        
        // 3. Word Count / Format Score (Product names are usually 1-4 words)
        const words = cleanText.split(/\s+/);
        if (words.length >= 1 && words.length <= 4) score += 30;
        if (words.length > 5) score -= (words.length * 10); // Heavy penalty for long sentences
        
        // 4. Alpha Ratio (Penalize strings that are mostly numbers or symbols)
        const alphaCount = (cleanText.match(/[a-zA-Z]/g) || []).length;
        const alphaRatio = alphaCount / cleanText.length;
        if (alphaRatio < 0.5) score -= 100; // Likely a barcode, weight, or date
        
        // 5. Keyword Penalization (Ensure we don't pick up common label declarations)
        const lowerText = cleanText.toLowerCase();
        const blacklist = ['net', 'weight', 'mrp', 'rs', 'inclusive', 'taxes', 'mfg', 'manufactured', 'ingredients', 'nutritional', 'consumer', 'care', 'address', 'best before', 'expiry', 'date', 'batch', 'kcal', 'energy', 'protein', 'customer'];
        const hasBlacklistedWord = blacklist.some(word => lowerText.includes(word));
        if (hasBlacklistedWord) score -= 500;
        
        // Update the best candidate
        if (score > highestScore) {
          highestScore = score;
          bestProductName = cleanText;
        }
      });
    }

    if (!text) {
      return {
        text: '',
        confidence: 0,
        success: false,
        error: 'No text could be extracted from the image. Please try a clearer image.',
      };
    }

    return { text, confidence, success: true, largestText: bestProductName };
  } catch (error) {
    console.error('OCR Error:', error);
    return {
      text: '',
      confidence: 0,
      success: false,
      error: 'OCR processing failed. Please try again or enter details manually.',
    };
  }
}
