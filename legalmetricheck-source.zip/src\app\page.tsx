"use client";

import React, { useState, Suspense } from 'react';
import Link from 'next/link';
import { ArrowRight, Sparkles, Layers, Cpu, RotateCcw, Brain } from 'lucide-react';
import { WebGLShader } from '@/components/ui/web-gl-shader';
import { DemoModal } from '@/components/DemoModal';

export default function Home() {
  const [distortion, setDistortion] = useState(0.05);
  const [xScale, setXScale] = useState(1.0);
  const [yScale, setYScale] = useState(0.5);
  const [yOffset, setYOffset] = useState(0.0);

  const resetShader = () => {
    setDistortion(0.05);
    setXScale(1.0);
    setYScale(0.5);
    setYOffset(0.0);
  };

  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);

  return (
    <div className="bg-[#09090b] text-white min-h-screen selection:bg-purple-500/30 selection:text-white flex flex-col items-center">
      {/* SVG Filter for Liquid Glass Button */}
      <svg aria-hidden="true" className="absolute w-0 h-0 pointer-events-none opacity-0">
        <defs>
          <filter colorInterpolationFilters="sRGB" height="100%" id="container-glass" width="100%" x="0%" y="0%">
            <feTurbulence baseFrequency="0.05 0.05" numOctaves={1} result="turbulence" seed={1} type="fractalNoise" />
            <feGaussianBlur in="turbulence" result="blurredNoise" stdDeviation="2" />
            <feDisplacementMap in="SourceGraphic" in2="blurredNoise" result="displaced" scale="40" xChannelSelector="R" yChannelSelector="B" />
            <feGaussianBlur in="displaced" result="finalBlur" stdDeviation="3" />
            <feComposite in="finalBlur" in2="finalBlur" operator="over" />
          </filter>
        </defs>
      </svg>

      {/* Navigation Bar: Perfectly Balanced and Symmetrical */}
      <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/10 bg-black/50 backdrop-blur-xl transition-all">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          {/* Left Anchor (balanced width) */}
          <div className="flex items-center gap-3 w-56">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-tr from-purple-500 via-indigo-500 to-cyan-400 flex items-center justify-center font-black text-sm tracking-tighter shadow-lg shadow-purple-500/20 shrink-0 text-white">
              <Brain className="w-5 h-5" />
            </div>
            <div className="flex flex-col text-left">
              <span className="text-xs font-bold tracking-tight text-white uppercase">TEAM BRAIN&gt;EXE</span>
              <span className="text-[10px] text-zinc-400 font-mono">v2.4 Production</span>
            </div>
          </div>

          {/* Right Action (matching left width for symmetry) */}
          <div className="flex items-center justify-end w-56">
            <Link className="text-xs px-4 py-1.5 rounded-full bg-white text-black font-semibold hover:bg-zinc-200 transition shadow-sm tracking-wide" href="#variants">
              GET STARTED
            </Link>
          </div>
        </div>
      </header>

      {/* Fixed Fullscreen WebGL Canvas Background */}
      <Suspense fallback={<div className="fixed inset-0 bg-[#09090b] -z-10" />}>
        <WebGLShader distortion={distortion} xScale={xScale} yScale={yScale} yOffset={yOffset} />
      </Suspense>
      <div className="fixed inset-0 bg-radial from-transparent via-black/45 to-[#09090b]/95 pointer-events-none z-[1]" />

      {/* Central Page Wrapper */}
      <div className="relative z-10 w-full flex flex-col items-center justify-center px-4 pt-28 pb-20 max-w-5xl mx-auto mt-16">
        {/* Hero Box Outer Container (Symmetrical & Centered) */}
        <div className="relative border border-[#27272a] p-2.5 sm:p-3.5 w-full mx-auto rounded-3xl bg-black/40 backdrop-blur-xl glow-border">
          {/* Top Window Chrome: Harmoniously Balanced */}
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-[#27272a] mb-2.5 text-xs font-mono text-zinc-400">
            <div className="flex items-center gap-2 w-36">
              <div className="flex gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500/80"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 text-[11px] text-zinc-500 w-36" />
          </div>

          {/* Main Content Inner Section: Perfectly Center-Aligned */}
          <main className="relative border border-[#27272a] py-16 sm:py-20 px-6 sm:px-14 overflow-hidden rounded-2xl bg-gradient-to-b from-black/70 via-[#101014]/70 to-black/85 flex flex-col items-center justify-center text-center">
            {/* Subtle Grid Backdrop */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none"></div>
            
            {/* Available for New Projects Badge (Dead Center) */}
            <div className="relative z-10 mb-7 inline-flex items-center justify-center gap-2 px-4 py-1.5 rounded-full border border-emerald-500/25 bg-emerald-500/10 shadow-[0_0_24px_rgba(16,185,129,0.18)] backdrop-blur-md">
              <span className="relative flex h-2.5 w-2.5 items-center justify-center">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500"></span>
              </span>
              <p className="text-xs font-semibold text-emerald-400 tracking-wider uppercase font-mono">Available&nbsp;</p>
            </div>

            {/* Hero Headline: Symmetrical Two-Line Structure */}
            <h1 className="relative z-10 mb-5 text-white text-center text-5xl sm:text-6xl md:text-7xl lg:text-[5.25rem] font-extrabold tracking-tight leading-[1.08] drop-shadow-2xl max-w-4xl mx-auto">
              Legal Metrology<br/>
              <span className="bg-gradient-to-b from-white via-zinc-100 to-zinc-400 bg-clip-text text-transparent">Compliance Program</span>
            </h1>
            
            {/* Centered Explanatory Subtitles */}
            <div className="relative z-10 space-y-2 mb-9 max-w-2xl mx-auto">
              <p className="text-white/80 text-base sm:text-lg font-medium tracking-tight">
                Automated verification for packed commodities
              </p>
              <p className="text-zinc-400 text-sm sm:text-base font-normal">
                Ensure Strict adherence to statutory rules and declarations
              </p>
            </div>

            {/* Centered Dual CTA Buttons with Equal Dimensions & Symmetrical Flanking */}
            <div className="relative z-20 flex flex-col sm:flex-row items-center justify-center gap-5 w-full max-w-md mx-auto mb-14">
              {/* Primary: Liquid Glass Button */}
              <div className="relative group w-full sm:w-1/2">
                <Link href="/login" className="relative group w-full cursor-pointer inline-flex items-center justify-center gap-2.5 whitespace-nowrap rounded-full h-12 px-6 text-sm font-semibold text-white tracking-wide transition-all duration-300 hover:scale-[1.03] active:scale-[0.98] border border-white/30 overflow-hidden shadow-2xl bg-white/5 backdrop-blur-md" id="main-liquid-btn">
                  <div className="absolute inset-0 z-0 h-full w-full rounded-full liquid-glass-inner"></div>
                  <div className="absolute inset-0 isolate -z-10 h-full w-full overflow-hidden rounded-full liquid-backdrop bg-white/5"></div>
                  <span className="pointer-events-none z-10 relative flex items-center justify-center gap-2 font-medium tracking-normal text-white drop-shadow">
                    Let&apos;s Go
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </span>
                </Link>
                <div className="absolute -inset-1 bg-gradient-to-r from-purple-500/30 to-cyan-500/30 rounded-full blur-lg opacity-40 group-hover:opacity-80 transition duration-500 pointer-events-none -z-20"></div>
              </div>
              
              {/* Secondary: Symmetrical Metal Variant Button */}
              <div className="w-full sm:w-1/2">
                <div className="metal-btn-wrap relative inline-flex w-full transform-gpu rounded-full p-[1.25px] will-change-transform bg-gradient-to-b from-[#555] to-[#141416]">
                  <div className="absolute inset-[1px] transform-gpu rounded-full will-change-transform bg-gradient-to-b from-[#2a2a2e] via-[#18181b] to-[#09090b]"></div>
                  <button 
                    onClick={() => setIsDemoModalOpen(true)}
                    className="relative z-10 m-[1px] inline-flex w-full h-12 transform-gpu cursor-pointer items-center justify-center overflow-hidden rounded-full px-6 text-sm font-semibold will-change-transform outline-none text-zinc-100 hover:text-white [text-shadow:_0_-1px_0_rgb(0_0_0_/_80%)] bg-gradient-to-b from-[#222226] to-[#141416]"
                  >
                    <span className="flex items-center justify-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      Request A Demo
                    </span>
                  </button>
                </div>
              </div>
            </div>

            {/* Metrics/Stats Row: Centered 3-Column Symmetrical Grid with Centered Dividers */}
            <div className="relative z-10 w-full pt-8 border-t border-white/10 grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-0 divide-y sm:divide-y-0 sm:divide-x divide-white/10 text-center">
              <div className="px-4 py-2">
                <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white tracking-tight">5067</div>
                <div className="text-xs text-zinc-400 font-mono tracking-widest uppercase mt-1">TOTAL USERS</div>
              </div>
              <div className="px-4 py-2">
                <div className="text-2xl sm:text-3xl font-extrabold font-mono text-emerald-400 tracking-tight">3098</div>
                <div className="text-xs text-zinc-400 font-mono tracking-widest uppercase mt-1">ACTIVE USERS</div>
              </div>
              <div className="px-4 py-2">
                <div className="text-2xl sm:text-3xl font-extrabold font-mono text-purple-400 tracking-tight">40k+</div>
                <div className="text-xs text-zinc-400 font-mono tracking-widest uppercase mt-1">INVESTIGATIONS</div>
              </div>
            </div>
          </main>

          {/* Bottom Status Strip: Perfectly Balanced Across Central Axis */}
          <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#27272a] mt-2.5 text-[11px] font-mono text-zinc-500">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse"></span>
            </div>
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-purple-400"></span>
            </div>
          </div>
        </div>

        {/* Platform Capabilities / Symmetrical 3x2 Grid Section */}
        <section className="w-full mt-16 space-y-6" id="variants">
          {/* Section Header: Centered and Harmonious */}
          <div className="flex flex-col items-center justify-center text-center pb-4 border-b border-white/10">
            <h2 className="text-2xl font-bold text-white tracking-tight">PLATFORM CAPABILITIES</h2>
            <p className="text-xs text-zinc-400 max-w-md mt-1">Automated compliance engines, real-time validation modules, and legal rule verification.</p>
          </div>

          {/* Symmetrical 3x2 Feature Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
            {/* Card 1: Default Silver (Automated OCR) */}
            <div className="p-6 rounded-2xl border border-white/10 bg-black/40 backdrop-blur-md flex flex-col items-center justify-between text-center gap-5 hover:border-zinc-500/40 transition duration-300">
              <div className="w-full flex items-center justify-end border-b border-white/5 pb-2 text-xs font-mono text-zinc-400">
                <span className="w-2 h-2 rounded-full bg-zinc-400 shadow-[0_0_8px_rgba(212,212,216,0.6)]"></span>
              </div>
              <div className="w-full flex items-center justify-center py-3">
                <div className="metal-btn-wrap relative inline-flex w-full transform-gpu rounded-lg p-[1.25px] will-change-transform bg-gradient-to-b from-[#000] to-[#A0A0A0]">
                  <div className="absolute inset-[1px] transform-gpu rounded-lg will-change-transform bg-gradient-to-b from-[#FAFAFA] via-[#3E3E3E] to-[#E5E5E5]"></div>
                  <button className="relative z-10 m-[1px] w-full rounded-lg inline-flex h-11 transform-gpu cursor-pointer items-center justify-center overflow-hidden px-4 text-xs font-bold tracking-wider outline-none text-white [text-shadow:_0_-1px_0_rgb(80_80_80_/_100%)] bg-gradient-to-b from-[#B9B9B9] to-[#969696]">
                    AUTOMATED OCR
                  </button>
                </div>
              </div>
              <div className="text-[11px] font-mono text-zinc-400 text-center">
                Satin Silver Engine
              </div>
            </div>

            {/* Card 2: Primary Indigo (Real Time Validation) */}
            <div className="p-6 rounded-2xl border border-white/10 bg-black/40 backdrop-blur-md flex flex-col items-center justify-between text-center gap-5 hover:border-indigo-500/40 transition duration-300">
              <div className="w-full flex items-center justify-end border-b border-white/5 pb-2 text-xs font-mono text-zinc-400">
                <span className="w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.6)]"></span>
              </div>
              <div className="w-full flex items-center justify-center py-3">
                <div className="metal-btn-wrap relative inline-flex w-full transform-gpu rounded-lg p-[1.25px] will-change-transform bg-gradient-to-b from-[#000] to-[#A0A0A0]">
                  <div className="absolute inset-[1px] transform-gpu rounded-lg will-change-transform bg-gradient-to-b from-indigo-500 via-purple-700 to-indigo-950"></div>
                  <button className="relative z-10 m-[1px] w-full rounded-lg inline-flex h-11 transform-gpu cursor-pointer items-center justify-center overflow-hidden px-4 text-xs font-bold tracking-wider outline-none text-white [text-shadow:_0_-1px_0_rgb(30_58_138_/_100%)] bg-gradient-to-b from-indigo-600 to-indigo-800">
                    REAL TIME VALIDATION
                  </button>
                </div>
              </div>
              <div className="text-[11px] font-mono text-zinc-400 text-center">
                Deep Cobalt Sapphire
              </div>
            </div>

            {/* Card 3: Success Emerald (Success Checks) */}
            <div className="p-6 rounded-2xl border border-white/10 bg-black/40 backdrop-blur-md flex flex-col items-center justify-between text-center gap-5 hover:border-emerald-500/40 transition duration-300">
              <div className="w-full flex items-center justify-end border-b border-white/5 pb-2 text-xs font-mono text-zinc-400">
                <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]"></span>
              </div>
              <div className="w-full flex items-center justify-center py-3">
                <div className="metal-btn-wrap relative inline-flex w-full transform-gpu rounded-lg p-[1.25px] will-change-transform bg-gradient-to-b from-[#005A43] to-[#7CCB9B]">
                  <div className="absolute inset-[1px] transform-gpu rounded-lg will-change-transform bg-gradient-to-b from-[#E5F8F0] via-[#00352F] to-[#D1F0E6]"></div>
                  <button className="relative z-10 m-[1px] w-full rounded-lg inline-flex h-11 transform-gpu cursor-pointer items-center justify-center overflow-hidden px-4 text-xs font-bold tracking-wider outline-none text-[#FFF7F0] [text-shadow:_0_-1px_0_rgb(6_78_59_/_100%)] bg-gradient-to-b from-[#9ADBC8] to-[#3E8F7C]">
                    SUCCESS CHECKS
                  </button>
                </div>
              </div>
              <div className="text-[11px] font-mono text-zinc-400 text-center">
                Emerald Green Satin
              </div>
            </div>

            {/* Card 4: Gold Variant (Stationary Rules Engine) */}
            <div className="p-6 rounded-2xl border border-white/10 bg-black/40 backdrop-blur-md flex flex-col items-center justify-between text-center gap-5 hover:border-amber-500/40 transition duration-300">
              <div className="w-full flex items-center justify-end border-b border-white/5 pb-2 text-xs font-mono text-zinc-400">
                <span className="w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]"></span>
              </div>
              <div className="w-full flex items-center justify-center py-3">
                <div className="metal-btn-wrap relative inline-flex w-full transform-gpu rounded-lg p-[1.25px] will-change-transform bg-gradient-to-b from-[#917100] to-[#EAD98F]">
                  <div className="absolute inset-[1px] transform-gpu rounded-lg will-change-transform bg-gradient-to-b from-[#FFFDDD] via-[#856807] to-[#FFF1B3]"></div>
                  <button className="relative z-10 m-[1px] w-full rounded-lg inline-flex h-11 transform-gpu cursor-pointer items-center justify-center overflow-hidden px-4 text-xs font-bold tracking-wider outline-none text-[#FFFDE5] [text-shadow:_0_-1px_0_rgb(178_140_2_/_100%)] bg-gradient-to-b from-[#FFEBA1] to-[#9B873F]">
                    STATIONARY RULES ENGINE
                  </button>
                </div>
              </div>
              <div className="text-[11px] font-mono text-zinc-400 text-center">
                Polished Brass / Gold
              </div>
            </div>

            {/* Card 5: Error Ruby (Automated Citations) */}
            <div className="p-6 rounded-2xl border border-white/10 bg-black/40 backdrop-blur-md flex flex-col items-center justify-between text-center gap-5 hover:border-rose-500/40 transition duration-300">
              <div className="w-full flex items-center justify-end border-b border-white/5 pb-2 text-xs font-mono text-zinc-400">
                <span className="w-2 h-2 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]"></span>
              </div>
              <div className="w-full flex items-center justify-center py-3">
                <div className="metal-btn-wrap relative inline-flex w-full transform-gpu rounded-lg p-[1.25px] will-change-transform bg-gradient-to-b from-[#5A0000] to-[#FFAEB0]">
                  <div className="absolute inset-[1px] transform-gpu rounded-lg will-change-transform bg-gradient-to-b from-[#FFDEDE] via-[#680002] to-[#FFE9E9]"></div>
                  <button className="relative z-10 m-[1px] w-full rounded-lg inline-flex h-11 transform-gpu cursor-pointer items-center justify-center overflow-hidden px-4 text-xs font-bold tracking-wider outline-none text-[#FFF7F0] [text-shadow:_0_-1px_0_rgb(146_64_14_/_100%)] bg-gradient-to-b from-[#F08D8F] to-[#A45253]">
                    AUTOMATED CITATIONS
                  </button>
                </div>
              </div>
              <div className="text-[11px] font-mono text-zinc-400 text-center">
                Ruby Metallic Red
              </div>
            </div>

            {/* Card 6: Bronze Variant (Statutory Audit & Reports) */}
            <div className="p-6 rounded-2xl border border-white/10 bg-black/40 backdrop-blur-md flex flex-col items-center justify-between text-center gap-5 hover:border-orange-500/40 transition duration-300">
              <div className="w-full flex items-center justify-end border-b border-white/5 pb-2 text-xs font-mono text-zinc-400">
                <span className="w-2 h-2 rounded-full bg-amber-600 shadow-[0_0_8px_rgba(217,119,6,0.6)]"></span>
              </div>
              <div className="w-full flex items-center justify-center py-3">
                <div className="metal-btn-wrap relative inline-flex w-full transform-gpu rounded-lg p-[1.25px] will-change-transform bg-gradient-to-b from-[#593006] to-[#C99156]">
                  <div className="absolute inset-[1px] transform-gpu rounded-lg will-change-transform bg-gradient-to-b from-[#FFE8D1] via-[#5C2F04] to-[#F7D2A8]"></div>
                  <button className="relative z-10 m-[1px] w-full rounded-lg inline-flex h-11 transform-gpu cursor-pointer items-center justify-center overflow-hidden px-4 text-xs font-bold tracking-wider outline-none text-[#FFF8F0] [text-shadow:_0_-1px_0_rgb(120_53_15_/_100%)] bg-gradient-to-b from-[#D99B61] to-[#8C5222]">
                    STATUTORY AUDIT &amp; REPORTS
                  </button>
                </div>
              </div>
              <div className="text-[11px] font-mono text-zinc-400 text-center">
                Bronze Metallic Spec
              </div>
            </div>
          </div>

          {/* Live GLSL Shader Uniform Controls: Perfectly Centered & Symmetrical Layout */}
          <div className="p-6 sm:p-8 rounded-2xl border border-white/10 bg-black/75 backdrop-blur-2xl transition-all duration-300 mt-10" id="controls-panel">
            {/* Controls Header: Symmetrical Split */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6 border-b border-white/10 pb-4 text-center sm:text-left">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-md bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                  <Cpu className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Live GLSL Shader Uniform Controls</h3>
                  <p className="text-[11px] text-zinc-400 font-mono">Real-time parameters injected into fragment shader pipeline</p>
                </div>
              </div>
              <button 
                onClick={resetShader}
                className="text-xs px-4 py-1.5 rounded-full border border-white/15 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white transition shadow-sm font-mono flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset Defaults
              </button>
            </div>

            {/* 4 Uniform Sliders Symmetrically Positioned */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-xs">
              {/* Slider 1 */}
              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                <div className="flex justify-between items-center text-zinc-400 mb-2">
                  <span className="font-medium">distortion (warp factor)</span>
                  <span className="font-mono text-cyan-400 font-semibold px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40">
                    {distortion.toFixed(3)}
                  </span>
                </div>
                <input 
                  className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg" 
                  max="0.25" min="0.00" step="0.005" type="range" 
                  value={distortion}
                  onChange={(e) => setDistortion(parseFloat(e.target.value))}
                />
              </div>

              {/* Slider 2 */}
              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                <div className="flex justify-between items-center text-zinc-400 mb-2">
                  <span className="font-medium">xScale (frequency)</span>
                  <span className="font-mono text-cyan-400 font-semibold px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40">
                    {xScale.toFixed(2)}
                  </span>
                </div>
                <input 
                  className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg" 
                  max="3.0" min="0.2" step="0.1" type="range" 
                  value={xScale}
                  onChange={(e) => setXScale(parseFloat(e.target.value))}
                />
              </div>

              {/* Slider 3 */}
              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                <div className="flex justify-between items-center text-zinc-400 mb-2">
                  <span className="font-medium">yScale (amplitude)</span>
                  <span className="font-mono text-cyan-400 font-semibold px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40">
                    {yScale.toFixed(2)}
                  </span>
                </div>
                <input 
                  className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg" 
                  max="1.5" min="0.1" step="0.05" type="range" 
                  value={yScale}
                  onChange={(e) => setYScale(parseFloat(e.target.value))}
                />
              </div>

              {/* Slider 4 */}
              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                <div className="flex justify-between items-center text-zinc-400 mb-2">
                  <span className="font-medium">yOffset (shift)</span>
                  <span className="font-mono text-cyan-400 font-semibold px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40">
                    {yOffset.toFixed(2)}
                  </span>
                </div>
                <input 
                  className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg" 
                  max="1.0" min="-1.0" step="0.05" type="range" 
                  value={yOffset}
                  onChange={(e) => setYOffset(parseFloat(e.target.value))}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Balanced Centered Footer */}
        <footer className="w-full max-w-4xl mx-auto mt-14 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-500 font-mono gap-3 text-center sm:text-left">
          <div>© TEAM BRAIN&gt;EXE • Legal Metrology Division</div>
          <div className="flex items-center gap-4">
            <span className="hover:text-zinc-400 cursor-pointer">Three.js R128</span>
            <span>•</span>
            <span className="hover:text-zinc-400 cursor-pointer">GLSL Shaders</span>
            <span>•</span>
            <span className="hover:text-zinc-400 cursor-pointer">Symmetrical Systems</span>
          </div>
        </footer>
      </div>
      
      <DemoModal isOpen={isDemoModalOpen} onClose={() => setIsDemoModalOpen(false)} />
    </div>
  );
}
