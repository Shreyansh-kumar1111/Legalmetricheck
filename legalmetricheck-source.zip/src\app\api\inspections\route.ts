// ============================================================
// LegalMetriCheck — Inspections API (list & create)
// ============================================================

import { NextRequest, NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Inspection from '@/models/Inspection';
import { getSessionUserId } from '@/lib/auth';
import { getRuntimeInspections, addRuntimeInspection } from '@/lib/demoData';
import { generateInspectionId } from '@/lib/utils';
import { validateProduct } from '@/lib/engine/validator';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const search = searchParams.get('search');

    let inspections;
    try {
      await connectDB();
      const query: Record<string, unknown> = {};
      if (status && status !== 'ALL') query.status = status;
      if (search) {
        query.$or = [
          { productName: { $regex: search, $options: 'i' } },
          { inspectionId: { $regex: search, $options: 'i' } },
          { officerName: { $regex: search, $options: 'i' } },
        ];
      }
      inspections = await Inspection.find(query).sort({ createdAt: -1 }).lean();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      inspections = inspections.map((i: any) => ({ ...i, _id: i._id.toString() }));
    } catch {
      // Fallback to in-memory runtime store if DB not available
      inspections = getRuntimeInspections(status, search);
    }

    return NextResponse.json({ success: true, data: inspections });
  } catch (error) {
    console.error('Fetch inspections error:', error);
    return NextResponse.json({ success: true, data: getRuntimeInspections() });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const userId = await getSessionUserId();

    // Auto-calculate validation if not provided
    const evalResult = (!body.validationResults || !body.status)
      ? validateProduct(body.extractedFields || {})
      : null;

    const validationResults = body.validationResults || evalResult?.results || [];
    const status = body.status || evalResult?.status || 'NEEDS_REVIEW';
    const complianceScore = body.complianceScore !== undefined
      ? body.complianceScore
      : (evalResult?.complianceScore ?? 0);

    const inspectionData = {
      inspectionId: generateInspectionId(),
      userId: userId || 'demo',
      productName: body.productName || 'Unknown Product',
      imageBase64: body.imageBase64 || '',
      ocrRawText: body.ocrRawText || '',
      extractedFields: body.extractedFields || {},
      validationResults,
      status,
      complianceScore,
      officerName: body.officerName || 'Inspector Rajesh Kumar',
      createdAt: new Date().toISOString(),
    };

    try {
      await connectDB();
      const inspection = await Inspection.create(inspectionData);
      const saved = { ...inspectionData, _id: inspection._id.toString() };
      addRuntimeInspection(saved as Parameters<typeof addRuntimeInspection>[0]);
      return NextResponse.json({
        success: true,
        data: saved,
      }, { status: 201 });
    } catch {
      // If DB fails, save to runtime store so that the app functions seamlessly offline/demo
      const saved = { ...inspectionData, _id: `demo-${Date.now()}` };
      addRuntimeInspection(saved as Parameters<typeof addRuntimeInspection>[0]);
      return NextResponse.json({
        success: true,
        data: saved,
      }, { status: 201 });
    }
  } catch (error) {
    console.error('Create inspection error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create inspection' },
      { status: 500 }
    );
  }
}
