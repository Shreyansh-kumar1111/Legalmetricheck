'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  Brain,
  LayoutDashboard,
  PlusCircle,
  History,
  BookOpen,
  BarChart3,
  Settings,
  Search,
  Bell,
  LogOut,
  Menu,
  X,
  Zap,
} from 'lucide-react';
import { UserData } from '@/types';
import { ThemeSwitcher } from '@/components/ThemeSwitcher';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { UserProvider } from '@/contexts/UserContext';
import { ShaderBackground } from '@/components/ui/shader-background';

// NAV_GROUPS are generated dynamically based on role

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<UserData | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    const fetchUser = () => {
      fetch(`/api/auth/me?t=${Date.now()}`)
        .then((res) => res.json())
        .then((data) => {
          if (!data.success) {
            window.location.href = '/login';
          } else {
            setUser(data.data);
          }
        })
        .catch(() => {
          setUser({
            _id: 'demo-officer-1',
            name: 'Inspector Rajesh Kumar',
            email: 'officer@legalmetri.demo',
            role: 'Senior Field Officer',
            department: 'Legal Metrology Dept',
          });
        });
    };

    fetchUser();

    // Since we now rely purely on Auth context, profile update events can just re-fetch
    const handleProfileUpdate = () => {
      fetchUser();
    };

    window.addEventListener('profileUpdated', handleProfileUpdate);
    return () => window.removeEventListener('profileUpdated', handleProfileUpdate);
  }, [router]);

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    window.location.href = '/login';
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/dashboard/history?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const isAuditor = user?.role?.toLowerCase().includes('auditor') || false;

  const NAV_GROUPS = [
    {
      title: 'Audit Workflow',
      items: [
        { href: '/dashboard', icon: LayoutDashboard, label: 'Overview' },
        (!isAuditor ? { href: '/dashboard/inspect', icon: PlusCircle, label: 'New Inspection', highlight: true } : null),
        { href: '/dashboard/history', icon: History, label: 'Audit Records' },
      ].filter(Boolean) as any[],
    },
    {
      title: 'Statutory & System',
      items: [
        { href: '/dashboard/rules', icon: BookOpen, label: 'Statutory Rules' },
        (isAuditor ? { href: '/dashboard/reports', icon: BarChart3, label: 'Reports & Trends' } : null),
        { href: '/dashboard/settings', icon: Settings, label: 'Settings' },
      ].filter(Boolean) as any[],
    },
  ];

  return (
    <UserProvider user={user} loading={user === null}>
    <div className="min-h-screen w-full flex selection:bg-indigo-600 selection:text-[var(--text-color)] font-sans relative overflow-x-hidden transition-colors duration-300">
      {/* Ambient background shader */}
      <div className="fixed inset-0 pointer-events-none -z-20">
        <ShaderBackground className="absolute inset-0" />
      </div>
      
      {/* Contrast Overlay & Micro-dot grid */}
      <div className="fixed inset-0 pointer-events-none -z-10 bg-white/20 dark:bg-black/70 backdrop-blur-[8px] sm:backdrop-blur-[12px]" />
      <div className="fixed inset-0 pointer-events-none -z-10 moody-dot-grid opacity-20 dark:opacity-40" />

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 lg:hidden transition-opacity"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Clean Spacious Minimal Sidebar — Fixed width w-72 for proper breathing space */}
      <aside
        className={`
          fixed lg:static inset-y-0 left-0 z-50 w-72 bg-white/80 dark:bg-black/60 backdrop-blur-3xl text-[var(--text-color)] flex flex-col transition-all duration-300 ease-out border-r border-[var(--border-color)] dark:border-[var(--border-color)] shadow-[5px_0_30px_rgba(0,0,0,0.15)] dark:shadow-[5px_0_30px_rgba(0,0,0,0.8)] shrink-0
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Brand Header */}
        <div className="h-20 px-6 border-b border-[var(--border-color)] dark:border-[var(--border-color)] flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center gap-3.5 group">
            <div className="w-10 h-10 rounded-2xl bg-indigo-950/60 border border-indigo-500/30 flex items-center justify-center text-[var(--text-color)] shadow-sm group-hover:border-indigo-500/60 transition">
              <Brain className="w-5 h-5 text-indigo-300" />
            </div>
            <div>
              <span className="font-bold text-lg tracking-tight text-[var(--text-color)] block transition-colors duration-300">
                Team <span className="text-indigo-400">brain.exe</span>
              </span>
              <span className="text-xs font-mono tracking-wider text-[var(--text-muted)] block -mt-0.5">
                Compliance Studio
              </span>
            </div>
          </Link>

          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-2 rounded-xl text-[var(--text-muted)] hover:text-[var(--text-color)] hover:bg-[var(--border-color)] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Sections with Proper Spacing & 2-4pt Larger Typography */}
        <div className="flex-1 py-8 px-4 space-y-8 overflow-y-auto">
          {NAV_GROUPS.map((group, gIdx) => (
            <div key={gIdx} className="space-y-2">
              <span className="px-3.5 py-1.5 mx-2 bg-black/5 dark:bg-white/5 rounded-md text-[11px] font-bold uppercase tracking-[0.2em] text-[var(--text-color)]/80 block select-none mb-3 shadow-sm border border-black/5 dark:border-white/5">
                {group.title}
              </span>

              <div className="space-y-1.5">
                {group.items.map((item) => {
                  const isActive =
                    pathname === item.href ||
                    (item.href !== '/dashboard' && pathname.startsWith(item.href));

                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      prefetch={true}
                      onClick={() => setSidebarOpen(false)}
                      className={`
                        flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 select-none
                        ${
                          isActive
                            ? 'bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-400/50 shadow-md ring-1 ring-indigo-500/20'
                            : item.highlight
                            ? 'text-indigo-700 dark:text-indigo-200 bg-indigo-500/5 hover:bg-indigo-500/15 hover:text-indigo-900 dark:hover:text-indigo-100 border border-indigo-300 dark:border-indigo-500/35 hover:border-indigo-400 dark:hover:border-indigo-400/60 shadow-sm'
                            : 'text-[var(--text-color)] bg-white/40 dark:bg-black/20 backdrop-blur-sm border border-[var(--border-color)] hover:border-slate-300 dark:hover:border-slate-700 hover:bg-white/60 dark:hover:bg-black/40 shadow-sm'
                        }
                      `}
                    >
                      <item.icon className={`w-5 h-5 shrink-0 ${isActive ? 'text-indigo-400' : 'text-[var(--text-muted)]'}`} />
                      <span className="truncate">{item.label}</span>
                      {item.highlight && !isActive && (
                        <span className="ml-auto text-xs font-mono tracking-wider bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-md border border-indigo-500/30">
                          Scan
                        </span>
                      )}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Officer Profile Badge */}
        <div className="p-4 border-t border-[var(--border-color)] bg-[var(--card-bg)]/80 backdrop-blur-md">
          <div className="flex items-center justify-between p-3 rounded-2xl bg-white/40 dark:bg-black/40 backdrop-blur-sm border border-[var(--border-color)] shadow-sm">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-300 text-sm font-bold shrink-0">
                {user?.name ? user.name.charAt(0) : 'R'}
              </div>
              <div className="min-w-0">
                <span className="text-sm font-semibold text-[var(--text-color)] block truncate">
                  {user?.name || 'Inspector Rajesh Kumar'}
                </span>
                <span className="text-xs text-[var(--text-muted)] block truncate font-light">
                  {user?.role || 'Senior Field Officer'}
                </span>
              </div>
            </div>

            <button
              onClick={handleLogout}
              className="p-2 text-[var(--text-muted)] hover:text-rose-400 hover:bg-rose-950/40 rounded-xl transition ml-1"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-transparent text-[var(--text-color)] transition-colors duration-300">
        {/* Top Header */}
        <header className="h-20 bg-white/80 dark:bg-black/60 backdrop-blur-2xl border-b border-[var(--border-color)] dark:border-[var(--border-color)] px-6 sm:px-8 lg:px-10 flex items-center justify-between gap-6 sticky top-0 z-30 transition-colors duration-300 shadow-sm">
          <div className="flex items-center gap-4 flex-1">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl text-[var(--text-color)] hover:bg-[var(--border-color)] transition border border-[var(--border-color)]"
              aria-label="Open sidebar"
            >
              <Menu className="w-6 h-6" />
            </button>

            {/* Quick Search Bar with Structured Border & Zero Collision */}
            <form
              onSubmit={handleSearch}
              className="relative w-full max-w-md hidden sm:flex items-center gap-3 px-4 py-2.5 rounded-xl bg-[var(--border-color)] border border-[var(--border-color)] focus-within:border-indigo-500/60 focus-within:bg-white/[0.07] focus-within:ring-2 focus-within:ring-indigo-500/20 transition-all shadow-sm group"
            >
              <Search className="w-4 h-4 text-[var(--text-muted)] group-focus-within:text-indigo-400 shrink-0 pointer-events-none transition-colors" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search commodity, ID, or rule..."
                className="w-full bg-transparent text-sm font-normal text-[var(--text-color)] placeholder:text-[var(--text-muted)]/70 focus:outline-none leading-normal tracking-wide transition-colors duration-300"
              />
              {searchQuery ? (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="text-xs text-[var(--text-muted)] hover:text-[var(--text-color)] p-1 rounded transition hover:bg-[var(--border-color)]"
                  aria-label="Clear search"
                >
                  ✕
                </button>
              ) : (
                <kbd className="hidden md:inline-flex items-center px-2 py-0.5 text-[10px] font-mono text-[var(--text-muted)] bg-[var(--border-color)] border border-[var(--border-color)] rounded select-none shrink-0">
                  Enter
                </kbd>
              )}
            </form>
          </div>

          <div className="flex items-center gap-4">
            <LanguageSwitcher />
            <ThemeSwitcher />
            
            {/* Notifications Popover */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2.5 rounded-xl text-[var(--text-color)] hover:text-[var(--text-color)] bg-[var(--border-color)] border border-[var(--border-color)] hover:border-[var(--border-color)] hover:bg-[var(--border-color)] transition relative min-h-[42px] min-w-[42px] flex items-center justify-center cursor-pointer shadow-sm"
                aria-label="View notifications"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-indigo-400" />
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-3 w-80 sm:w-96 rounded-2xl moody-card border border-[var(--border-color)] shadow-2xl z-50 p-5 space-y-3.5 animate-fade-in-scale">
                  <div className="flex items-center justify-between pb-3 border-b border-[var(--border-color)]">
                    <span className="text-sm font-semibold text-[var(--text-color)] flex items-center gap-2">
                      <Bell className="w-4 h-4 text-indigo-400" />
                      Statutory Notifications
                    </span>
                    <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-[var(--border-color)] text-[var(--text-color)] border border-[var(--border-color)]">
                      3 Active
                    </span>
                  </div>

                  <div className="space-y-2.5 text-xs sm:text-sm">
                    <div className="p-3 rounded-xl bg-[var(--border-color)] border border-[var(--border-color)] space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-[var(--text-color)]">Rule 6(1)(da) Flag</span>
                        <span className="text-xs text-[var(--text-muted)]">10m ago</span>
                      </div>
                      <p className="text-[var(--text-color)] leading-relaxed font-light">
                        Packaged snack commodity flagged for missing Unit Sale Price.
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-[var(--border-color)] border border-[var(--border-color)] space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-[var(--text-color)]">Gazette Notification</span>
                        <span className="text-xs text-[var(--text-muted)]">2h ago</span>
                      </div>
                      <p className="text-[var(--text-color)] leading-relaxed font-light">
                        Department of Consumer Affairs statutory guidance active.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Clean Action Button — 2-4pt larger */}
            <Link
              href="/dashboard/inspect"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold text-slate-950 bg-white hover:bg-slate-100 shadow-sm hover:shadow-md transition active:scale-95"
            >
              <Zap className="w-4 h-4 text-slate-950" />
              <span>New Scan</span>
            </Link>
          </div>
        </header>

        {/* Dynamic Page Content */}
        <main className="flex-1 p-6 sm:p-8 lg:p-10 overflow-y-auto bg-white/10 dark:bg-black/20">
          <div className="max-w-7xl mx-auto w-full transition-colors duration-300">
            {children}
          </div>
        </main>
      </div>
    </div>
    </UserProvider>
  );
}
