'use client';

import React, { useState, useEffect } from 'react';
import { BarChart3, Download, FileText, PieChart, Printer, TrendingUp, AlertTriangle, Sparkles } from 'lucide-react';
import { DashboardStats } from '@/types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart as RPieChart,
  Pie,
} from 'recharts';
import { getDemoStats } from '@/lib/demoData';

export default function ReportsPage() {
  const [stats, setStats] = useState<DashboardStats | null>(getDemoStats());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch('/api/inspections/stats')
      .then((res) => res.json())
      .then((data) => {
        if (data.success) setStats(data.data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading || !stats) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] space-y-3">
        <div className="w-10 h-10 border-3 border-indigo-900 border-t-indigo-500 rounded-full animate-spin" />
        <p className="text-sm font-semibold text-[var(--text-muted)]">Loading compliance analytics...</p>
      </div>
    );
  }

  const pieData = [
    { name: 'Compliant', value: stats.compliant, color: '#10b981' },
    { name: 'Non-Compliant', value: stats.nonCompliant, color: '#f43f5e' },
    { name: 'Needs Review', value: stats.needsReview, color: '#f59e0b' },
  ];

  const handleExportCSV = () => {
    if (!stats) return;
    const csvContent = [
      ['Metric', 'Value'],
      ['Total Inspections', stats.total],
      ['Compliant', stats.compliant],
      ['Non-Compliant', stats.nonCompliant],
      ['Needs Review', stats.needsReview],
      ['Overall Compliance Rate', `${stats.complianceRate}%`],
      [''],
      ['Month', 'Compliant', 'Non-Compliant', 'Needs Review'],
      ...stats.monthlyData.map((m) => [m.month, m.compliant, m.nonCompliant, m.needsReview]),
    ]
      .map((e) => e.join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `legalmetricheck_report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5 pb-6 border-b border-[var(--border-color)]">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-950/80 text-indigo-300 border border-indigo-700/60 mb-2">
            <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
            <span>Compliance Analytics</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[var(--text-color)] tracking-tight">
            Analytics & Reports
          </h1>
          <p className="text-sm text-[var(--text-muted)] mt-1">
            Aggregated compliance metrics, trends, and distribution reports.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 sm:gap-3 print:hidden w-full sm:w-auto">
          <button
            onClick={() => window.print()}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-[var(--text-color)] bg-[var(--card-bg)] border border-[var(--border-color)] hover:bg-[var(--card-bg)] transition shadow-sm cursor-pointer min-h-[44px]"
          >
            <Printer className="w-4 h-4 text-[var(--text-muted)]" />
            <span>Print Report</span>
          </button>
          <button
            onClick={handleExportCSV}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-[var(--text-color)] bg-indigo-600 hover:opacity-95 shadow-lg shadow-indigo-500/25 transition cursor-pointer hover:scale-[1.02] min-h-[44px]"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="p-6 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 shadow-sm text-center space-y-1 backdrop-blur-sm">
          <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
            Overall Compliance Rate
          </span>
          <p className="text-4xl font-extrabold text-emerald-400">
            {stats.complianceRate}%
          </p>
          <p className="text-[11px] text-emerald-500/80 font-medium">Standard baseline threshold: 85%</p>
        </div>

        <div className="p-6 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 shadow-sm text-center space-y-1 backdrop-blur-sm">
          <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider">
            Total Inspected Units
          </span>
          <p className="text-4xl font-extrabold text-[var(--text-color)]">{stats.total}</p>
          <p className="text-[11px] text-indigo-400/80 font-medium">Recorded in active dossier</p>
        </div>

        <div className="p-6 rounded-2xl bg-rose-950/40 border border-rose-500/30 shadow-sm text-center space-y-1 backdrop-blur-sm">
          <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">
            Total Violations Flagged
          </span>
          <p className="text-4xl font-extrabold text-rose-400">{stats.nonCompliant}</p>
          <p className="text-[11px] text-rose-500/80 font-medium">Form VI statutory notices drafted</p>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Monthly Trend */}
        <div className="lg:col-span-8 rounded-3xl p-5 sm:p-7 space-y-5 bg-white/40 dark:bg-black/40 backdrop-blur-xl border border-[var(--border-color)] shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-[var(--border-color)]">
            <div>
              <h3 className="font-bold text-base text-[var(--text-color)]">Historical Compliance Trends</h3>
              <p className="text-xs text-[var(--text-muted)] mt-0.5">Monthly distribution of audited commodities</p>
            </div>
            <div className="w-8 h-8 rounded-xl bg-indigo-950/80 text-indigo-400 border border-indigo-700/50 flex items-center justify-center">
              <BarChart3 className="w-4 h-4" />
            </div>
          </div>

          <div className="h-72 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#07090E',
                    borderRadius: '12px',
                    border: '1px solid rgba(255,255,255,0.15)',
                    boxShadow: '0 10px 25px -5px rgba(0,0,0,0.7)',
                    fontSize: '12px',
                    fontWeight: 600,
                    color: '#ffffff',
                  }}
                  itemStyle={{ color: '#ffffff' }}
                />
                <Bar dataKey="compliant" name="Compliant" fill="#10b981" radius={[6, 6, 0, 0]} />
                <Bar dataKey="nonCompliant" name="Non-Compliant" fill="#f43f5e" radius={[6, 6, 0, 0]} />
                <Bar dataKey="needsReview" name="Needs Review" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Status Distribution Pie */}
        <div className="lg:col-span-4 rounded-3xl p-5 sm:p-7 flex flex-col justify-between space-y-6 bg-white/40 dark:bg-black/40 backdrop-blur-xl border border-[var(--border-color)] shadow-xl">
          <div className="pb-3 border-b border-[var(--border-color)]">
            <h3 className="font-bold text-base text-[var(--text-color)]">Compliance Distribution</h3>
            <p className="text-xs text-[var(--text-muted)] mt-0.5">Ratio of audit outcomes</p>
          </div>

          <div className="h-52 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <RPieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={75}
                  paddingAngle={6}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderRadius: '12px',
                    border: '1px solid rgba(255,255,255,0.15)',
                    boxShadow: '0 10px 25px -5px rgba(0,0,0,0.5)',
                    fontSize: '12px',
                    color: '#ffffff',
                  }}
                  itemStyle={{ color: '#ffffff' }}
                />
              </RPieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2.5 pt-3 border-t border-[var(--border-color)]">
            {pieData.map((item) => (
              <div key={item.name} className="flex items-center justify-between text-xs sm:text-sm">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-[var(--text-color)] font-medium">{item.name}</span>
                </div>
                <span className="font-bold text-[var(--text-color)]">{item.value} units</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
