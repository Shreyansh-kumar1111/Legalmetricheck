async function testInspectionCreation() {
  console.log('Testing Inspection Creation & Evaluation API...\n');

  const payload = {
    productName: 'ChocoDelight Cookies 150g',
    brandName: 'SweetBites',
    category: 'Food & Beverages',
    extractedFields: {
      mrp: { value: '₹ 45.00', confidence: 0.95, isPresent: true },
      netQuantity: { value: '150 g', confidence: 0.94, isPresent: true },
      unitSalePrice: { value: '₹ 0.30 / g', confidence: 0.88, isPresent: true },
      manufacturerName: { value: 'SweetBites Confectionery Pvt Ltd', confidence: 0.92, isPresent: true },
      manufacturerAddress: { value: 'Plot 42, Industrial Area, Sector 58, Gurugram, Haryana 122001', confidence: 0.90, isPresent: true },
      manufacturingDate: { value: '15/01/2026', confidence: 0.93, isPresent: true },
      expiryDate: { value: '15/07/2026', confidence: 0.91, isPresent: true },
      consumerCare: { value: '1800-123-4567, care@sweetbites.com', confidence: 0.95, isPresent: true },
      countryOfOrigin: { value: 'India', confidence: 0.98, isPresent: true }
    },
    officerName: 'Inspector Rajesh Kumar'
  };

  const createRes = await fetch('http://localhost:3000/api/inspections', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const createJson = await createRes.json();
  console.log('Create Inspection Response status:', createRes.status);
  console.log('Inspection ID:', createJson.data?.inspectionId);
  console.log('Overall Status:', createJson.data?.overallStatus);
  console.log('Compliance Score:', createJson.data?.complianceScore + '%');
  console.log('Total Checks:', createJson.data?.validationResults?.length);

  if (createJson.data?.inspectionId) {
    const detailRes = await fetch(`http://localhost:3000/api/inspections/${createJson.data.inspectionId}`);
    const detailJson = await detailRes.json();
    console.log('\nDetail Fetch Status:', detailRes.status);
    console.log('Fetched Inspection Name:', detailJson.data?.productName);
    console.log('Fetched Violations Count:', detailJson.data?.violations?.length);
    console.log('\nFULL END-TO-END FLOW VERIFIED SUCCESSFULLY!');
  }
}

testInspectionCreation();
