// ============================================================
// LegalMetriCheck — MongoDB Connection
// ============================================================

import mongoose from 'mongoose';

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/legalmetricheck';

interface MongooseCache {
  conn: typeof mongoose | null;
  promise: Promise<typeof mongoose> | null;
  lastFailedAt: number;
}

declare global {
  // eslint-disable-next-line no-var
  var mongooseCache: MongooseCache | undefined;
}

const cached: MongooseCache = global.mongooseCache || { conn: null, promise: null, lastFailedAt: 0 };

if (!global.mongooseCache) {
  global.mongooseCache = cached;
}

export async function connectDB(): Promise<typeof mongoose> {
  if (cached.conn) {
    return cached.conn;
  }

  // If failed recently (within 30s), don't block requests
  if (Date.now() - cached.lastFailedAt < 30000) {
    throw new Error('MongoDB recently unreachable, using fast in-memory fallback');
  }

  if (!cached.promise) {
    cached.promise = mongoose.connect(MONGODB_URI, {
      bufferCommands: false,
      serverSelectionTimeoutMS: 150,
      connectTimeoutMS: 150,
    });
  }

  try {
    cached.conn = await cached.promise;
    cached.lastFailedAt = 0;
  } catch (e) {
    cached.promise = null;
    cached.lastFailedAt = Date.now();
    throw e;
  }

  return cached.conn;
}
