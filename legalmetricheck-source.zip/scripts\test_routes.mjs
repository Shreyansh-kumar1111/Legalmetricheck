async function runTests() {
  const routes = [
    { url: 'http://localhost:3000', type: 'page', name: 'Landing Page' },
    { url: 'http://localhost:3000/login', type: 'page', name: 'Login Page' },
    { url: 'http://localhost:3000/dashboard', type: 'page', name: 'Dashboard' },
    { url: 'http://localhost:3000/dashboard/inspect', type: 'page', name: 'New Inspection Page' },
    { url: 'http://localhost:3000/dashboard/history', type: 'page', name: 'History Page' },
    { url: 'http://localhost:3000/dashboard/rules', type: 'page', name: 'Rules Page' },
    { url: 'http://localhost:3000/dashboard/reports', type: 'page', name: 'Reports Page' },
    { url: 'http://localhost:3000/api/rules', type: 'api', name: 'Rules API' },
    { url: 'http://localhost:3000/api/inspections/stats', type: 'api', name: 'Stats API' },
    { url: 'http://localhost:3000/api/inspections', type: 'api', name: 'Inspections API' }
  ];

  console.log('Testing LegalMetriCheck Routes...\n');
  let allPass = true;

  for (const r of routes) {
    try {
      const res = await fetch(r.url);
      const ok = res.status >= 200 && res.status < 400;
      let extra = '';
      if (r.type === 'api') {
        const json = await res.json();
        extra = `(Success: ${json.success}, Items: ${Array.isArray(json.data) ? json.data.length : 'Object'})`;
      }
      console.log(`[${ok ? 'PASS' : 'FAIL'}] ${r.name.padEnd(22)}: Status ${res.status} ${extra}`);
      if (!ok) allPass = false;
    } catch (e) {
      console.log(`[ERROR] ${r.name.padEnd(22)}: ${e.message}`);
      allPass = false;
    }
  }

  console.log(`\nOverall Result: ${allPass ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
}

runTests();
