// ============================================================
// LegalMetriCheck — Auth Helpers (MVP)
// ============================================================

import { cookies } from 'next/headers';
import { connectDB } from './db';
import User from '@/models/User';
import { UserData } from '@/types';

const SESSION_COOKIE = 'lmc_session';

export async function setSession(userId: string): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, userId, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7, // 7 days
    path: '/',
  });
}

export async function clearSession(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE);
}

export const DEMO_OFFICER: UserData = {
  _id: 'demo-officer-1',
  name: 'Inspector Rajesh Kumar',
  email: 'officer@legalmetri.demo',
  role: 'Legal Metrology Officer',
  department: 'Department of Consumer Affairs, Legal Metrology Division',
};

export async function getCurrentUser(): Promise<UserData | null> {
  try {
    const cookieStore = await cookies();
    const sessionCookie = cookieStore.get(SESSION_COOKIE);
    if (!sessionCookie?.value) return null;

    if (sessionCookie.value.startsWith('demo-')) {
      let baseDemoUser = DEMO_OFFICER;
      
      if (sessionCookie.value === 'demo-auditor-1') {
        baseDemoUser = {
          _id: 'demo-auditor-1',
          name: 'Auditor Priya Sharma',
          email: 'auditor@legalmetri.demo',
          role: 'Compliance Auditor',
          department: 'Department of Consumer Affairs, Legal Metrology Division, Govt. of India',
        };
      } else if (sessionCookie.value === 'demo-admin-1') {
        baseDemoUser = {
          _id: 'demo-admin-1',
          name: 'Director General S. K. Verma',
          email: 'admin@legalmetri.demo',
          role: 'Director (Legal Metrology)',
          department: 'Department of Consumer Affairs, Legal Metrology Division, Govt. of India',
        };
      }

      // Check for profile overrides
      const overrideCookie = cookieStore.get('lmc_demo_profile');
      if (overrideCookie?.value) {
        try {
          const overrides = JSON.parse(overrideCookie.value);
          baseDemoUser = { ...baseDemoUser, ...overrides };
        } catch (e) {}
      }

      return baseDemoUser;
    }

    try {
      await connectDB();
      const user = await User.findById(sessionCookie.value).select('-password').lean();
      if (user) {
        return {
          _id: user._id.toString(),
          name: user.name,
          email: user.email,
          role: user.role,
          department: user.department,
        };
      }
    } catch {
      // Fallback to demo officer
      return DEMO_OFFICER;
    }

    return DEMO_OFFICER;
  } catch {
    return null;
  }
}

export async function getSessionUserId(): Promise<string | null> {
  const cookieStore = await cookies();
  const sessionCookie = cookieStore.get(SESSION_COOKIE);
  return sessionCookie?.value || null;
}
