import type { Metadata, Viewport } from "next";
import { ThemeProvider } from "@/components/theme-provider";
import Script from "next/script";
import "./globals.css";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#07090E",
  colorScheme: "dark light",
};

export const metadata: Metadata = {
  title: "LegalMetriCheck - Intelligent Packaged Commodity Compliance System",
  description:
    "Digitize packaged commodity inspections with automated label scanning and rule-based compliance validation under Legal Metrology (Packaged Commodities) Rules, 2011.",
  keywords: [
    "legal metrology",
    "packaged commodities",
    "compliance",
    "label scanning",
    "OCR",
    "inspection"
  ],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <style>{`
          /* Hide Google Translate Banner and clean up UI */
          .goog-te-banner-frame { display: none !important; }
          .goog-te-menu-value { display: none !important; }
          body { top: 0 !important; }
          #goog-gt-tt { display: none !important; }
          .goog-tooltip { display: none !important; }
          .goog-tooltip:hover { display: none !important; }
          .goog-text-highlight { background-color: transparent !important; box-shadow: none !important; }
        `}</style>
      </head>
      <body className="antialiased selection:bg-slate-300 dark:selection:bg-slate-600 selection:text-black dark:selection:text-white min-h-[100dvh] w-full overflow-x-hidden m-0 p-0 flex flex-col items-center transition-colors duration-300">
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          themes={["light", "dark", "indigo", "rose", "emerald", "skyblue", "cream", "midnight"]}
          enableSystem={false}
        >
          {children}
        </ThemeProvider>
        
        <div id="google_translate_element" style={{ display: 'none' }}></div>
        
        <Script 
          id="google-translate-init" 
          strategy="afterInteractive"
          dangerouslySetInnerHTML={{
            __html: `
              function googleTranslateElementInit() {
                new google.translate.TranslateElement({pageLanguage: 'en', autoDisplay: false}, 'google_translate_element');
              }
            `,
          }}
        />
        <Script 
          src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit" 
          strategy="afterInteractive" 
        />
      </body>
    </html>
  );
}
