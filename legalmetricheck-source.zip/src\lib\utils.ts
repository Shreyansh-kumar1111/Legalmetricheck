// ============================================================
// LegalMetriCheck — Utility Functions
// ============================================================

export function generateInspectionId(): string {
  const year = new Date().getFullYear();
  const random = Math.floor(1000 + Math.random() * 9000);
  return `INS-${year}-${random}`;
}

export function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatDateTime(date: string | Date): string {
  return new Date(date).toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'COMPLIANT':
      return 'text-green-700 bg-green-50 border-green-200';
    case 'NON_COMPLIANT':
      return 'text-red-700 bg-red-50 border-red-200';
    case 'NEEDS_REVIEW':
      return 'text-amber-700 bg-amber-50 border-amber-200';
    default:
      return 'text-slate-700 bg-slate-50 border-slate-200';
  }
}

export function getStatusLabel(status: string): string {
  switch (status) {
    case 'COMPLIANT':
      return 'Compliant';
    case 'NON_COMPLIANT':
      return 'Non-Compliant';
    case 'NEEDS_REVIEW':
      return 'Needs Review';
    case 'PENDING':
      return 'Pending';
    default:
      return status;
  }
}

export function getSeverityColor(severity: string): string {
  switch (severity) {
    case 'HIGH':
      return 'text-red-700 bg-red-50';
    case 'MEDIUM':
      return 'text-amber-700 bg-amber-50';
    case 'LOW':
      return 'text-blue-700 bg-blue-50';
    default:
      return 'text-slate-700 bg-slate-50';
  }
}

export function cn(...classes: (string | undefined | null | false)[]): string {
  return classes.filter(Boolean).join(' ');
}
