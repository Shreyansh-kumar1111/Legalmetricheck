// ============================================================
// LegalMetriCheck — Rules API
// ============================================================

import { NextResponse } from 'next/server';
import { getRuleData } from '@/lib/engine/rules';

export async function GET() {
  try {
    const rules = getRuleData();
    return NextResponse.json({ success: true, data: rules });
  } catch (error) {
    console.error('Rules error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch rules' },
      { status: 500 }
    );
  }
}
